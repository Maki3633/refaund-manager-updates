@echo off
chcp 65001 >nul
cd /d "%~dp0"

set "PY_CMD="
where py >nul 2>nul
if not errorlevel 1 set "PY_CMD=py -3"
if not defined PY_CMD (
  where python >nul 2>nul
  if not errorlevel 1 set "PY_CMD=python"
)
if not defined PY_CMD (
  echo Python не знайдено. Встанови Python 3.11 або новіший та Add Python to PATH.
  pause
  exit /b 1
)

if not exist ".deps" mkdir ".deps"
set "PYTHONPATH=%CD%\.deps;%PYTHONPATH%"

echo [1/5] Готую pip...
%PY_CMD% -m pip --version >nul 2>nul
if errorlevel 1 %PY_CMD% -m ensurepip --upgrade

echo [2/5] Встановлюю Pillow + pystray локально...
%PY_CMD% -m pip install --disable-pip-version-check --upgrade --target "%CD%\.deps" -r requirements.txt
if errorlevel 1 goto :deps_error

echo [3/5] Встановлюю/перевіряю PyInstaller...
%PY_CMD% -m PyInstaller --version >nul 2>nul
if errorlevel 1 %PY_CMD% -m pip install --user --upgrade pyinstaller
%PY_CMD% -m PyInstaller --version >nul 2>nul
if errorlevel 1 goto :deps_error

echo [4/5] Перевіряю програму та трей...
%PY_CMD% -c "import PIL, pystray; print('Tray OK')"
if errorlevel 1 goto :deps_error
%PY_CMD% -m py_compile app.py
if errorlevel 1 goto :compile_error

echo [5/5] Збираю EXE з вбудованим системним треєм...
%PY_CMD% -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name "RefaundManager_8_27" ^
  --icon "assets\brand\mountain.ico" ^
  --paths ".deps" ^
  --add-data "assets;assets" ^
  --add-data "latest_version.json;." ^
  --add-data "update_config.json;." ^
  --collect-all pystray ^
  --collect-all PIL ^
  --hidden-import pystray._win32 ^
  --hidden-import PIL.Image ^
  --hidden-import PIL.ImageDraw ^
  --hidden-import PIL.ImageTk ^
  app.py
if errorlevel 1 goto :build_error

echo.
echo ================================================
echo ГОТОВО!
echo EXE: %CD%\dist\RefaundManager_8_27.exe
echo Pillow і pystray вже вбудовані в EXE.
echo ================================================
echo.
pause
exit /b 0

:deps_error
echo.
echo Не вдалося підготувати залежності. Перевір інтернет, Python та pip.
echo Сфотографуй текст вище, якщо помилка повториться.
pause
exit /b 1

:compile_error
echo.
echo У app.py є помилка. Сфотографуй текст вище.
pause
exit /b 1

:build_error
echo.
echo PyInstaller завершив збірку з помилкою. Сфотографуй текст вище.
pause
exit /b 1
