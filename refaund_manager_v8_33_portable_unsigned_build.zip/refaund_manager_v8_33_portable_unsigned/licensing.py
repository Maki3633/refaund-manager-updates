import os, sys, json, base64, hashlib, platform, uuid, urllib.request, urllib.error, time, sqlite3
from datetime import datetime
import tkinter as tk
from tkinter import messagebox

try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
except Exception:
    serialization = None
    Ed25519PublicKey = None

PRODUCT_NAME = "Refaund Manager"
LICENSE_STATE_FILE = "license_state.json"


def _b64u_decode(text):
    text = text.strip().encode("ascii")
    text += b"=" * ((4 - len(text) % 4) % 4)
    return base64.urlsafe_b64decode(text)


def _canonical_payload(payload):
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")


def device_code():
    parts = []
    if sys.platform == "win32":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0, winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0)) as key:
                parts.append(str(winreg.QueryValueEx(key, "MachineGuid")[0]))
        except Exception:
            pass
    try:
        parts.append(platform.node())
        parts.append(str(uuid.getnode()))
    except Exception:
        pass
    seed = "|".join(parts) or os.path.expanduser("~")
    digest = hashlib.sha256(("Mountain-License-v1|" + seed).encode("utf-8", errors="ignore")).hexdigest().upper()[:16]
    return "MNT-" + "-".join(digest[i:i+4] for i in range(0, 16, 4))


def saved_language(db_path):
    try:
        if os.path.exists(db_path):
            con = sqlite3.connect(db_path)
            row = con.execute("SELECT value FROM settings WHERE key='language'").fetchone()
            con.close()
            if row and row[0] in ("uk", "en", "ru"):
                return row[0]
    except Exception:
        pass
    return "uk"


TEXT = {
    "uk": {
        "title": "Активація Refaund Manager",
        "subtitle": "Приватний доступ Mountain",
        "device": "ID цього ПК",
        "copy": "Копіювати",
        "key": "Ключ активації",
        "placeholder": "Встав ключ, який видав Maki",
        "activate": "Активувати",
        "hint": "Надішли Maki ID цього ПК. Отриманий ключ працюватиме тільки на цьому пристрої.",
        "bad": "Ключ недійсний або створений для іншого ПК.",
        "revoked": "Цю ліцензію заблоковано власником.",
        "offline": "Не вдалося перевірити ліцензію онлайн. Підключись до інтернету й спробуй ще раз.",
        "active": "Ліцензія активна",
        "copied": "ID скопійовано",
    },
    "en": {
        "title": "Activate Refaund Manager", "subtitle": "Private Mountain access", "device": "This PC ID",
        "copy": "Copy", "key": "Activation key", "placeholder": "Paste the key issued by Maki", "activate": "Activate",
        "hint": "Send this PC ID to Maki. The issued key will work only on this device.",
        "bad": "The key is invalid or was created for another PC.", "revoked": "This license has been revoked by the owner.",
        "offline": "Could not verify the license online. Connect to the internet and try again.", "active": "License active", "copied": "PC ID copied",
    },
    "ru": {
        "title": "Активация Refaund Manager", "subtitle": "Приватный доступ Mountain", "device": "ID этого ПК",
        "copy": "Копировать", "key": "Ключ активации", "placeholder": "Вставь ключ, который выдал Maki", "activate": "Активировать",
        "hint": "Отправь Maki ID этого ПК. Полученный ключ будет работать только на этом устройстве.",
        "bad": "Ключ недействителен или создан для другого ПК.", "revoked": "Эта лицензия заблокирована владельцем.",
        "offline": "Не удалось проверить лицензию онлайн. Подключись к интернету и попробуй снова.", "active": "Лицензия активна", "copied": "ID скопирован",
    },
}


class LicenseManager:
    def __init__(self, data_dir, public_key_path, config_path=None):
        self.data_dir = data_dir
        self.state_path = os.path.join(data_dir, LICENSE_STATE_FILE)
        self.public_key_path = public_key_path
        self.config = {"revocation_url": "", "offline_grace_hours": 72}
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as fh:
                    self.config.update(json.load(fh) or {})
            except Exception:
                pass
        self.device_code = device_code()
        self.payload = None
        self.last_error = ""
        self.state = self._load_state()
        self.public_key = self._load_public_key()

    def _load_public_key(self):
        if serialization is None:
            raise RuntimeError("cryptography is required for license verification")
        with open(self.public_key_path, "rb") as fh:
            return serialization.load_pem_public_key(fh.read())

    def _load_state(self):
        try:
            with open(self.state_path, "r", encoding="utf-8") as fh:
                return json.load(fh) or {}
        except Exception:
            return {}

    def _save_state(self):
        os.makedirs(self.data_dir, exist_ok=True)
        tmp = self.state_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self.state, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, self.state_path)

    def clear_local_activation(self):
        self.state = {}
        self.payload = None
        try:
            os.remove(self.state_path)
        except OSError:
            pass

    def parse_and_verify(self, token):
        try:
            raw = token.strip()
            if not raw.startswith("MNT1."):
                raise ValueError("format")
            _, p64, s64 = raw.split(".", 2)
            payload_bytes = _b64u_decode(p64)
            sig = _b64u_decode(s64)
            self.public_key.verify(sig, payload_bytes)
            payload = json.loads(payload_bytes.decode("utf-8"))
            if payload.get("product") != "refaund-manager":
                raise ValueError("product")
            if payload.get("device") != self.device_code:
                raise ValueError("device")
            exp = int(payload.get("expires") or 0)
            if exp and int(time.time()) > exp:
                raise ValueError("expired")
            return payload
        except Exception:
            return None

    def _fetch_revoked(self):
        """Fetch the revocation list without reusing a stale CDN/browser cache.

        raw.githubusercontent.com may briefly serve an older object after the owner
        edits revoked_licenses.json.  Every check therefore uses a unique query
        parameter plus explicit no-cache/no-store headers.  We retry once with a
        second unique URL before falling back to the normal offline-grace logic.
        """
        base_url = str(self.config.get("revocation_url") or "").strip()
        if not base_url:
            return set(), True

        for attempt in range(2):
            nonce = f"{int(time.time() * 1000)}-{uuid.uuid4().hex[:10]}-{attempt}"
            separator = "&" if "?" in base_url else "?"
            url = f"{base_url}{separator}_mountain_refresh={nonce}"
            try:
                req = urllib.request.Request(
                    url,
                    headers={
                        "User-Agent": "RefaundManager-License/2",
                        "Accept": "application/json, text/plain, */*",
                        "Accept-Encoding": "identity",
                        "Cache-Control": "no-cache, no-store, max-age=0, must-revalidate",
                        "Pragma": "no-cache",
                        "Expires": "0",
                    },
                )
                with urllib.request.urlopen(req, timeout=7) as resp:
                    data = json.loads(resp.read().decode("utf-8", errors="replace"))
                revoked = set(str(x).strip() for x in (data.get("revoked") or []) if str(x).strip())
                self.state["last_revocation_fetch"] = int(time.time())
                self.state["last_revocation_updated_at"] = str(data.get("updated_at") or "")
                return revoked, True
            except urllib.error.HTTPError as exc:
                if exc.code == 404:
                    return set(), True
                if attempt == 0:
                    time.sleep(0.15)
                    continue
            except Exception:
                if attempt == 0:
                    time.sleep(0.15)
                    continue

        return set(), False

    def validate_token(self, token, online=True, activation=False):
        payload = self.parse_and_verify(token)
        if not payload:
            self.last_error = "invalid"
            return False
        lic_id = str(payload.get("license_id") or "")
        if online:
            revoked, ok = self._fetch_revoked()
            if ok:
                if lic_id in revoked:
                    self.last_error = "revoked"
                    return False
                self.state["last_online_check"] = int(time.time())
                self._save_state()
            else:
                grace = int(self.config.get("offline_grace_hours") or 72) * 3600
                last = int(self.state.get("last_online_check") or 0)
                if activation or not last or int(time.time()) - last > grace:
                    self.last_error = "offline"
                    return False
        self.payload = payload
        self.last_error = ""
        return True

    def activate(self, token):
        if not self.validate_token(token, online=True, activation=True):
            return False
        self.state.update({
            "activation_key": token.strip(),
            "license_id": self.payload.get("license_id", ""),
            "owner": self.payload.get("owner", ""),
            "device": self.device_code,
            "activated_at": int(time.time()),
            "last_online_check": int(self.state.get("last_online_check") or time.time()),
        })
        self._save_state()
        return True

    def validate_current(self):
        token = str(self.state.get("activation_key") or "")
        if not token:
            self.last_error = "missing"
            return False
        return self.validate_token(token, online=True, activation=False)

    @property
    def license_id(self):
        return str((self.payload or {}).get("license_id") or self.state.get("license_id") or "")

    @property
    def owner(self):
        return str((self.payload or {}).get("owner") or self.state.get("owner") or "")


class ActivationWindow(tk.Tk):
    def __init__(self, manager, language="uk", logo_path=None):
        super().__init__()
        self.manager = manager
        self.language = language if language in TEXT else "uk"
        self.txt = TEXT[self.language]
        self.authorized = False
        self.logo_path = logo_path
        self.logo_photo = None
        self.title(self.txt["title"])
        self.configure(bg="#0b0f14")
        self.geometry("620x570")
        self.minsize(560, 540)
        self.resizable(False, False)
        try:
            self.iconbitmap(default="")
        except Exception:
            pass
        self._build()
        self.update_idletasks()
        x = max(0, (self.winfo_screenwidth() - self.winfo_width()) // 2)
        y = max(0, (self.winfo_screenheight() - self.winfo_height()) // 2)
        self.geometry(f"+{x}+{y}")

    def _build(self):
        card = tk.Frame(self, bg="#121923", highlightthickness=1, highlightbackground="#2a3442")
        card.pack(fill="both", expand=True, padx=28, pady=28)
        if self.logo_path:
            try:
                self.logo_photo = tk.PhotoImage(file=self.logo_path)
                tk.Label(card, image=self.logo_photo, bg="#121923", bd=0, highlightthickness=0).pack(pady=(22, 5))
            except Exception:
                tk.Label(card, text="▲", bg="#121923", fg="#ffffff", font=("Segoe UI Semibold", 31)).pack(pady=(24, 4))
        else:
            tk.Label(card, text="▲", bg="#121923", fg="#ffffff", font=("Segoe UI Semibold", 31)).pack(pady=(24, 4))
        tk.Label(card, text=self.txt["title"], bg="#121923", fg="#eaf2ff", font=("Segoe UI Semibold", 19)).pack()
        tk.Label(card, text=self.txt["subtitle"], bg="#121923", fg="#8b7cff", font=("Segoe UI", 10)).pack(pady=(2, 20))
        tk.Label(card, text=self.txt["device"], bg="#121923", fg="#9aa8bc", font=("Segoe UI", 9)).pack(anchor="w", padx=28)
        device_row = tk.Frame(card, bg="#121923"); device_row.pack(fill="x", padx=28, pady=(5, 12))
        device_box = tk.Label(device_row, text=self.manager.device_code, font=("Consolas", 12), bg="#0f141c", fg="#eaf2ff", anchor="w", padx=10, pady=10)
        device_box.pack(side="left", fill="x", expand=True)
        tk.Button(device_row, text=self.txt["copy"], command=self._copy_device, bg="#162033", fg="#eaf2ff", activebackground="#253244", activeforeground="#ffffff", relief="flat", padx=16, pady=9, cursor="hand2").pack(side="left", padx=(8,0))
        tk.Label(card, text=self.txt["hint"], bg="#121923", fg="#6f7f93", font=("Segoe UI", 9), wraplength=510, justify="left").pack(anchor="w", padx=28, pady=(0, 16))
        tk.Label(card, text=self.txt["key"], bg="#121923", fg="#9aa8bc", font=("Segoe UI", 9)).pack(anchor="w", padx=28)
        self.key_text = tk.Text(card, height=4, bg="#0f141c", fg="#eaf2ff", insertbackground="#eaf2ff", relief="flat", font=("Consolas", 9), wrap="word")
        self.key_text.pack(fill="x", padx=28, pady=(5, 10))
        self.status = tk.Label(card, text="", bg="#121923", fg="#ff5d69", font=("Segoe UI", 9))
        self.status.pack(anchor="w", padx=28, pady=(0, 6))
        self.activate_btn = tk.Button(card, text=self.txt["activate"], command=self._activate, bg="#8b5cf6", fg="#ffffff", activebackground="#7c3aed", activeforeground="#ffffff", relief="flat", font=("Segoe UI Semibold", 10), pady=11, cursor="hand2")
        self.activate_btn.pack(fill="x", padx=28, pady=(4, 22))

    def _copy_device(self):
        self.clipboard_clear(); self.clipboard_append(self.manager.device_code)
        self.status.config(text=self.txt["copied"], fg="#19d3ae")

    def _activate(self):
        token = self.key_text.get("1.0", "end").strip()
        self.activate_btn.config(state="disabled")
        self.status.config(text="…", fg="#ffb24a")
        self.update_idletasks()
        ok = self.manager.activate(token)
        if ok:
            self.status.config(text=self.txt["active"], fg="#19d3ae")
            self.authorized = True
            self.after(350, self.destroy)
        else:
            key = self.manager.last_error
            msg = self.txt["revoked"] if key == "revoked" else self.txt["offline"] if key == "offline" else self.txt["bad"]
            self.status.config(text=msg, fg="#ff5d69")
            self.activate_btn.config(state="normal")


def ensure_licensed(data_dir, public_key_path, config_path, db_path, logo_path=None):
    manager = LicenseManager(data_dir, public_key_path, config_path)
    if manager.validate_current():
        return manager
    # Revoked licenses never fall back silently to activation; let the owner issue a new key.
    lang = saved_language(db_path)
    gate = ActivationWindow(manager, lang, logo_path=logo_path)
    gate.mainloop()
    if gate.authorized:
        return manager
    return None
