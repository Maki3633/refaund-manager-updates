@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title Refaund Manager 8.33 - Portable Build

echo ================================================
echo   Refaund Manager 8.33 - PORTABLE UNSIGNED
echo ================================================
echo.
echo This build uses PyInstaller ONEDIR, not ONEFILE.
echo End users must receive the WHOLE Refaund Manager folder.
echo.

set "PY_CMD="
where py >nul 2>nul
if not errorlevel 1 set "PY_CMD=py -3"
if not defined PY_CMD (
  where python >nul 2>nul
  if not errorlevel 1 set "PY_CMD=python"
)
if not defined PY_CMD (
  echo ERROR: Python 3 not found.
  echo Install Python 3.11+ and enable Add Python to PATH.
  pause
  exit /b 1
)

echo [1/5] Installing build dependencies...
%PY_CMD% -m pip install --disable-pip-version-check --upgrade pyinstaller Pillow pystray cryptography
if errorlevel 1 goto :error

echo [2/5] Checking Python source...
%PY_CMD% -m py_compile app.py licensing.py
if errorlevel 1 goto :error

echo [3/5] Building portable folder...
if exist build rmdir /s /q build
if exist "dist\Refaund Manager" rmdir /s /q "dist\Refaund Manager"
%PY_CMD% -m PyInstaller --noconfirm --clean --onedir --windowed --noupx ^
  --name "Refaund Manager" ^
  --icon "assets\brand\mountain.ico" ^
  --version-file "version_info.txt" ^
  --add-data "assets;assets" ^
  --add-data "update_config.json;." ^
  --add-data "license_config.json;." ^
  --collect-all pystray ^
  --collect-all PIL ^
  --collect-all cryptography ^
  --hidden-import pystray._win32 ^
  --hidden-import PIL.Image ^
  --hidden-import PIL.ImageDraw ^
  --hidden-import PIL.ImageTk ^
  app.py
if errorlevel 1 goto :error

echo [4/5] Preparing user package...
copy /y "USER_START_UA.txt" "dist\Refaund Manager\READ_ME_FIRST.txt" >nul
if exist "Refaund_Manager_8_33_Portable.zip" del /q "Refaund_Manager_8_33_Portable.zip"
powershell -NoProfile -Command "Compress-Archive -Path 'dist\Refaund Manager\*' -DestinationPath 'Refaund_Manager_8_33_Portable.zip' -CompressionLevel Optimal -Force"
if errorlevel 1 goto :error

echo [5/5] Calculating SHA256...
powershell -NoProfile -Command "$h=(Get-FileHash -Algorithm SHA256 'dist\Refaund Manager\Refaund Manager.exe').Hash; 'Refaund Manager.exe SHA256: '+$h | Set-Content -Encoding UTF8 'Refaund_Manager_8_33_SHA256.txt'"

echo.
echo ================================================
echo READY
echo ================================================
echo Test locally:
echo   %CD%\dist\Refaund Manager\Refaund Manager.exe
echo.
echo Send to another person:
echo   %CD%\Refaund_Manager_8_33_Portable.zip
echo.
echo IMPORTANT: Do NOT send only the EXE.
echo The complete extracted folder is required.
echo.
pause
exit /b 0

:error
echo.
echo BUILD ERROR. Send a screenshot of the text above.
pause
exit /b 1
