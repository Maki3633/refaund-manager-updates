import os
import sqlite3
import sys
import csv
import json
import threading
import urllib.error
import urllib.parse
import urllib.request
import shutil
import subprocess
import time
import webbrowser
import importlib
from collections import defaultdict

# Local optional dependencies. start.bat installs pystray/Pillow here so the
# exact same Python that launches the app can always find them. This avoids
# Windows machines where pip --user installs into a different interpreter.
def _bootstrap_local_deps():
    if getattr(sys, "frozen", False):
        return
    try:
        base = os.path.dirname(os.path.abspath(__file__))
        deps = os.path.join(base, ".deps")
        if os.path.isdir(deps) and deps not in sys.path:
            sys.path.insert(0, deps)
    except Exception:
        pass

_bootstrap_local_deps()
import tkinter as tk
from tkinter import ttk, messagebox
import tkinter.font as tkfont
from datetime import datetime
from decimal import Decimal, InvalidOperation

APP_NAME = "Refaund Manager"
APP_VERSION = "8.28"


def app_data_dir():
    """Keep user data next to the executable/source file."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def resource_path(*parts):
    """Locate bundled read-only UI assets both from source and PyInstaller."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        base = sys._MEIPASS
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, *parts)


DB_FILE = os.path.join(app_data_dir(), "amazon_resale.db")

# ---------- Premium black / blue dashboard theme ----------
BG = "#0b0f14"
SIDEBAR = "#0a0f16"
CARD = "#121923"
CARD_2 = "#0f141c"
CARD_3 = "#162033"
BORDER = "#2a3442"
TEXT = "#eaf2ff"
MUTED = "#9aa8bc"
MUTED_2 = "#6f7f93"
ACCENT = "#1687ff"
ACCENT_HOVER = "#0b73e6"
GREEN = "#19d3ae"
RED = "#ff5d69"
AMBER = "#ffb24a"
BLUE = "#2c92ff"
PURPLE = "#8b7cff"
ROW_ALT = "#0a111a"
GRID_LINE = "#172433"

THEME_PRESETS = {
    "dark": {"BG":"#0b0f14","SIDEBAR":"#0a0f16","CARD":"#121923","CARD_2":"#0f141c","CARD_3":"#162033","BORDER":"#2a3442","TEXT":"#eaf2ff","MUTED":"#9aa8bc","MUTED_2":"#6f7f93","ROW_ALT":"#0a111a","GRID_LINE":"#172433"},
    "light": {"BG":"#edf2f7","SIDEBAR":"#f8fafc","CARD":"#ffffff","CARD_2":"#f2f5f9","CARD_3":"#e6edf5","BORDER":"#cbd6e3","TEXT":"#152238","MUTED":"#52657b","MUTED_2":"#7b8a9c","ROW_ALT":"#f6f8fb","GRID_LINE":"#dce4ee"},
}

def apply_theme_globals(theme_key):
    global BG, SIDEBAR, CARD, CARD_2, CARD_3, BORDER, TEXT, MUTED, MUTED_2, ROW_ALT, GRID_LINE
    pal = THEME_PRESETS.get(theme_key, THEME_PRESETS["dark"])
    BG=pal["BG"]; SIDEBAR=pal["SIDEBAR"]; CARD=pal["CARD"]; CARD_2=pal["CARD_2"]; CARD_3=pal["CARD_3"]
    BORDER=pal["BORDER"]; TEXT=pal["TEXT"]; MUTED=pal["MUTED"]; MUTED_2=pal["MUTED_2"]; ROW_ALT=pal["ROW_ALT"]; GRID_LINE=pal["GRID_LINE"]

ITEM_CATEGORIES = ["Phones", "Computers", "Tablets", "Audio", "Gaming", "Smart Home", "Cameras", "Accessories", "Other"]
UPDATE_MANIFEST_FILE = "latest_version.json"

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI Semibold", 10)
FONT_SMALL = ("Segoe UI", 9)
FONT_TITLE = ("Segoe UI Semibold", 24)
FONT_SUBTITLE = ("Segoe UI Semibold", 14)
FONT_BIG = ("Segoe UI Semibold", 21)

LANGUAGE_NAMES = {"uk": "Українська", "en": "English", "ru": "Русский"}
ORDER_STATUSES = ["Ordered", "In transit", "Received", "Refund received", "Sent to buyer", "Completed", "Cancelled"]
ITEM_STATUSES = ["Ordered", "In transit", "Received", "Sent to buyer", "Returned"]

# Multi-carrier tracking. One AfterShip integration covers the common carriers
# used by the app, so the user does not need a separate FedEx/UPS/DHL API key.
TRACKING_CARRIERS = {
    "Auto detect": "",
    "FedEx": "fedex",
    "UPS": "ups",
    "USPS": "usps",
    "DHL Express": "dhl",
    "DPD": "dpd",
    "Amazon Shipping": "amazon",
    "Meest": "meest",
    "OnTrac": "ontrac",
    "Canada Post": "canada-post",
    "Purolator": "purolator",
}
TRACKING_SLUG_TO_NAME = {v: k for k, v in TRACKING_CARRIERS.items() if v}
AFTERSHIP_BASE = "https://api.aftership.com/tracking/2026-07"
DELIVERY_TAGS = ("Pending", "InfoReceived", "InTransit", "OutForDelivery", "AttemptFail",
                 "Delivered", "AvailableForPickup", "Exception", "Expired")

I18N = {
    "uk": {
        "app_subtitle": "Облік закупівель і продажів",
        "dashboard": "Головна",
        "orders": "Замовлення",
        "settings": "Налаштування",
        "data_saved": "Дані зберігаються локально",
        "version": "Версія {version}",
        "dashboard_title": "Фінансовий огляд",
        "dashboard_subtitle": "Усі закупівлі, продажі та прибуток в одному місці",
        "new_order": "+ Нове замовлення",
        "total_invested": "Вкладено всього",
        "revenue_received": "Отримана виручка",
        "profit_now": "Прибуток зараз",
        "projected_profit": "Прогноз прибутку",
        "orders_count": "Замовлень",
        "refunds_count": "Refund",
        "recent_orders": "Останні замовлення",
        "no_orders_yet": "Поки немає замовлень. Створи перше замовлення.",
        "order_id": "Order ID",
        "store": "Магазин",
        "date": "Дата",
        "products": "Товари",
        "expenses": "Витрати",
        "revenue": "Виручка",
        "status": "Статус",
        "refund": "Refund",
        "tracking": "Tracking",
        "margin": "Маржа",
        "orders_title": "Замовлення",
        "orders_subtitle": "Керуй закупівлями, товарами, продажами та поверненнями",
        "search_placeholder": "Пошук за магазином, Order ID, tracking або товаром...",
        "edit": "Редагувати",
        "delete": "Видалити",
        "items": "Шт.",
        "settings_title": "Налаштування",
        "settings_subtitle": "Персоналізація програми",
        "language": "Мова інтерфейсу",
        "language_hint": "Мова змінюється у всій програмі: меню, статуси, вікна та повідомлення.",
        "currency": "Валюта",
        "currency_hint": "Змінюється тільки символ у відображенні сум. Самі значення не конвертуються.",
        "animations": "Плавні анімації",
        "animations_hint": "Анімація запуску, кнопок та фінансових показників.",
        "save_settings": "Зберегти налаштування",
        "settings_saved": "Налаштування збережено.",
        "appearance": "Інтерфейс",
        "dark_theme": "Темна тема",
        "local_data": "Локальні дані",
        "database_path": "Файл бази даних",
        "about": "Про програму",
        "about_text": "Refaund Manager допомагає рахувати собівартість, виручку, прибуток і Refund по кожному замовленню.",
        "order_details": "Деталі замовлення",
        "edit_order": "Редагування замовлення",
        "create_order": "Нове замовлення",
        "save_order": "Зберегти замовлення",
        "purchase_date": "Дата покупки",
        "order_status": "Статус замовлення",
        "products_in_order": "Товари в цьому замовленні",
        "add_product": "+ Додати товар",
        "product": "Товар",
        "qty": "К-сть",
        "sold": "Продано",
        "buy_unit": "Закупка / шт.",
        "plan_sale": "План продажу",
        "actual_sale": "Факт. продаж",
        "projected": "Прогноз",
        "remove": "Видалити",
        "order_expenses": "Витрати замовлення",
        "shipping": "Доставка",
        "tax": "Податок",
        "other_expenses": "Інші витрати",
        "refund_received": "Refund отримано",
        "refund_amount": "Сума Refund",
        "notes": "Примітки",
        "revenue_now": "Виручка зараз",
        "projected_revenue": "Прогноз виручки",
        "product_title": "Товар",
        "product_name": "Назва товару",
        "quantity": "Кількість",
        "sold_quantity": "Продано одиниць",
        "buy_price_unit": "Ціна закупки / шт.",
        "consumables_unit": "Розхідники / шт.",
        "planned_sale_unit": "Планова ціна продажу / шт.",
        "actual_sale_unit": "Фактична ціна продажу / шт.",
        "serial_imei": "Serial / IMEI",
        "product_status": "Статус товару",
        "cancel": "Скасувати",
        "save_product": "Зберегти товар",
        "enter_product_name": "Введи назву товару.",
        "quantity_whole": "Кількість повинна бути цілим числом.",
        "check_quantity": "Перевір кількість і кількість проданих одиниць.",
        "select_product": "Спочатку вибери товар.",
        "enter_order_id": "Введи Order ID.",
        "add_one_product": "Додай хоча б один товар.",
        "date_format": "Дата повинна бути у форматі РРРР-ММ-ДД.",
        "select_order": "Спочатку вибери замовлення.",
        "delete_order_title": "Видалення замовлення",
        "delete_order_question": "Видалити {order_id} та всі товари в ньому?",
        "yes": "Так",
        "no": "Ні",
        "status.Ordered": "Замовлено",
        "status.In transit": "В дорозі",
        "status.Received": "Отримано",
        "status.Processing": "В обробці",
        "status.Completed": "Завершено",
        "status.Cancelled": "Скасовано",
        "status.For sale": "У продажу",
        "status.Sold": "Продано",
        "status.Returned": "Повернено",
        "metric_hint_invested": "Повна собівартість усіх замовлень",
        "metric_hint_revenue": "Фактично отримано від продажів",
        "metric_hint_profit": "Фактична виручка + Refund − усі витрати",
        "metric_hint_projected": "Очікуваний результат після продажу залишку",
        "metric_hint_orders": "Загальна кількість замовлень",
        "metric_hint_refunds": "Замовлення з відміткою Refund",
    },
    "en": {
        "app_subtitle": "Purchases & sales tracker",
        "dashboard": "Dashboard",
        "orders": "Orders",
        "settings": "Settings",
        "data_saved": "Data is saved locally",
        "version": "Version {version}",
        "dashboard_title": "Financial overview",
        "dashboard_subtitle": "Purchases, sales and profit in one place",
        "new_order": "+ New order",
        "total_invested": "Total invested",
        "revenue_received": "Revenue received",
        "profit_now": "Profit now",
        "projected_profit": "Projected profit",
        "orders_count": "Orders",
        "refunds_count": "Refunds",
        "recent_orders": "Recent orders",
        "no_orders_yet": "No orders yet. Create your first order.",
        "order_id": "Order ID",
        "store": "Store",
        "date": "Date",
        "products": "Products",
        "expenses": "Expenses",
        "revenue": "Revenue",
        "status": "Status",
        "refund": "Refund",
        "tracking": "Tracking",
        "margin": "Margin",
        "orders_title": "Orders",
        "orders_subtitle": "Manage purchases, products, sales and refunds",
        "search_placeholder": "Search by store, Order ID, tracking or product...",
        "edit": "Edit",
        "delete": "Delete",
        "items": "Items",
        "settings_title": "Settings",
        "settings_subtitle": "Personalize the application",
        "language": "Interface language",
        "language_hint": "The whole interface changes: menu, statuses, windows and messages.",
        "currency": "Currency",
        "currency_hint": "Only the displayed symbol changes. Values are not converted.",
        "animations": "Smooth animations",
        "animations_hint": "Startup, button hover and financial metric animations.",
        "save_settings": "Save settings",
        "settings_saved": "Settings saved.",
        "appearance": "Appearance",
        "dark_theme": "Dark theme",
        "local_data": "Local data",
        "database_path": "Database file",
        "about": "About",
        "about_text": "Refaund Manager tracks cost, revenue, profit and refunds for every order.",
        "order_details": "Order details",
        "edit_order": "Edit order",
        "create_order": "New order",
        "save_order": "Save order",
        "purchase_date": "Purchase date",
        "order_status": "Order status",
        "products_in_order": "Products in this order",
        "add_product": "+ Add product",
        "product": "Product",
        "qty": "Qty",
        "sold": "Sold",
        "buy_unit": "Buy / unit",
        "plan_sale": "Plan sale",
        "actual_sale": "Actual sale",
        "projected": "Projected",
        "remove": "Remove",
        "order_expenses": "Order expenses",
        "shipping": "Shipping",
        "tax": "Tax",
        "other_expenses": "Other expenses",
        "refund_received": "Refund received",
        "refund_amount": "Refund amount",
        "notes": "Notes",
        "revenue_now": "Revenue now",
        "projected_revenue": "Projected revenue",
        "product_title": "Product",
        "product_name": "Product name",
        "quantity": "Quantity",
        "sold_quantity": "Sold quantity",
        "buy_price_unit": "Buy price / unit",
        "consumables_unit": "Consumables / unit",
        "planned_sale_unit": "Planned sale / unit",
        "actual_sale_unit": "Actual sale / unit",
        "serial_imei": "Serial / IMEI",
        "product_status": "Product status",
        "cancel": "Cancel",
        "save_product": "Save product",
        "enter_product_name": "Enter product name.",
        "quantity_whole": "Quantity must be a whole number.",
        "check_quantity": "Check quantity and sold quantity.",
        "select_product": "Select a product first.",
        "enter_order_id": "Enter Order ID.",
        "add_one_product": "Add at least one product.",
        "date_format": "Date format must be YYYY-MM-DD.",
        "select_order": "Select an order first.",
        "delete_order_title": "Delete order",
        "delete_order_question": "Delete {order_id} and all its products?",
        "yes": "Yes",
        "no": "No",
        "status.Ordered": "Ordered",
        "status.In transit": "In transit",
        "status.Received": "Received",
        "status.Processing": "Processing",
        "status.Completed": "Completed",
        "status.Cancelled": "Cancelled",
        "status.For sale": "For sale",
        "status.Sold": "Sold",
        "status.Returned": "Returned",
        "metric_hint_invested": "Full cost of all orders",
        "metric_hint_revenue": "Revenue actually received from sales",
        "metric_hint_profit": "Actual revenue + refunds − all expenses",
        "metric_hint_projected": "Expected result after remaining stock is sold",
        "metric_hint_orders": "Total number of orders",
        "metric_hint_refunds": "Orders marked as refunded",
    },
    "ru": {
        "app_subtitle": "Учёт закупок и продаж",
        "dashboard": "Главная",
        "orders": "Заказы",
        "settings": "Настройки",
        "data_saved": "Данные сохраняются локально",
        "version": "Версия {version}",
        "dashboard_title": "Финансовый обзор",
        "dashboard_subtitle": "Все закупки, продажи и прибыль в одном месте",
        "new_order": "+ Новый заказ",
        "total_invested": "Вложено всего",
        "revenue_received": "Полученная выручка",
        "profit_now": "Прибыль сейчас",
        "projected_profit": "Прогноз прибыли",
        "orders_count": "Заказов",
        "refunds_count": "Refund",
        "recent_orders": "Последние заказы",
        "no_orders_yet": "Пока нет заказов. Создай первый заказ.",
        "order_id": "Order ID",
        "store": "Магазин",
        "date": "Дата",
        "products": "Товары",
        "expenses": "Расходы",
        "revenue": "Выручка",
        "status": "Статус",
        "refund": "Refund",
        "tracking": "Tracking",
        "margin": "Маржа",
        "orders_title": "Заказы",
        "orders_subtitle": "Управляй закупками, товарами, продажами и возвратами",
        "search_placeholder": "Поиск по магазину, Order ID, tracking или товару...",
        "edit": "Редактировать",
        "delete": "Удалить",
        "items": "Шт.",
        "settings_title": "Настройки",
        "settings_subtitle": "Персонализация программы",
        "language": "Язык интерфейса",
        "language_hint": "Язык меняется во всей программе: меню, статусы, окна и сообщения.",
        "currency": "Валюта",
        "currency_hint": "Меняется только символ отображения сумм. Значения не конвертируются.",
        "animations": "Плавные анимации",
        "animations_hint": "Анимация запуска, кнопок и финансовых показателей.",
        "save_settings": "Сохранить настройки",
        "settings_saved": "Настройки сохранены.",
        "appearance": "Интерфейс",
        "dark_theme": "Тёмная тема",
        "local_data": "Локальные данные",
        "database_path": "Файл базы данных",
        "about": "О программе",
        "about_text": "Refaund Manager помогает считать себестоимость, выручку, прибыль и Refund по каждому заказу.",
        "order_details": "Детали заказа",
        "edit_order": "Редактирование заказа",
        "create_order": "Новый заказ",
        "save_order": "Сохранить заказ",
        "purchase_date": "Дата покупки",
        "order_status": "Статус заказа",
        "products_in_order": "Товары в этом заказе",
        "add_product": "+ Добавить товар",
        "product": "Товар",
        "qty": "Кол-во",
        "sold": "Продано",
        "buy_unit": "Закупка / шт.",
        "plan_sale": "План продажи",
        "actual_sale": "Факт. продажа",
        "projected": "Прогноз",
        "remove": "Удалить",
        "order_expenses": "Расходы заказа",
        "shipping": "Доставка",
        "tax": "Налог",
        "other_expenses": "Другие расходы",
        "refund_received": "Refund получен",
        "refund_amount": "Сумма Refund",
        "notes": "Примечания",
        "revenue_now": "Выручка сейчас",
        "projected_revenue": "Прогноз выручки",
        "product_title": "Товар",
        "product_name": "Название товара",
        "quantity": "Количество",
        "sold_quantity": "Продано единиц",
        "buy_price_unit": "Цена закупки / шт.",
        "consumables_unit": "Расходники / шт.",
        "planned_sale_unit": "Плановая цена продажи / шт.",
        "actual_sale_unit": "Фактическая цена продажи / шт.",
        "serial_imei": "Serial / IMEI",
        "product_status": "Статус товара",
        "cancel": "Отмена",
        "save_product": "Сохранить товар",
        "enter_product_name": "Введи название товара.",
        "quantity_whole": "Количество должно быть целым числом.",
        "check_quantity": "Проверь количество и количество проданных единиц.",
        "select_product": "Сначала выбери товар.",
        "enter_order_id": "Введи Order ID.",
        "add_one_product": "Добавь хотя бы один товар.",
        "date_format": "Дата должна быть в формате ГГГГ-ММ-ДД.",
        "select_order": "Сначала выбери заказ.",
        "delete_order_title": "Удаление заказа",
        "delete_order_question": "Удалить {order_id} и все товары в нём?",
        "yes": "Да",
        "no": "Нет",
        "status.Ordered": "Заказано",
        "status.In transit": "В пути",
        "status.Received": "Получено",
        "status.Processing": "В обработке",
        "status.Completed": "Завершено",
        "status.Cancelled": "Отменено",
        "status.For sale": "В продаже",
        "status.Sold": "Продано",
        "status.Returned": "Возвращено",
        "metric_hint_invested": "Полная себестоимость всех заказов",
        "metric_hint_revenue": "Фактически получено от продаж",
        "metric_hint_profit": "Фактическая выручка + Refund − все расходы",
        "metric_hint_projected": "Ожидаемый результат после продажи остатка",
        "metric_hint_orders": "Общее количество заказов",
        "metric_hint_refunds": "Заказы с отметкой Refund",
    },
}


ACCENT_PRESETS = {
    # Calm, readable accents for the black theme.
    "violet": ("#8b5cf6", "#7c3aed"),
    "cyan": ("#22d3ee", "#0891b2"),
    "emerald": ("#22c55e", "#16a34a"),
}

I18N_EXTRAS = {
    "uk": {
        "analytics": "Аналітика",
        "analytics_title": "Аналітика бізнесу",
        "analytics_subtitle": "Прибуток, оборот, запаси та найкращі товари",
        "overview": "Огляд",
        "refresh": "Оновити",
        "roi": "ROI",
        "avg_order": "Середнє замовлення",
        "refund_rate": "Частка Refund",
        "inventory_value": "Товару в залишку",
        "units_total": "Всього одиниць",
        "units_sold": "Продано одиниць",
        "units_stock": "В залишку",
        "performance": "Фінансова динаміка",
        "performance_hint": "Витрати та прогнозована виручка за місяцем покупки",
        "inventory_health": "Стан запасів",
        "inventory_hint": "Скільки одиниць уже продано і скільки ще в залишку",
        "invested": "Витрати",
        "projected_revenue_short": "Прогноз виручки",
        "top_products": "Найприбутковіші товари",
        "top_products_hint": "Прогнозований валовий прибуток без розподілу доставки та податків",
        "profit_per_unit": "Прибуток / шт.",
        "units": "Одиниці",
        "all_statuses": "Усі статуси",
        "all_refunds": "Усі замовлення",
        "refunded_only": "Тільки Refund",
        "without_refund": "Без Refund",
        "filter_status": "Статус",
        "filter_refund": "Refund-фільтр",
        "clear_filters": "Скинути",
        "export_csv": "Експорт CSV",
        "backup_db": "Створити backup",
        "open_data_folder": "Відкрити папку даних",
        "data_tools": "Дані та резервні копії",
        "data_tools_hint": "Експортуй таблицю або зроби резервну копію бази перед великими змінами.",
        "backup_created": "Резервну копію створено:\n{path}",
        "export_created": "CSV-файл створено:\n{path}",
        "accent_color": "Акцентний колір",
        "accent_hint": "Змінює основний колір кнопок, активного меню та графіків.",
        "accent.violet": "Фіолетовий",
        "accent.cyan": "Блакитний",
        "accent.emerald": "Зелений",
        "quick_actions": "Швидкі дії",
        "new_order_action": "Додати нове замовлення",
        "open_orders": "Відкрити замовлення",
        "open_analytics": "Переглянути аналітику",
        "business_snapshot": "Поточний результат",
        "business_snapshot_hint": "Прогнозований чистий результат по всіх активних і завершених замовленнях",
        "projected_roi": "Прогнозований ROI",
        "active_orders": "Активних замовлень",
        "completed_orders": "Завершено",
        "refund_total": "Refund сума",
        "no_analytics": "Додай хоча б одне замовлення — тут з’являться графіки та статистика.",
        "status_breakdown": "Замовлення за статусом",
        "product_name_short": "Товар",
        "profit": "Прибуток",
        "shortcut_new": "Ctrl+N — нове замовлення",
        "shortcut_search": "Ctrl+F — пошук замовлень",
        "shortcut_refresh": "F5 — оновити сторінку",
        "shortcut_fullscreen": "F11 — повний екран • Esc — вийти",
        "keyboard_shortcuts": "Гарячі клавіші",
        "saved_toast": "Замовлення збережено",
        "settings_saved_toast": "Налаштування застосовано",
        "autosave_settings": "Автозбереження налаштувань",
        "autosave_settings_hint": "Усі зміни зберігаються автоматично одразу після вибору.",
        "autosaved": "Збережено автоматично",
        "backup": "Backup",
        "export": "Експорт",
        "search": "Пошук",
        "order_count_label": "замовлень",
        "stock": "Залишок",
        "sold_label": "Продано",
        "month_no_data": "Немає даних",
        "products_page": "Товари",
        "sales_page": "Продажі",
        "refunds_page": "Refunds",
        "expenses_page": "Витрати",
        "products_title": "Усі товари",
        "products_subtitle": "Повний список техніки у всіх замовленнях",
        "sales_title": "Продажі",
        "sales_subtitle": "Продані одиниці, виручка та прибуток",
        "refunds_title": "Refund",
        "refunds_subtitle": "Замовлення з отриманим або очікуваним поверненням",
        "expenses_title": "Витрати",
        "expenses_subtitle": "Закупки, доставка, податки та інші витрати",
        "search_global": "Пошук товарів, замовлень, tracking...",
        "revenue_profit_trend": "Виручка та прибуток",
        "order_status_chart": "Статуси замовлень",
        "sold_vs_stock": "Продано / в залишку",
        "weekly_sales": "Продажі за днями",
        "refund_overview": "Refund огляд",
        "top_profitable": "Найприбутковіші товари",
        "view_all": "Переглянути все",
        "no_refund": "Без Refund",
        "refund_orders": "Refund замовлень",
        "active_orders_short": "Активні",
        "total_orders_short": "Замовлень",
        "revenue_short": "Виручка",
        "net_profit_short": "Чистий прибуток",
        "total_invested_short": "Вкладено",
        "roi_short": "ROI",
        "trend_hint": "Прогнозована виручка та прибуток за датами закупівель",
        "weekly_hint": "Фактична виручка за днем покупки",
        "refund_sum": "Сума Refund",
        "buy_cost": "Закупка",
        "consumables": "Розхідники",
        "other_costs": "Інше",
        "order_cost": "Собівартість",
        "unit_profit": "Прибуток / шт.",
    },
    "en": {
        "analytics": "Analytics",
        "analytics_title": "Business analytics",
        "analytics_subtitle": "Profit, revenue, inventory and best-performing products",
        "overview": "Overview",
        "refresh": "Refresh",
        "roi": "ROI",
        "avg_order": "Average order",
        "refund_rate": "Refund rate",
        "inventory_value": "Inventory value",
        "units_total": "Total units",
        "units_sold": "Units sold",
        "units_stock": "In stock",
        "performance": "Financial performance",
        "performance_hint": "Costs and projected revenue grouped by purchase month",
        "inventory_health": "Inventory health",
        "inventory_hint": "How many units are sold and how many are still in stock",
        "invested": "Invested",
        "projected_revenue_short": "Projected revenue",
        "top_products": "Top products",
        "top_products_hint": "Projected gross contribution before allocating shipping and taxes",
        "profit_per_unit": "Profit / unit",
        "units": "Units",
        "all_statuses": "All statuses",
        "all_refunds": "All orders",
        "refunded_only": "Refund only",
        "without_refund": "Without refund",
        "filter_status": "Status",
        "filter_refund": "Refund filter",
        "clear_filters": "Reset",
        "export_csv": "Export CSV",
        "backup_db": "Create backup",
        "open_data_folder": "Open data folder",
        "data_tools": "Data & backups",
        "data_tools_hint": "Export your table or create a database backup before major changes.",
        "backup_created": "Backup created:\n{path}",
        "export_created": "CSV file created:\n{path}",
        "accent_color": "Accent color",
        "accent_hint": "Changes the main button, active navigation and chart color.",
        "accent.violet": "Violet",
        "accent.cyan": "Cyan",
        "accent.emerald": "Emerald",
        "quick_actions": "Quick actions",
        "new_order_action": "Add new order",
        "open_orders": "Open orders",
        "open_analytics": "View analytics",
        "business_snapshot": "Current result",
        "business_snapshot_hint": "Projected net result across all active and completed orders",
        "projected_roi": "Projected ROI",
        "active_orders": "Active orders",
        "completed_orders": "Completed",
        "refund_total": "Refund total",
        "no_analytics": "Add at least one order and charts will appear here.",
        "status_breakdown": "Orders by status",
        "product_name_short": "Product",
        "profit": "Profit",
        "shortcut_new": "Ctrl+N — new order",
        "shortcut_search": "Ctrl+F — search orders",
        "shortcut_refresh": "F5 — refresh page",
        "shortcut_fullscreen": "F11 — fullscreen • Esc — exit",
        "keyboard_shortcuts": "Keyboard shortcuts",
        "saved_toast": "Order saved",
        "settings_saved_toast": "Settings applied",
        "autosave_settings": "Settings auto-save",
        "autosave_settings_hint": "Every change is saved automatically as soon as you select it.",
        "autosaved": "Saved automatically",
        "backup": "Backup",
        "export": "Export",
        "search": "Search",
        "order_count_label": "orders",
        "stock": "Stock",
        "sold_label": "Sold",
        "month_no_data": "No data",
        "products_page": "Products",
        "sales_page": "Sales",
        "refunds_page": "Refunds",
        "expenses_page": "Expenses",
        "products_title": "All products",
        "products_subtitle": "Complete inventory across all orders",
        "sales_title": "Sales",
        "sales_subtitle": "Sold units, revenue and profit",
        "refunds_title": "Refunds",
        "refunds_subtitle": "Orders with received or expected refunds",
        "expenses_title": "Expenses",
        "expenses_subtitle": "Purchases, shipping, taxes and other costs",
        "search_global": "Search products, orders, tracking...",
        "revenue_profit_trend": "Revenue & Profit Trend",
        "order_status_chart": "Order Status",
        "sold_vs_stock": "Sold vs In Stock",
        "weekly_sales": "Weekly Sales",
        "refund_overview": "Refund Overview",
        "top_profitable": "Top Profitable Products",
        "view_all": "View all",
        "no_refund": "No refund",
        "refund_orders": "Refund orders",
        "active_orders_short": "Active",
        "total_orders_short": "Orders",
        "revenue_short": "Revenue",
        "net_profit_short": "Net profit",
        "total_invested_short": "Invested",
        "roi_short": "ROI",
        "trend_hint": "Projected revenue and profit by purchase date",
        "weekly_hint": "Realized revenue by purchase weekday",
        "refund_sum": "Refund total",
        "buy_cost": "Purchase",
        "consumables": "Consumables",
        "other_costs": "Other",
        "order_cost": "Order cost",
        "unit_profit": "Profit / unit",
    },
    "ru": {
        "analytics": "Аналитика",
        "analytics_title": "Аналитика бизнеса",
        "analytics_subtitle": "Прибыль, оборот, запасы и лучшие товары",
        "overview": "Обзор",
        "refresh": "Обновить",
        "roi": "ROI",
        "avg_order": "Средний заказ",
        "refund_rate": "Доля Refund",
        "inventory_value": "Товаров в остатке",
        "units_total": "Всего единиц",
        "units_sold": "Продано единиц",
        "units_stock": "В остатке",
        "performance": "Финансовая динамика",
        "performance_hint": "Расходы и прогнозируемая выручка по месяцу покупки",
        "inventory_health": "Состояние запасов",
        "inventory_hint": "Сколько единиц уже продано и сколько осталось",
        "invested": "Расходы",
        "projected_revenue_short": "Прогноз выручки",
        "top_products": "Самые прибыльные товары",
        "top_products_hint": "Прогнозируемая валовая прибыль без распределения доставки и налогов",
        "profit_per_unit": "Прибыль / шт.",
        "units": "Единицы",
        "all_statuses": "Все статусы",
        "all_refunds": "Все заказы",
        "refunded_only": "Только Refund",
        "without_refund": "Без Refund",
        "filter_status": "Статус",
        "filter_refund": "Refund-фильтр",
        "clear_filters": "Сбросить",
        "export_csv": "Экспорт CSV",
        "backup_db": "Создать backup",
        "open_data_folder": "Открыть папку данных",
        "data_tools": "Данные и резервные копии",
        "data_tools_hint": "Экспортируй таблицу или создай резервную копию базы перед большими изменениями.",
        "backup_created": "Резервная копия создана:\n{path}",
        "export_created": "CSV-файл создан:\n{path}",
        "accent_color": "Акцентный цвет",
        "accent_hint": "Меняет основной цвет кнопок, активного меню и графиков.",
        "accent.violet": "Фиолетовый",
        "accent.cyan": "Голубой",
        "accent.emerald": "Зелёный",
        "quick_actions": "Быстрые действия",
        "new_order_action": "Добавить новый заказ",
        "open_orders": "Открыть заказы",
        "open_analytics": "Посмотреть аналитику",
        "business_snapshot": "Текущий результат",
        "business_snapshot_hint": "Прогнозируемый чистый результат по всем активным и завершённым заказам",
        "projected_roi": "Прогнозируемый ROI",
        "active_orders": "Активных заказов",
        "completed_orders": "Завершено",
        "refund_total": "Сумма Refund",
        "no_analytics": "Добавь хотя бы один заказ — здесь появятся графики и статистика.",
        "status_breakdown": "Заказы по статусу",
        "product_name_short": "Товар",
        "profit": "Прибыль",
        "shortcut_new": "Ctrl+N — новый заказ",
        "shortcut_search": "Ctrl+F — поиск заказов",
        "shortcut_refresh": "F5 — обновить страницу",
        "shortcut_fullscreen": "F11 — полный экран • Esc — выйти",
        "keyboard_shortcuts": "Горячие клавиши",
        "saved_toast": "Заказ сохранён",
        "settings_saved_toast": "Настройки применены",
        "autosave_settings": "Автосохранение настроек",
        "autosave_settings_hint": "Все изменения сохраняются автоматически сразу после выбора.",
        "autosaved": "Сохранено автоматически",
        "backup": "Backup",
        "export": "Экспорт",
        "search": "Поиск",
        "order_count_label": "заказов",
        "stock": "Остаток",
        "sold_label": "Продано",
        "month_no_data": "Нет данных",
        "products_page": "Товары",
        "sales_page": "Продажи",
        "refunds_page": "Refunds",
        "expenses_page": "Расходы",
        "products_title": "Все товары",
        "products_subtitle": "Полный список техники во всех заказах",
        "sales_title": "Продажи",
        "sales_subtitle": "Проданные единицы, выручка и прибыль",
        "refunds_title": "Refund",
        "refunds_subtitle": "Заказы с полученным или ожидаемым возвратом",
        "expenses_title": "Расходы",
        "expenses_subtitle": "Закупки, доставка, налоги и другие расходы",
        "search_global": "Поиск товаров, заказов, tracking...",
        "revenue_profit_trend": "Выручка и прибыль",
        "order_status_chart": "Статусы заказов",
        "sold_vs_stock": "Продано / в остатке",
        "weekly_sales": "Продажи по дням",
        "refund_overview": "Refund обзор",
        "top_profitable": "Самые прибыльные товары",
        "view_all": "Посмотреть всё",
        "no_refund": "Без Refund",
        "refund_orders": "Refund заказов",
        "active_orders_short": "Активные",
        "total_orders_short": "Заказов",
        "revenue_short": "Выручка",
        "net_profit_short": "Чистая прибыль",
        "total_invested_short": "Вложено",
        "roi_short": "ROI",
        "trend_hint": "Прогнозируемая выручка и прибыль по датам закупок",
        "weekly_hint": "Фактическая выручка по дню покупки",
        "refund_sum": "Сумма Refund",
        "buy_cost": "Закупка",
        "consumables": "Расходники",
        "other_costs": "Другое",
        "order_cost": "Себестоимость",
        "unit_profit": "Прибыль / шт.",
    },
}
for _lang, _extra in I18N_EXTRAS.items():
    I18N[_lang].update(_extra)

I18N_V7 = {
    "uk": {
        "app_subtitle": "Облік Amazon-замовлень і виплат",
        "dashboard_title": "Фінансовий огляд",
        "dashboard_subtitle": "Витрати → Refund → виплата скупу → чистий результат",
        "orders_subtitle": "Кілька товарів в одному замовленні, витрати, Refund і скуп",
        "analytics_subtitle": "Грошовий потік, виплати скупу, Refund і чистий результат",
        "tax": "Податок (старі дані)",
        "other_expenses": "Розхідники замовлення",
        "order_expenses": "Додаткові витрати",
        "expenses": "Витрачено",
        "revenue": "Скуп отримано",
        "revenue_short": "Скуп отримано",
        "revenue_received": "Отримано від скупу",
        "projected_revenue": "Очікувана виплата скупу",
        "projected_revenue_short": "Очікується від скупу",
        "total_invested": "Всього витрачено",
        "total_invested_short": "Витрачено",
        "profit_now": "Результат зараз",
        "projected_profit": "Фінальний результат",
        "metric_hint_invested": "Товари + доставка + розхідники",
        "metric_hint_revenue": "Фактично отримана виплата від скупу",
        "metric_hint_profit": "Refund + виплата скупу − усі витрати",
        "metric_hint_projected": "Результат після очікуваної виплати скупу",
        "buy_unit": "Ціна / шт.",
        "buy_price_unit": "Ціна товару / шт.",
        "consumables_unit": "Розхідники / шт. (старі дані)",
        "plan_sale": "Скуп %",
        "actual_sale": "Виплата скупу",
        "margin": "Скуп %",
        "refund_received": "Refund отримано",
        "refund_amount": "Фактично повернуто",
        "full_refund_fill": "= Сума товарів",
        "buyer_section": "Скуп",
        "buyer_percent": "Відсоток скупу",
        "buyer_expected": "Очікувана виплата",
        "buyer_sent": "Передано скупу",
        "buyer_sent_hint": "Познач, коли фізично передав/відправив замовлення скупу.",
        "buyer_paid": "Скуп виплатив",
        "buyer_amount": "Фактично отримано від скупу",
        "default_buyer_percent": "Стандартний % скупу",
        "default_buyer_percent_hint": "Автоматично підставляється у нові замовлення. Наприклад 70% = виплата 70% від суми товарів.",
        "expected_refund": "Очікуваний Refund",
        "projected_profit_hint": "Прогноз за умови повного Refund вартості товарів і очікуваної виплати скупу.",
        "purchase_total": "Сума товарів",
        "extra_costs": "Доставка + розхідники",
        "cash_outflow": "Витрачено всього",
        "after_refund_cost": "Витрати після Refund",
        "capital_tied": "Грошей в обороті",
        "buyer_discount": "Втрата на % скупу",
        "cash_inflow": "Отримано зараз",
        "workflow": "Етапи замовлення",
        "workflow_paid": "Замовлення оплачено",
        "workflow_refund": "Refund отримано",
        "workflow_buyer": "Передано / виплачено скупом",
        "buyer_payouts": "Виплати скупу",
        "refund_total_short": "Refund отримано",
        "sent_to_buyer": "Передано скупу",
        "not_sent": "На руках / в процесі",
        "sold_vs_stock": "Передано скупу / в процесі",
        "weekly_sales": "Виплати скупу за днями",
        "weekly_hint": "Фактичні виплати скупу за днем покупки",
        "revenue_profit_trend": "Надходження та результат",
        "trend_hint": "Refund + виплата скупу та чистий результат за замовленнями",
        "performance_hint": "Витрати та очікувані надходження за місяцем покупки",
        "inventory_health": "Передача скупу",
        "inventory_hint": "Скільки одиниць уже передано скупу і скільки ще в процесі",
        "top_products": "Товари за очікуваною виплатою",
        "top_profitable": "Товари за виплатою скупу",
        "top_products_hint": "Розрахунок від ціни товару та відсотка скупу",
        "sold_label": "Передано",
        "inventory_value": "Товарів у процесі",
        "status.Refund received": "Refund отримано",
        "status.Sent to buyer": "Передано скупу",
        "refunds_subtitle": "Облік фактично отриманих повернень/кредитів",
        "about_text": "Refaund Manager рахує витрати, фактично отриманий Refund, виплату скупу та чистий фінансовий результат по кожному замовленню.",
    },
    "en": {
        "app_subtitle": "Amazon orders & buyer payouts",
        "dashboard_subtitle": "Costs → refund → buyer payout → net result",
        "orders_subtitle": "Multiple products per order, costs, refunds and buyer payouts",
        "analytics_subtitle": "Cash flow, buyer payouts, refunds and net result",
        "other_expenses": "Order consumables",
        "order_expenses": "Additional costs",
        "expenses": "Cash out",
        "revenue": "Buyer received",
        "revenue_short": "Buyer received",
        "revenue_received": "Buyer payouts received",
        "projected_revenue": "Expected buyer payout",
        "projected_revenue_short": "Expected buyer payout",
        "total_invested": "Total cash out",
        "total_invested_short": "Cash out",
        "profit_now": "Result now",
        "projected_profit": "Final result",
        "metric_hint_invested": "Products + shipping + consumables",
        "metric_hint_revenue": "Buyer payouts actually received",
        "metric_hint_profit": "Refund + buyer payout − all costs",
        "metric_hint_projected": "Result after expected buyer payout",
        "buy_unit": "Price / unit",
        "buy_price_unit": "Product price / unit",
        "plan_sale": "Buyer %",
        "actual_sale": "Buyer payout",
        "margin": "Buyer %",
        "refund_amount": "Refund actually received",
        "full_refund_fill": "= Product total",
        "buyer_section": "Buyer",
        "buyer_percent": "Buyer payout percent",
        "buyer_expected": "Expected payout",
        "buyer_sent": "Sent to buyer",
        "buyer_sent_hint": "Mark this when the order has physically been handed/sent to the buyer.",
        "buyer_paid": "Buyer has paid",
        "buyer_amount": "Buyer payout received",
        "default_buyer_percent": "Default buyer payout %",
        "default_buyer_percent_hint": "Automatically used for new orders. Example: 70% means a 70% payout of the product total.",
        "expected_refund": "Expected refund",
        "projected_profit_hint": "Forecast assuming a full refund of product cost and the expected buyer payout.",
        "purchase_total": "Product total",
        "extra_costs": "Shipping + consumables",
        "cash_outflow": "Total cash out",
        "after_refund_cost": "Cost after refund",
        "capital_tied": "Capital tied up",
        "buyer_discount": "Buyer percentage loss",
        "cash_inflow": "Cash received now",
        "workflow": "Order workflow",
        "workflow_paid": "Order paid",
        "workflow_refund": "Refund received",
        "workflow_buyer": "Sent / paid by buyer",
        "buyer_payouts": "Buyer payouts",
        "refund_total_short": "Refund received",
        "sent_to_buyer": "Sent to buyer",
        "not_sent": "On hand / in progress",
        "sold_vs_stock": "Sent to buyer / in progress",
        "weekly_sales": "Buyer payouts by day",
        "weekly_hint": "Actual buyer payouts grouped by purchase weekday",
        "revenue_profit_trend": "Inflows & net result",
        "trend_hint": "Refund + buyer payout and net result by order date",
        "performance_hint": "Cash out and expected inflows grouped by purchase month",
        "inventory_health": "Buyer handoff",
        "inventory_hint": "Units already sent to the buyer versus still in progress",
        "top_products": "Products by expected payout",
        "top_profitable": "Products by buyer payout",
        "top_products_hint": "Calculated from product price and buyer payout percentage",
        "sold_label": "Sent",
        "inventory_value": "Products in progress",
        "status.Refund received": "Refund received",
        "status.Sent to buyer": "Sent to buyer",
        "refunds_subtitle": "Track refunds or credits actually received",
        "about_text": "Refaund Manager tracks costs, refunds actually received, buyer payouts and net financial result for every order.",
    },
    "ru": {
        "app_subtitle": "Учёт Amazon-заказов и выплат",
        "dashboard_subtitle": "Расходы → Refund → выплата скупа → чистый результат",
        "orders_subtitle": "Несколько товаров в заказе, расходы, Refund и скуп",
        "analytics_subtitle": "Денежный поток, выплаты скупа, Refund и чистый результат",
        "other_expenses": "Расходники заказа",
        "order_expenses": "Дополнительные расходы",
        "expenses": "Потрачено",
        "revenue": "Получено от скупа",
        "revenue_short": "Получено от скупа",
        "revenue_received": "Выплаты скупа",
        "projected_revenue": "Ожидаемая выплата скупа",
        "projected_revenue_short": "Ожидается от скупа",
        "total_invested": "Всего потрачено",
        "total_invested_short": "Потрачено",
        "profit_now": "Результат сейчас",
        "projected_profit": "Финальный результат",
        "metric_hint_invested": "Товары + доставка + расходники",
        "metric_hint_revenue": "Фактически полученная выплата от скупа",
        "metric_hint_profit": "Refund + выплата скупа − все расходы",
        "metric_hint_projected": "Результат после ожидаемой выплаты скупа",
        "buy_unit": "Цена / шт.",
        "buy_price_unit": "Цена товара / шт.",
        "plan_sale": "Скуп %",
        "actual_sale": "Выплата скупа",
        "margin": "Скуп %",
        "refund_amount": "Фактически возвращено",
        "full_refund_fill": "= Сумма товаров",
        "buyer_section": "Скуп",
        "buyer_percent": "Процент скупа",
        "buyer_expected": "Ожидаемая выплата",
        "buyer_sent": "Передано скупу",
        "buyer_sent_hint": "Отметь, когда заказ физически передан/отправлен скупу.",
        "buyer_paid": "Скуп выплатил",
        "buyer_amount": "Фактически получено от скупа",
        "default_buyer_percent": "Стандартный % скупа",
        "default_buyer_percent_hint": "Автоматически подставляется в новые заказы. Например 70% = выплата 70% от суммы товаров.",
        "expected_refund": "Ожидаемый Refund",
        "projected_profit_hint": "Прогноз при полном Refund стоимости товаров и ожидаемой выплате скупа.",
        "purchase_total": "Сумма товаров",
        "extra_costs": "Доставка + расходники",
        "cash_outflow": "Потрачено всего",
        "after_refund_cost": "Расходы после Refund",
        "capital_tied": "Денег в обороте",
        "buyer_discount": "Потеря на % скупа",
        "cash_inflow": "Получено сейчас",
        "workflow": "Этапы заказа",
        "workflow_paid": "Заказ оплачен",
        "workflow_refund": "Refund получен",
        "workflow_buyer": "Передано / выплачено скупом",
        "buyer_payouts": "Выплаты скупа",
        "refund_total_short": "Refund получен",
        "sent_to_buyer": "Передано скупу",
        "not_sent": "На руках / в процессе",
        "sold_vs_stock": "Передано скупу / в процессе",
        "weekly_sales": "Выплаты скупа по дням",
        "weekly_hint": "Фактические выплаты скупа по дню покупки",
        "revenue_profit_trend": "Поступления и результат",
        "trend_hint": "Refund + выплата скупа и чистый результат по заказам",
        "performance_hint": "Расходы и ожидаемые поступления по месяцу покупки",
        "inventory_health": "Передача скупу",
        "inventory_hint": "Сколько единиц передано скупу и сколько ещё в процессе",
        "top_products": "Товары по ожидаемой выплате",
        "top_profitable": "Товары по выплате скупа",
        "top_products_hint": "Расчёт от цены товара и процента скупа",
        "sold_label": "Передано",
        "inventory_value": "Товаров в процессе",
        "status.Refund received": "Refund получен",
        "status.Sent to buyer": "Передано скупу",
        "refunds_subtitle": "Учёт фактически полученных возвратов/кредитов",
        "about_text": "Refaund Manager считает расходы, фактически полученный Refund, выплату скупа и чистый финансовый результат по каждому заказу.",
    },
}
for _lang, _extra in I18N_V7.items():
    I18N[_lang].update(_extra)

I18N_V87 = {
    "uk": {
        "app_subtitle": "Облік замовлень і виплат",
        "carrier": "Служба доставки", "carrier_auto": "Автовизначення",
        "delivery_status": "Статус доставки", "delivery_last_update": "Останнє оновлення",
        "delivery_message": "Остання подія", "tracking_update": "Оновити трек",
        "tracking_update_all": "Оновити всі треки", "tracking_updating": "Оновлюю статуси доставки…",
        "tracking_updated": "Статуси доставки оновлено",
        "tracking_no_key": "Щоб статуси треків оновлювались автоматично, додай AfterShip API key у Налаштуваннях.",
        "tracking_no_number": "У замовленні немає трек-номера.",
        "tracking_error": "Не вдалося оновити tracking: {error}",
        "tracking_api": "Tracking API",
        "tracking_api_hint": "Один AfterShip API key дає статуси FedEx, UPS, USPS, DHL, DPD, Amazon Shipping, Meest та інших служб.",
        "aftership_api_key": "AfterShip API key",
        "aftership_api_key_hint": "Ключ зберігається тільки локально у базі цієї програми.",
        "tracking_refresh_interval": "Автооновлення tracking",
        "tracking_refresh_hint": "Поки програма відкрита, статуси активних треків оновлюються з вибраним інтервалом.",
        "minutes_15": "Кожні 15 хв", "minutes_30": "Кожні 30 хв", "minutes_60": "Кожні 60 хв",
        "tracking_connected": "Tracking підключено", "tracking_not_connected": "API key не вказаний",
        "delivery.Pending": "Очікує даних", "delivery.InfoReceived": "Дані отримано",
        "delivery.InTransit": "В дорозі", "delivery.OutForDelivery": "На доставці",
        "delivery.AttemptFail": "Невдала спроба", "delivery.Delivered": "Доставлено",
        "delivery.AvailableForPickup": "Готово до отримання", "delivery.Exception": "Проблема доставки",
        "delivery.Expired": "Tracking застарів", "delivery.unknown": "Статус ще не отримано",
        "tracking_sync_note": "Доставка автоматично змінює статус замовлення Замовлено → В дорозі → Отримано. Фінансові статуси Refund / Скуп не перезаписуються.",
    },
    "en": {
        "app_subtitle": "Orders & payouts tracker",
        "carrier": "Carrier", "carrier_auto": "Auto detect", "delivery_status": "Delivery status",
        "delivery_last_update": "Last update", "delivery_message": "Latest event",
        "tracking_update": "Update tracking", "tracking_update_all": "Update all tracking",
        "tracking_updating": "Updating delivery statuses…", "tracking_updated": "Delivery statuses updated",
        "tracking_no_key": "Add an AfterShip API key in Settings to enable automatic tracking updates.",
        "tracking_no_number": "This order has no tracking number.",
        "tracking_error": "Could not update tracking: {error}", "tracking_api": "Tracking API",
        "tracking_api_hint": "One AfterShip API key provides FedEx, UPS, USPS, DHL, DPD, Amazon Shipping, Meest and many other carriers.",
        "aftership_api_key": "AfterShip API key", "aftership_api_key_hint": "The key is stored only in this app's local database.",
        "tracking_refresh_interval": "Tracking auto refresh",
        "tracking_refresh_hint": "While the app is open, active tracking numbers refresh at the selected interval.",
        "minutes_15": "Every 15 min", "minutes_30": "Every 30 min", "minutes_60": "Every 60 min",
        "tracking_connected": "Tracking connected", "tracking_not_connected": "API key not set",
        "delivery.Pending": "Pending", "delivery.InfoReceived": "Info received", "delivery.InTransit": "In transit",
        "delivery.OutForDelivery": "Out for delivery", "delivery.AttemptFail": "Delivery attempt failed",
        "delivery.Delivered": "Delivered", "delivery.AvailableForPickup": "Available for pickup",
        "delivery.Exception": "Delivery exception", "delivery.Expired": "Tracking expired", "delivery.unknown": "No status yet",
        "tracking_sync_note": "Delivery can automatically move an order Ordered → In transit → Received. Refund / buyer financial statuses are never overwritten.",
    },
    "ru": {
        "app_subtitle": "Учёт заказов и выплат",
        "carrier": "Служба доставки", "carrier_auto": "Автоопределение", "delivery_status": "Статус доставки",
        "delivery_last_update": "Последнее обновление", "delivery_message": "Последнее событие",
        "tracking_update": "Обновить трек", "tracking_update_all": "Обновить все треки",
        "tracking_updating": "Обновляю статусы доставки…", "tracking_updated": "Статусы доставки обновлены",
        "tracking_no_key": "Чтобы треки обновлялись автоматически, добавь AfterShip API key в Настройках.",
        "tracking_no_number": "В заказе нет трек-номера.", "tracking_error": "Не удалось обновить tracking: {error}",
        "tracking_api": "Tracking API",
        "tracking_api_hint": "Один AfterShip API key дает статусы FedEx, UPS, USPS, DHL, DPD, Amazon Shipping, Meest и других служб.",
        "aftership_api_key": "AfterShip API key", "aftership_api_key_hint": "Ключ хранится только локально в базе этой программы.",
        "tracking_refresh_interval": "Автообновление tracking",
        "tracking_refresh_hint": "Пока программа открыта, активные треки обновляются с выбранным интервалом.",
        "minutes_15": "Каждые 15 мин", "minutes_30": "Каждые 30 мин", "minutes_60": "Каждые 60 мин",
        "tracking_connected": "Tracking подключен", "tracking_not_connected": "API key не указан",
        "delivery.Pending": "Ожидает данных", "delivery.InfoReceived": "Данные получены", "delivery.InTransit": "В дороге",
        "delivery.OutForDelivery": "На доставке", "delivery.AttemptFail": "Неудачная попытка",
        "delivery.Delivered": "Доставлено", "delivery.AvailableForPickup": "Готово к получению",
        "delivery.Exception": "Проблема доставки", "delivery.Expired": "Tracking устарел", "delivery.unknown": "Статус еще не получен",
        "tracking_sync_note": "Доставка автоматически меняет статус заказа Заказано → В дороге → Получено. Финансовые статусы Refund / Скуп не перезаписываются.",
    },
}
for _lang, _extra in I18N_V87.items():
    I18N[_lang].update(_extra)

I18N_V88 = {
    "uk": {
        "tracking_check_connection": "Перевірити підключення",
        "tracking_checking": "Перевіряю підключення…",
        "tracking_connected_ok": "Підключено",
        "tracking_connection_error": "Помилка підключення",
        "tracking_not_verified": "Не перевірено",
        "tracking_enter_key": "Введи API key перед перевіркою.",
        "remember_api_key": "Зберігати API key на цьому ПК",
        "remember_api_key_hint": "Якщо вимкнути — ключ працюватиме тільки до закриття програми і не буде записаний у локальну базу.",
        "aftership_api_key_hint": "Ключ використовується тільки для Tracking API. Збереження на цьому ПК можна ввімкнути або вимкнути нижче.",
    },
    "en": {
        "tracking_check_connection": "Check connection",
        "tracking_checking": "Checking connection…",
        "tracking_connected_ok": "Connected",
        "tracking_connection_error": "Connection error",
        "tracking_not_verified": "Not verified",
        "tracking_enter_key": "Enter an API key before checking it.",
        "remember_api_key": "Save API key on this PC",
        "remember_api_key_hint": "If disabled, the key works only until the app is closed and is not written to the local database.",
        "aftership_api_key_hint": "The key is used only for the Tracking API. You can choose below whether to save it on this PC.",
    },
    "ru": {
        "tracking_check_connection": "Проверить подключение",
        "tracking_checking": "Проверяю подключение…",
        "tracking_connected_ok": "Подключено",
        "tracking_connection_error": "Ошибка подключения",
        "tracking_not_verified": "Не проверено",
        "tracking_enter_key": "Введи API key перед проверкой.",
        "remember_api_key": "Сохранять API key на этом ПК",
        "remember_api_key_hint": "Если выключить — ключ будет работать только до закрытия программы и не запишется в локальную базу.",
        "aftership_api_key_hint": "Ключ используется только для Tracking API. Ниже можно выбрать, сохранять ли его на этом ПК.",
    },
}
for _lang, _extra in I18N_V88.items():
    I18N[_lang].update(_extra)


I18N_V816 = {
    "uk": {
        "instructions": "Інструкція",
        "instructions_title": "Інструкція",
        "instructions_subtitle": "Як користуватися Refaund Manager — від створення замовлення до фінального результату",
        "guide_quick_title": "Як працює програма",
        "guide_quick_text": "Замовлення → товари та витрати → доставка → фактично отриманий Refund → передача скупу → виплата скупу → чистий результат.",
        "guide_phase1_title": "Початок — замовлення та витрати",
        "guide_phase1_subtitle": "Створи замовлення, додай усі товари та зафіксуй реальні витрати.",
        "guide_phase2_title": "Refund і передача скупу",
        "guide_phase2_subtitle": "Відмічай тільки фактичні події: отриманий Refund, відсоток і передачу товарів.",
        "guide_phase3_title": "Tracking, виплата та результат",
        "guide_phase3_subtitle": "Стеж за доставкою, зафіксуй фактичну виплату та контролюй фінальний результат.",
        "guide_formula_title": "Формула результату",
        "guide_formula_now": "Результат зараз = отриманий Refund + фактична виплата скупу − усі витрати",
        "guide_formula_final": "Фінальний результат = Refund + очікувана виплата скупу − усі витрати",
        "guide_formula_example": "Приклад: товари $900 + розхідники $200 + доставка $50, Refund $900, скуп 70% = $630 → фінальний результат $380.",
        "guide_step1_title": "1. Створи замовлення",
        "guide_step1_text": "Натисни «+ Нове замовлення». Вкажи магазин, Order ID і дату покупки. Якщо вже є трек — вибери службу доставки та встав Tracking Number.",
        "guide_step2_title": "2. Додай товари",
        "guide_step2_text": "У одному замовленні можна додати 1, 2, 3 або більше товарів. Для кожного вкажи назву, кількість і ціну за одиницю. Сума товарів рахується автоматично.",
        "guide_step3_title": "3. Додай витрати",
        "guide_step3_text": "Вкажи доставку та розхідники замовлення. Програма покаже повну суму грошей, яку ти витратив: товари + доставка + розхідники.",
        "guide_step4_title": "4. Відміть Refund тільки після отримання",
        "guide_step4_text": "Коли повернення фактично прийшло, увімкни «Refund отримано» і вкажи суму. Для повного повернення можна підставити суму всіх товарів. До фактичного отримання Refund не додається до результату зараз.",
        "guide_step5_title": "5. Вкажи % скупу",
        "guide_step5_text": "Наприклад, 70% означає: зі суми товарів $900 очікувана виплата скупу = $630. Стандартний відсоток можна змінити в Налаштуваннях.",
        "guide_step6_title": "6. Передача та виплата скупу",
        "guide_step6_text": "Коли відправив товар — познач «Передано скупу». Коли гроші реально отримані — познач «Скуп виплатив» і вкажи фактичну суму. Тоді вона потрапить у результат зараз.",
        "guide_step7_title": "7. Tracking доставки",
        "guide_step7_text": "У Налаштуваннях додай AfterShip API key і натисни «Перевірити підключення». У замовленні вибери FedEx, UPS, USPS, DHL, DPD, Amazon Shipping, Meest або іншу підтримувану службу та додай трек. Програма оновлює статус доставки автоматично.",
        "guide_step8_title": "8. Як рахується результат",
        "guide_step8_text": "Результат зараз = фактично отриманий Refund + фактично отримана виплата скупу − усі витрати. Фінальний результат окремо показує прогноз після очікуваної виплати скупу.",
        "guide_step9_title": "9. Аналітика та резервні копії",
        "guide_step9_text": "На Головній бачиш загальні витрати, надходження та результат. В Аналітиці — графіки й статистику. У Налаштуваннях можна створити backup бази та експортувати CSV.",
        "guide_shortcuts_title": "Гарячі клавіші",
        "guide_shortcuts_text": "Ctrl+N — нове замовлення  •  Ctrl+F — пошук  •  F5 — оновити  •  F11 — повний екран  •  Esc — вийти з повного екрана",
        "guide_tip_title": "Порада",
        "guide_tip_text": "Заповнюй статуси тільки після фактичної події — наприклад Refund після зарахування коштів, а виплату скупу після отримання грошей. Так «Результат зараз» завжди буде точним.",
    },
    "en": {
        "instructions": "Guide",
        "instructions_title": "Guide",
        "instructions_subtitle": "How to use Refaund Manager — from creating an order to the final result",
        "guide_quick_title": "How the app works",
        "guide_quick_text": "Order → products and costs → delivery → refund actually received → send to buyer → buyer payout → net result.",
        "guide_phase1_title": "Start — order and costs",
        "guide_phase1_subtitle": "Create the order, add every product and record the real costs.",
        "guide_phase2_title": "Refund and buyer handoff",
        "guide_phase2_subtitle": "Record only real events: received refund, buyer percentage and product handoff.",
        "guide_phase3_title": "Tracking, payout and result",
        "guide_phase3_subtitle": "Track delivery, record the actual payout and monitor the final result.",
        "guide_formula_title": "Result formula",
        "guide_formula_now": "Result now = received refund + actual buyer payout − all costs",
        "guide_formula_final": "Final result = refund + expected buyer payout − all costs",
        "guide_formula_example": "Example: products $900 + consumables $200 + shipping $50, refund $900, buyer 70% = $630 → final result $380.",
        "guide_step1_title": "1. Create an order",
        "guide_step1_text": "Click “+ New order”. Enter the store, Order ID and purchase date. If you already have tracking, choose the carrier and add the Tracking Number.",
        "guide_step2_title": "2. Add products",
        "guide_step2_text": "One order can contain 1, 2, 3 or more products. For each product enter its name, quantity and unit price. The product total is calculated automatically.",
        "guide_step3_title": "3. Add costs",
        "guide_step3_text": "Enter shipping and order consumables. The app shows your full cash out: products + shipping + consumables.",
        "guide_step4_title": "4. Mark refund only after it is received",
        "guide_step4_text": "When the refund actually arrives, enable “Refund received” and enter the amount. For a full refund you can fill the total product cost. Until it is actually received, it is not added to Result now.",
        "guide_step5_title": "5. Set the buyer %",
        "guide_step5_text": "For example, 70% means that a $900 product total gives an expected buyer payout of $630. You can change the default percentage in Settings.",
        "guide_step6_title": "6. Send to buyer and record payout",
        "guide_step6_text": "When the products are sent, mark “Sent to buyer”. When you actually receive the money, mark “Buyer has paid” and enter the actual payout. It then appears in Result now.",
        "guide_step7_title": "7. Delivery tracking",
        "guide_step7_text": "In Settings add your AfterShip API key and click “Check connection”. In an order choose FedEx, UPS, USPS, DHL, DPD, Amazon Shipping, Meest or another supported carrier and add tracking. The app can refresh delivery status automatically.",
        "guide_step8_title": "8. How the result is calculated",
        "guide_step8_text": "Result now = refund actually received + buyer payout actually received − all costs. Final result separately shows the forecast after the expected buyer payout.",
        "guide_step9_title": "9. Analytics and backups",
        "guide_step9_text": "Dashboard shows total cash out, inflows and result. Analytics contains charts and statistics. Settings lets you create a database backup and export CSV.",
        "guide_shortcuts_title": "Keyboard shortcuts",
        "guide_shortcuts_text": "Ctrl+N — new order  •  Ctrl+F — search  •  F5 — refresh  •  F11 — fullscreen  •  Esc — exit fullscreen",
        "guide_tip_title": "Tip",
        "guide_tip_text": "Update a status only after the event actually happens — for example, refund after the money arrives and buyer payout after payment is received. This keeps Result now accurate.",
    },
    "ru": {
        "instructions": "Инструкция",
        "instructions_title": "Инструкция",
        "instructions_subtitle": "Как пользоваться Refaund Manager — от создания заказа до финального результата",
        "guide_quick_title": "Как работает программа",
        "guide_quick_text": "Заказ → товары и расходы → доставка → фактически полученный Refund → передача скупу → выплата скупа → чистый результат.",
        "guide_phase1_title": "Начало — заказ и расходы",
        "guide_phase1_subtitle": "Создай заказ, добавь все товары и зафиксируй реальные расходы.",
        "guide_phase2_title": "Refund и передача скупу",
        "guide_phase2_subtitle": "Отмечай только фактические события: полученный Refund, процент и передачу товаров.",
        "guide_phase3_title": "Tracking, выплата и результат",
        "guide_phase3_subtitle": "Следи за доставкой, зафиксируй фактическую выплату и контролируй финальный результат.",
        "guide_formula_title": "Формула результата",
        "guide_formula_now": "Результат сейчас = полученный Refund + фактическая выплата скупа − все расходы",
        "guide_formula_final": "Финальный результат = Refund + ожидаемая выплата скупа − все расходы",
        "guide_formula_example": "Пример: товары $900 + расходники $200 + доставка $50, Refund $900, скуп 70% = $630 → финальный результат $380.",
        "guide_step1_title": "1. Создай заказ",
        "guide_step1_text": "Нажми «+ Новое замовлення / New order». Укажи магазин, Order ID и дату покупки. Если трек уже есть — выбери службу доставки и добавь Tracking Number.",
        "guide_step2_title": "2. Добавь товары",
        "guide_step2_text": "В одном заказе можно добавить 1, 2, 3 или больше товаров. Для каждого укажи название, количество и цену за единицу. Сумма товаров считается автоматически.",
        "guide_step3_title": "3. Добавь расходы",
        "guide_step3_text": "Укажи доставку и расходники заказа. Программа покажет полную сумму расходов: товары + доставка + расходники.",
        "guide_step4_title": "4. Отмечай Refund только после получения",
        "guide_step4_text": "Когда возврат фактически поступил, включи «Refund получен» и укажи сумму. Для полного возврата можно подставить сумму всех товаров. До фактического получения Refund не добавляется в текущий результат.",
        "guide_step5_title": "5. Укажи % скупа",
        "guide_step5_text": "Например, 70% означает: при сумме товаров $900 ожидаемая выплата скупа = $630. Стандартный процент можно изменить в Настройках.",
        "guide_step6_title": "6. Передача и выплата скупа",
        "guide_step6_text": "Когда отправил товар — отметь «Передано скупу». Когда деньги реально получены — отметь «Скуп выплатил» и введи фактическую сумму. После этого она попадёт в текущий результат.",
        "guide_step7_title": "7. Tracking доставки",
        "guide_step7_text": "В Настройках добавь AfterShip API key и нажми «Проверить подключение». В заказе выбери FedEx, UPS, USPS, DHL, DPD, Amazon Shipping, Meest или другую поддерживаемую службу и добавь трек. Программа может автоматически обновлять статус доставки.",
        "guide_step8_title": "8. Как считается результат",
        "guide_step8_text": "Результат сейчас = фактически полученный Refund + фактически полученная выплата скупа − все расходы. Финальный результат отдельно показывает прогноз после ожидаемой выплаты скупа.",
        "guide_step9_title": "9. Аналитика и резервные копии",
        "guide_step9_text": "На Главной видны общие расходы, поступления и результат. В Аналитике — графики и статистика. В Настройках можно создать backup базы и экспортировать CSV.",
        "guide_shortcuts_title": "Горячие клавиши",
        "guide_shortcuts_text": "Ctrl+N — новый заказ  •  Ctrl+F — поиск  •  F5 — обновить  •  F11 — полный экран  •  Esc — выйти из полного экрана",
        "guide_tip_title": "Совет",
        "guide_tip_text": "Меняй статус только после фактического события — например Refund после зачисления денег, а выплату скупа после получения оплаты. Тогда «Результат сейчас» всегда будет точным.",
    },
}
for _lang, _extra in I18N_V816.items():
    I18N[_lang].update(_extra)

I18N_V819 = {
 "uk": {
  "category":"Категорія","category.Phones":"Телефони","category.Computers":"Комп’ютери / ноутбуки","category.Tablets":"Планшети","category.Audio":"Навушники / аудіо","category.Gaming":"Ігрова техніка","category.Smart Home":"Розумний дім","category.Cameras":"Камери","category.Accessories":"Аксесуари","category.Other":"Інше",
  "hide_amounts":"Сховати суми","show_amounts":"Показати суми","amounts_hidden":"Суми приховано",
  "theme":"Тема","theme_hint":"Перемикає всю програму між темним і світлим оформленням.","theme.dark":"Темна","theme.light":"Світла",
  "system_tray":"Системний трей","system_tray_hint":"При закритті вікно ховається в трей, а tracking може продовжувати оновлюватись.","tray_open":"Відкрити Refaund Manager","tray_hide":"Сховати вікно","tray_exit":"Вийти","tray_running":"Програма продовжує працювати у системному треї","tray_unavailable":"Системний трей недоступний. Не вдалося підключити pystray і Pillow.","tray_installing":"Встановлюю компоненти системного трею…","tray_installed":"Системний трей підключено ✓",
  "updates":"Оновлення","updates_hint":"Перевірка нової версії програми.","update_source":"URL manifest оновлень","update_source_hint":"Встав raw JSON URL. Якщо порожньо — програма перевіряє latest_version.json біля себе.","check_updates":"Перевірити оновлення","checking_updates":"Перевіряю оновлення…","update_available":"Доступна нова версія {version}","up_to_date":"У тебе актуальна версія {version}","update_error":"Не вдалося перевірити оновлення: {error}","open_update":"Відкрити сторінку оновлення","current_version":"Поточна версія: {version}"
 },
 "en": {
  "category":"Category","category.Phones":"Phones","category.Computers":"Computers / laptops","category.Tablets":"Tablets","category.Audio":"Headphones / audio","category.Gaming":"Gaming","category.Smart Home":"Smart home","category.Cameras":"Cameras","category.Accessories":"Accessories","category.Other":"Other",
  "hide_amounts":"Hide amounts","show_amounts":"Show amounts","amounts_hidden":"Amounts hidden",
  "theme":"Theme","theme_hint":"Switches the whole app between dark and light appearance.","theme.dark":"Dark","theme.light":"Light",
  "system_tray":"System tray","system_tray_hint":"Closing the window hides it to tray while tracking can keep refreshing.","tray_open":"Open Refaund Manager","tray_hide":"Hide window","tray_exit":"Exit","tray_running":"The app is still running in the system tray","tray_unavailable":"System tray unavailable. pystray and Pillow could not be loaded.","tray_installing":"Installing system tray components…","tray_installed":"System tray connected ✓",
  "updates":"Updates","updates_hint":"Check for a newer app version.","update_source":"Update manifest URL","update_source_hint":"Paste a raw JSON URL. If empty, the app checks latest_version.json next to itself.","check_updates":"Check for updates","checking_updates":"Checking for updates…","update_available":"New version {version} is available","up_to_date":"You are up to date: {version}","update_error":"Could not check for updates: {error}","open_update":"Open update page","current_version":"Current version: {version}"
 },
 "ru": {
  "category":"Категория","category.Phones":"Телефоны","category.Computers":"Компьютеры / ноутбуки","category.Tablets":"Планшеты","category.Audio":"Наушники / аудио","category.Gaming":"Игровая техника","category.Smart Home":"Умный дом","category.Cameras":"Камеры","category.Accessories":"Аксессуары","category.Other":"Другое",
  "hide_amounts":"Скрыть суммы","show_amounts":"Показать суммы","amounts_hidden":"Суммы скрыты",
  "theme":"Тема","theme_hint":"Переключает всю программу между тёмным и светлым оформлением.","theme.dark":"Тёмная","theme.light":"Светлая",
  "system_tray":"Системный трей","system_tray_hint":"При закрытии окно прячется в трей, а tracking может продолжать обновляться.","tray_open":"Открыть Refaund Manager","tray_hide":"Скрыть окно","tray_exit":"Выйти","tray_running":"Программа продолжает работать в системном трее","tray_unavailable":"Системный трей недоступен. Не удалось подключить pystray и Pillow.","tray_installing":"Устанавливаю компоненты системного трея…","tray_installed":"Системный трей подключен ✓",
  "updates":"Обновления","updates_hint":"Проверка новой версии программы.","update_source":"URL manifest обновлений","update_source_hint":"Вставь raw JSON URL. Если пусто — программа проверяет latest_version.json рядом с собой.","check_updates":"Проверить обновления","checking_updates":"Проверяю обновления…","update_available":"Доступна новая версия {version}","up_to_date":"У тебя актуальная версия {version}","update_error":"Не удалось проверить обновления: {error}","open_update":"Открыть страницу обновления","current_version":"Текущая версия: {version}"
 }
}
for _lang, _extra in I18N_V819.items():
    I18N[_lang].update(_extra)

I18N_V822 = {
    "uk": {"all_categories": "Усі категорії", "filter_category": "Категорія"},
    "en": {"all_categories": "All categories", "filter_category": "Category"},
    "ru": {"all_categories": "Все категории", "filter_category": "Категория"},
}
for _lang, _extra in I18N_V822.items():
    I18N[_lang].update(_extra)


I18N_V826 = {
    "uk": {
        "auto_update_title": "Доступне оновлення",
        "auto_update_body": "Доступна нова версія Refaund Manager {version}.\n\nОновити програму зараз?",
        "auto_update_now": "Оновити",
        "auto_update_later": "Пізніше",
        "auto_update_notes": "Що нового: {notes}",
    },
    "en": {
        "auto_update_title": "Update available",
        "auto_update_body": "A newer Refaund Manager version {version} is available.\n\nUpdate now?",
        "auto_update_now": "Update",
        "auto_update_later": "Later",
        "auto_update_notes": "What’s new: {notes}",
    },
    "ru": {
        "auto_update_title": "Доступно обновление",
        "auto_update_body": "Доступна новая версия Refaund Manager {version}.\n\nОбновить программу сейчас?",
        "auto_update_now": "Обновить",
        "auto_update_later": "Позже",
        "auto_update_notes": "Что нового: {notes}",
    },
}
for _lang, _extra in I18N_V826.items():
    I18N[_lang].update(_extra)


def tr(lang, key, **kwargs):
    lang = lang if lang in I18N else "uk"
    text = I18N[lang].get(key, I18N["en"].get(key, key))
    return text.format(**kwargs) if kwargs else text


def D(value=0):
    """Safe Decimal conversion."""
    try:
        if value is None or value == "":
            return Decimal("0")
        return Decimal(str(value).replace(",", "."))
    except (InvalidOperation, ValueError):
        return Decimal("0")


def money(value, currency="$", decimals=2):
    v = D(value)
    return f"{currency}{v:,.{decimals}f}"


def _aftership_request(api_key, method, path, query=None, body=None, timeout=14):
    """Small dependency-free AfterShip client used by the desktop app."""
    if not api_key:
        raise RuntimeError("AfterShip API key is empty")
    url = AFTERSHIP_BASE + path
    if query:
        url += "?" + urllib.parse.urlencode(query)
    payload = None if body is None else json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=payload, method=method.upper())
    req.add_header("as-api-key", api_key.strip())
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            payload_err = json.loads(raw) if raw else {}
            meta = payload_err.get("meta") or {}
            message = meta.get("message") or meta.get("type") or raw
        except Exception:
            message = raw or str(exc)
        raise RuntimeError(f"HTTP {exc.code}: {message}") from None
    except urllib.error.URLError as exc:
        raise RuntimeError(str(getattr(exc, "reason", exc))) from None


def verify_aftership_key(api_key):
    """Validate the key without creating or modifying a tracking record."""
    _aftership_request(api_key, "GET", "/trackings", query={"limit": 1}, timeout=12)
    return True


def _extract_tracking_objects(payload):
    data = payload.get("data", payload) if isinstance(payload, dict) else payload
    if isinstance(data, dict):
        if isinstance(data.get("tracking"), dict):
            return [data["tracking"]]
        if isinstance(data.get("trackings"), list):
            return data["trackings"]
        if "tracking_number" in data:
            return [data]
    if isinstance(data, list):
        return data
    return []


def _normalize_tracking(tracking):
    checkpoints = tracking.get("checkpoints") or []
    last = checkpoints[-1] if checkpoints else {}
    tag = tracking.get("tag") or last.get("tag") or "Pending"
    message = tracking.get("subtag_message") or last.get("subtag_message") or last.get("message") or ""
    updated = tracking.get("updated_at") or last.get("checkpoint_time") or last.get("created_at") or ""
    slug = tracking.get("slug") or last.get("slug") or ""
    return {
        "aftership_tracking_id": tracking.get("id") or "", "carrier_slug": slug,
        "tracking_status": tag, "tracking_substatus": tracking.get("subtag") or last.get("subtag") or "",
        "tracking_message": message, "tracking_updated_at": updated,
        "courier_tracking_link": tracking.get("courier_tracking_link") or "",
    }


def aftership_track(api_key, tracking_number, carrier_slug="", title=""):
    query = {"tracking_numbers": tracking_number, "fields": "title,order_id,tag,checkpoints"}
    if carrier_slug:
        query["slug"] = carrier_slug
    payload = _aftership_request(api_key, "GET", "/trackings", query=query)
    objects = _extract_tracking_objects(payload)
    if objects:
        return _normalize_tracking(objects[0])
    body = {"tracking_number": tracking_number}
    if carrier_slug:
        body["slug"] = carrier_slug
    if title:
        body["title"] = title
    payload = _aftership_request(api_key, "POST", "/trackings", body=body)
    objects = _extract_tracking_objects(payload)
    if not objects:
        payload = _aftership_request(api_key, "GET", "/trackings", query=query)
        objects = _extract_tracking_objects(payload)
    if not objects:
        raise RuntimeError("Tracking was created but no tracking object was returned")
    return _normalize_tracking(objects[0])


def _hex_to_rgb(color):
    color = color.lstrip("#")
    return tuple(int(color[i:i + 2], 16) for i in (0, 2, 4))


def _rgb_to_hex(rgb):
    return "#" + "".join(f"{max(0, min(255, int(v))):02x}" for v in rgb)


def blend_color(a, b, t):
    ar, ag, ab = _hex_to_rgb(a)
    br, bg, bb = _hex_to_rgb(b)
    return _rgb_to_hex((ar + (br - ar) * t, ag + (bg - ag) * t, ab + (bb - ab) * t))


class Database:
    def __init__(self, path):
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.create_schema()

    def _ensure_column(self, table, column, definition):
        cols = {row["name"] for row in self.conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if column not in cols:
            self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")

    def create_schema(self):
        cur = self.conn.cursor()
        cur.executescript(
            """
            PRAGMA foreign_keys = ON;

            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                amazon_order_id TEXT NOT NULL,
                store TEXT DEFAULT '',
                purchase_date TEXT,
                tracking TEXT,
                carrier_slug TEXT DEFAULT '',
                tracking_status TEXT DEFAULT '',
                tracking_substatus TEXT DEFAULT '',
                tracking_message TEXT DEFAULT '',
                tracking_updated_at TEXT DEFAULT '',
                aftership_tracking_id TEXT DEFAULT '',
                courier_tracking_link TEXT DEFAULT '',
                status TEXT DEFAULT 'Ordered',
                shipping REAL DEFAULT 0,
                tax REAL DEFAULT 0,
                other_expenses REAL DEFAULT 0,
                refunded INTEGER DEFAULT 0,
                refund_amount REAL DEFAULT 0,
                buyer_percent REAL DEFAULT 70,
                buyer_sent INTEGER DEFAULT 0,
                buyer_paid INTEGER DEFAULT 0,
                buyer_amount REAL DEFAULT 0,
                notes TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                qty INTEGER DEFAULT 1,
                sold_qty INTEGER DEFAULT 0,
                buy_price REAL DEFAULT 0,
                consumables REAL DEFAULT 0,
                planned_sale REAL DEFAULT 0,
                actual_sale REAL DEFAULT 0,
                status TEXT DEFAULT 'Ordered',
                serial_imei TEXT,
                category TEXT DEFAULT 'Other',
                notes TEXT,
                FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            """
        )
        # Automatic migration for databases created by V1–V6.
        self._ensure_column("orders", "store", "TEXT DEFAULT ''")
        self._ensure_column("orders", "buyer_percent", "REAL DEFAULT 70")
        self._ensure_column("orders", "buyer_sent", "INTEGER DEFAULT 0")
        self._ensure_column("orders", "buyer_paid", "INTEGER DEFAULT 0")
        self._ensure_column("orders", "buyer_amount", "REAL DEFAULT 0")
        self._ensure_column("orders", "carrier_slug", "TEXT DEFAULT ''")
        self._ensure_column("orders", "tracking_status", "TEXT DEFAULT ''")
        self._ensure_column("orders", "tracking_substatus", "TEXT DEFAULT ''")
        self._ensure_column("orders", "tracking_message", "TEXT DEFAULT ''")
        self._ensure_column("orders", "tracking_updated_at", "TEXT DEFAULT ''")
        self._ensure_column("orders", "aftership_tracking_id", "TEXT DEFAULT ''")
        self._ensure_column("orders", "courier_tracking_link", "TEXT DEFAULT ''")
        self._ensure_column("items", "category", "TEXT DEFAULT 'Other'")
        self.conn.commit()

    def fetch_orders(self):
        return self.conn.execute("SELECT * FROM orders ORDER BY id DESC").fetchall()

    def get_order(self, order_id):
        return self.conn.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()

    def get_items(self, order_id):
        return self.conn.execute("SELECT * FROM items WHERE order_id=? ORDER BY id", (order_id,)).fetchall()

    def add_order(self, data, items):
        cur = self.conn.cursor()
        cur.execute(
            """
            INSERT INTO orders (amazon_order_id, store, purchase_date, tracking, carrier_slug, tracking_status,
                                tracking_substatus, tracking_message, tracking_updated_at, aftership_tracking_id,
                                courier_tracking_link, status, shipping, tax, other_expenses, refunded, refund_amount,
                                buyer_percent, buyer_sent, buyer_paid, buyer_amount, notes, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """,
            (
                data["amazon_order_id"], data.get("store", ""), data["purchase_date"], data["tracking"],
                data.get("carrier_slug", ""), data.get("tracking_status", ""), data.get("tracking_substatus", ""),
                data.get("tracking_message", ""), data.get("tracking_updated_at", ""),
                data.get("aftership_tracking_id", ""), data.get("courier_tracking_link", ""), data["status"],
                float(D(data.get("shipping", 0))), float(D(data.get("tax", 0))),
                float(D(data.get("other_expenses", 0))), int(data.get("refunded", 0)),
                float(D(data.get("refund_amount", 0))), float(D(data.get("buyer_percent", 70))),
                int(data.get("buyer_sent", 0)), int(data.get("buyer_paid", 0)),
                float(D(data.get("buyer_amount", 0))), data.get("notes", "")
            )
        )
        order_id = cur.lastrowid
        self._insert_items(cur, order_id, items)
        self.conn.commit()
        return order_id

    def update_order(self, order_id, data, items):
        cur = self.conn.cursor()
        cur.execute(
            """
            UPDATE orders
            SET amazon_order_id=?, store=?, purchase_date=?, tracking=?, carrier_slug=?, tracking_status=?,
                tracking_substatus=?, tracking_message=?, tracking_updated_at=?, aftership_tracking_id=?,
                courier_tracking_link=?, status=?, shipping=?, tax=?, other_expenses=?, refunded=?, refund_amount=?,
                buyer_percent=?, buyer_sent=?, buyer_paid=?, buyer_amount=?, notes=?, updated_at=CURRENT_TIMESTAMP
            WHERE id=?
            """,
            (
                data["amazon_order_id"], data.get("store", ""), data["purchase_date"], data["tracking"],
                data.get("carrier_slug", ""), data.get("tracking_status", ""), data.get("tracking_substatus", ""),
                data.get("tracking_message", ""), data.get("tracking_updated_at", ""),
                data.get("aftership_tracking_id", ""), data.get("courier_tracking_link", ""), data["status"],
                float(D(data.get("shipping", 0))), float(D(data.get("tax", 0))),
                float(D(data.get("other_expenses", 0))), int(data.get("refunded", 0)),
                float(D(data.get("refund_amount", 0))), float(D(data.get("buyer_percent", 70))),
                int(data.get("buyer_sent", 0)), int(data.get("buyer_paid", 0)),
                float(D(data.get("buyer_amount", 0))), data.get("notes", ""), order_id
            )
        )
        cur.execute("DELETE FROM items WHERE order_id=?", (order_id,))
        self._insert_items(cur, order_id, items)
        self.conn.commit()

    def _insert_items(self, cur, order_id, items):
        for item in items:
            cur.execute(
                """
                INSERT INTO items (order_id, name, qty, sold_qty, buy_price, consumables,
                                   planned_sale, actual_sale, status, serial_imei, category, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    order_id, item["name"], int(item.get("qty", 1)), int(item.get("sold_qty", 0)),
                    float(D(item.get("buy_price", 0))), float(D(item.get("consumables", 0))),
                    float(D(item.get("planned_sale", 0))), float(D(item.get("actual_sale", 0))),
                    item.get("status", "Ordered"), item.get("serial_imei", ""), item.get("category", "Other"), item.get("notes", "")
                )
            )

    def update_tracking(self, order_id, tracking_data, order_status=None):
        self.conn.execute(
            """UPDATE orders SET carrier_slug=?, tracking_status=?, tracking_substatus=?, tracking_message=?,
                       tracking_updated_at=?, aftership_tracking_id=?, courier_tracking_link=?,
                       status=COALESCE(?, status), updated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (tracking_data.get("carrier_slug", ""), tracking_data.get("tracking_status", ""),
             tracking_data.get("tracking_substatus", ""), tracking_data.get("tracking_message", ""),
             tracking_data.get("tracking_updated_at", ""), tracking_data.get("aftership_tracking_id", ""),
             tracking_data.get("courier_tracking_link", ""), order_status, order_id)
        )
        self.conn.commit()

    def delete_order(self, order_id):
        self.conn.execute("DELETE FROM orders WHERE id=?", (order_id,))
        self.conn.commit()

    def get_setting(self, key, default=None):
        row = self.conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set_setting(self, key, value):
        self.conn.execute(
            "INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value)),
        )
        self.conn.commit()

    def close(self):
        self.conn.close()


def order_totals(order, items):
    """Cash-flow model used by V8.

    Refund is counted only when it is marked as actually received. Buyer payout
    is calculated from the original product total and the order-level percentage.
    Legacy tax is still included if an old database contains it, but V7 does not
    expose a tax field for new orders.
    """
    # sqlite3.Row has mapping access but no .get(); normalize both DB rows and dialog dicts.
    order = dict(order) if not isinstance(order, dict) else order
    items = [dict(i) if not isinstance(i, dict) else i for i in items]
    purchase = sum(D(i["buy_price"]) * D(i["qty"]) for i in items)
    item_consumables = sum(D(i.get("consumables", 0)) * D(i["qty"]) for i in items)
    shipping = D(order.get("shipping", 0))
    order_consumables = D(order.get("other_expenses", 0))
    legacy_tax = D(order.get("tax", 0))
    consumables = item_consumables + order_consumables
    extra_costs = shipping + consumables + legacy_tax
    gross_expenses = purchase + extra_costs

    refunded = bool(int(order.get("refunded", 0) or 0))
    refund = D(order.get("refund_amount", 0)) if refunded else Decimal("0")
    # The normal workflow expects a full refund of the product total. Actual results only
    # count money that has really been received; forecasts use the full product total until
    # the refund is confirmed, so "result now" and "final result" remain meaningfully different.
    expected_refund = refund if refunded else purchase

    buyer_percent = max(Decimal("0"), min(Decimal("100"), D(order.get("buyer_percent", 70))))
    buyer_expected = purchase * buyer_percent / Decimal("100")
    buyer_sent = bool(int(order.get("buyer_sent", 0) or 0))
    buyer_paid = bool(int(order.get("buyer_paid", 0) or 0))
    buyer_amount_stored = D(order.get("buyer_amount", 0))
    buyer_received = buyer_amount_stored if buyer_paid else Decimal("0")
    if buyer_paid and buyer_received == 0 and buyer_expected > 0:
        buyer_received = buyer_expected
    projected_buyer = buyer_received if buyer_paid else buyer_expected

    actual_inflow = refund + buyer_received
    projected_inflow = expected_refund + projected_buyer
    realized_profit = actual_inflow - gross_expenses
    projected_profit = projected_inflow - gross_expenses
    after_refund_cost = gross_expenses - refund
    capital_tied = max(gross_expenses - actual_inflow, Decimal("0"))
    buyer_discount = max(purchase - buyer_expected, Decimal("0"))
    margin = buyer_percent

    return {
        "purchase": purchase,
        "consumables": consumables,
        "shipping": shipping,
        "extra_costs": extra_costs,
        "gross_expenses": gross_expenses,
        "refund": refund,
        "expected_refund": expected_refund,
        "buyer_percent": buyer_percent,
        "buyer_sent": buyer_sent,
        "buyer_expected": buyer_expected,
        "buyer_received": buyer_received,
        "buyer_paid": buyer_paid,
        "buyer_discount": buyer_discount,
        "actual_inflow": actual_inflow,
        "projected_inflow": projected_inflow,
        "after_refund_cost": after_refund_cost,
        "capital_tied": capital_tied,
        # Compatibility aliases for older dashboard widgets.
        "realized_revenue": buyer_received,
        "projected_revenue": projected_buyer,
        "realized_profit": realized_profit,
        "projected_profit": projected_profit,
        "margin": margin,
    }


class AnimatedButton(tk.Canvas):
    """Canvas-based pill/rounded button.

    Tk's native Button is always rectangular on Windows.  This widget draws
    the whole surface itself so the corners stay perfectly rounded and are
    never covered by a child widget.
    """
    def __init__(self, master, text, command=None, bg=ACCENT, hover=ACCENT_HOVER, fg="white",
                 animations_getter=lambda: True, radius=16, height=40, padx=18, min_width=0, **kwargs):
        self._parent_bg = kwargs.pop("outer_bg", None)
        if self._parent_bg is None:
            try:
                self._parent_bg = master.cget("bg")
            except Exception:
                self._parent_bg = BG
        self.text = str(text)
        self.command = command
        self.default_bg = bg
        self.hover_bg = hover
        self.fg = fg
        self.radius = radius
        self.h = height
        self.padx = padx
        self.animations_getter = animations_getter
        self.current_bg = bg
        self._job = None
        self._hovered = False
        self._pressed = False
        self._state = kwargs.pop("state", "normal")
        self._font_spec = kwargs.pop("font", FONT_BOLD)
        try:
            f = tkfont.Font(font=self._font_spec)
            text_w = f.measure(self.text)
        except Exception:
            text_w = max(60, len(self.text) * 8)
        width = max(min_width, text_w + padx * 2)
        super().__init__(master, width=width, height=height, bg=self._parent_bg,
                         bd=0, highlightthickness=0, cursor="hand2" if self._state != "disabled" else "arrow")
        self.bind("<Configure>", lambda _e: self._redraw())
        self.bind("<Enter>", lambda _e: self._set_hover(True))
        self.bind("<Leave>", lambda _e: self._set_hover(False))
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)
        self._redraw()

    def _round(self, x1, y1, x2, y2, r, **kw):
        r = max(2, min(r, (x2-x1)/2, (y2-y1)/2))
        pts = [
            x1+r,y1, x2-r,y1, x2,y1, x2,y1+r,
            x2,y2-r, x2,y2, x2-r,y2, x1+r,y2,
            x1,y2, x1,y2-r, x1,y1+r, x1,y1,
        ]
        return self.create_polygon(pts, smooth=True, splinesteps=32, **kw)

    def _redraw(self):
        self.delete("all")
        w = max(2, self.winfo_width())
        h = max(2, self.winfo_height())
        color = self.current_bg
        if self._state == "disabled":
            color = blend_color(self.default_bg, CARD_2, 0.58)
        if self._pressed and self._state != "disabled":
            color = blend_color(color, "#000000", 0.14)
        # Two-pixel transparent margin prevents anti-aliased corners from clipping.
        self._round(2, 2, w-2, h-2, min(self.radius, (h-4)/2), fill=color, outline="")
        self.create_text(w/2, h/2, text=self.text,
                         fill=(MUTED_2 if self._state == "disabled" else self.fg),
                         font=self._font_spec, anchor="center")

    def _set_hover(self, state):
        self._hovered = state
        if self._state == "disabled":
            return
        self._animate_to(self.hover_bg if state else self.default_bg)

    def _on_press(self, _event):
        if self._state == "disabled":
            return
        self._pressed = True
        self._redraw()

    def _on_release(self, event):
        if self._state == "disabled":
            return
        was_pressed = self._pressed
        self._pressed = False
        self._redraw()
        if was_pressed and 0 <= event.x <= self.winfo_width() and 0 <= event.y <= self.winfo_height():
            if callable(self.command):
                self.command()

    def _animate_to(self, target):
        if self._job:
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
            self._job = None
        if not self.animations_getter():
            self.current_bg = target
            self._redraw()
            return
        start = self.current_bg
        # V8.12: more frames + smoothstep easing makes hover transitions feel
        # continuous instead of jumping through a handful of colors.
        steps = 9
        def step(i=1):
            if not self.winfo_exists():
                return
            t = i / steps
            eased = t * t * (3 - 2 * t)
            self.current_bg = blend_color(start, target, eased)
            self._redraw()
            if i < steps:
                self._job = self.after(16, step, i + 1)
            else:
                self.current_bg = target
                self._job = None
                self._redraw()
        step()

    def configure(self, cnf=None, **kw):
        # Keep a Button-like API for existing code.
        if cnf:
            kw.update(cnf)
        redraw = False
        if "text" in kw:
            self.text = str(kw.pop("text")); redraw = True
        if "bg" in kw or "background" in kw:
            self.default_bg = kw.pop("bg", kw.pop("background", self.default_bg))
            self.current_bg = self.default_bg; redraw = True
        if "fg" in kw or "foreground" in kw:
            self.fg = kw.pop("fg", kw.pop("foreground", self.fg)); redraw = True
        if "state" in kw:
            self._state = kw.pop("state")
            super().configure(cursor="arrow" if self._state == "disabled" else "hand2")
            redraw = True
        if "command" in kw:
            self.command = kw.pop("command")
        if kw:
            super().configure(**kw)
        if redraw:
            self._redraw()
    config = configure

    def cget(self, key):
        if key == "text": return self.text
        if key in ("bg", "background"): return self.default_bg
        if key in ("fg", "foreground"): return self.fg
        if key == "state": return self._state
        return super().cget(key)


class MetricCard(tk.Frame):
    def __init__(self, master, app, title, hint="", value_color=TEXT):
        super().__init__(master, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
        self.app = app
        self._job = None
        top = tk.Frame(self, bg=CARD)
        top.pack(fill="x", padx=18, pady=(15, 2))
        tk.Label(top, text=title, bg=CARD, fg=MUTED, font=FONT).pack(side="left")
        tk.Label(top, text="•", bg=CARD, fg=ACCENT, font=("Segoe UI", 12)).pack(side="right")
        self.value_label = tk.Label(self, text="—", bg=CARD, fg=value_color, font=FONT_BIG)
        self.value_label.pack(anchor="w", padx=18, pady=(1, 3))
        if hint:
            tk.Label(self, text=hint, bg=CARD, fg=MUTED_2, font=("Segoe UI", 8),
                     wraplength=235, justify="left").pack(anchor="w", padx=18, pady=(0, 14))
        else:
            tk.Frame(self, bg=CARD, height=12).pack()

    def set_text(self, value, color=None):
        if color:
            self.value_label.config(fg=color)
        self.value_label.config(text=value)

    def animate_number(self, target, formatter, color=None):
        if color:
            self.value_label.config(fg=color)
        if self._job:
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
            self._job = None
        target = D(target)
        if not self.app.animations_enabled:
            self.value_label.config(text=formatter(target))
            return
        steps = 18

        def step(i=1):
            if not self.winfo_exists():
                return
            t = i / steps
            eased = 1 - (1 - t) ** 4
            value = target * Decimal(str(eased))
            self.value_label.config(text=formatter(value))
            if i < steps:
                self._job = self.after(16, step, i + 1)
            else:
                self.value_label.config(text=formatter(target))
                self._job = None

        step()


class ItemDialog(tk.Toplevel):
    """A deliberately simple product editor: one order can contain any number of products."""
    def __init__(self, parent, app, item=None):
        super().__init__(parent)
        self.app = app
        self.result = None
        self.title(self.app.t("product_title"))
        self.configure(bg=BG)
        # RoundedCard uses a Canvas child and therefore does not naturally report
        # the requested size of all controls to a new Toplevel on Windows.  Without
        # an explicit client size the product editor can collapse into a tiny pill.
        # Give the editor a real, DPI-safe size and allow it to grow if Windows uses
        # 125/150% display scaling.
        self.geometry("700x570")
        self.minsize(650, 530)
        self.resizable(True, True)
        self.transient(parent)
        self.grab_set()

        status = item.get("status", "Ordered") if item else "Ordered"
        self.vars = {
            "name": tk.StringVar(),
            "category": tk.StringVar(value=self.app.category_label("Other")),
            "qty": tk.StringVar(value="1"),
            "buy_price": tk.StringVar(value="0"),
            "status": tk.StringVar(value=self.app.status_label(status if status in ITEM_STATUSES else "Ordered")),
        }
        if item:
            for k in ("name", "qty", "buy_price"):
                if k in item:
                    self.vars[k].set(str(item[k]))
            self.vars["category"].set(self.app.category_label(item.get("category", "Other")))

        card = RoundedCard(self, fill=CARD, border=BORDER, radius=26, content_inset=16)
        card.pack(fill="both", expand=True, padx=18, pady=18)
        panel = card.body
        fields = [
            ("product_name", "name"),
            ("category", "category"),
            ("quantity", "qty"),
            ("buy_price_unit", "buy_price"),
        ]
        first_entry = None
        for r, (label_key, key) in enumerate(fields):
            tk.Label(panel, text=self.app.t(label_key), bg=CARD, fg=MUTED, font=FONT).grid(
                row=r, column=0, sticky="w", pady=7, padx=(8, 16)
            )
            if key == "category":
                e = RoundedCombo(panel, textvariable=self.vars[key], values=[self.app.category_label(x) for x in ITEM_CATEGORIES], state="readonly", height=42)
            elif key == "buy_price":
                e = CurrencyEntry(panel, self.app, textvariable=self.vars[key], fill=CARD_2, radius=14, height=42)
            elif key == "qty":
                e = RoundedEntry(panel, textvariable=self.vars[key], fill=CARD_2, radius=14, height=42, integer=True)
            else:
                e = RoundedEntry(panel, textvariable=self.vars[key], fill=CARD_2, radius=14, height=42)
            e.grid(row=r, column=1, sticky="ew", pady=6, padx=(0, 8))
            if first_entry is None:
                first_entry = e

        r = len(fields)
        tk.Label(panel, text=self.app.t("product_status"), bg=CARD, fg=MUTED, font=FONT).grid(
            row=r, column=0, sticky="w", pady=7, padx=(8, 16)
        )
        RoundedCombo(panel, textvariable=self.vars["status"],
                     values=[self.app.status_label(x) for x in ITEM_STATUSES], state="readonly", height=42).grid(
            row=r, column=1, sticky="ew", pady=6, padx=(0, 8)
        )

        r += 1
        tk.Label(panel, text=self.app.t("notes"), bg=CARD, fg=MUTED, font=FONT).grid(
            row=r, column=0, sticky="nw", pady=8, padx=(8, 16)
        )
        self.notes = RoundedText(panel, fill=CARD_2, radius=14, height=100, width=36, text_height=4)
        self.notes.grid(row=r, column=1, sticky="ew", pady=6, padx=(0, 8))
        if item:
            self.notes.insert("1.0", item.get("notes", ""))

        btns = tk.Frame(panel, bg=CARD)
        btns.grid(row=r + 1, column=0, columnspan=2, sticky="e", pady=(18, 7), padx=(0, 8))
        self.app.button(btns, self.app.t("cancel"), self.destroy, bg=CARD_2, hover=BORDER, radius=18, height=42).pack(side="left", padx=(0, 8))
        self.app.button(btns, self.app.t("save_product"), self.save, radius=18, height=42).pack(side="left")
        panel.grid_columnconfigure(1, weight=1)
        self.bind("<Escape>", lambda _e: self.destroy())
        self.update_idletasks()
        self._center(parent)
        if first_entry:
            first_entry.focus_set()
        self.app.fade_in_window(self)

    def _center(self, parent):
        self.update_idletasks()
        w = max(self.winfo_width(), 650)
        h = max(self.winfo_height(), 530)
        x = parent.winfo_rootx() + (parent.winfo_width() - w) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - h) // 2
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        x = max(10, min(x, max(10, sw - w - 10)))
        y = max(10, min(y, max(10, sh - h - 50)))
        self.geometry(f"{w}x{h}+{x}+{y}")

    def save(self):
        name = self.vars["name"].get().strip()
        if not name:
            messagebox.showwarning(self.app.t("product_title"), self.app.t("enter_product_name"), parent=self)
            return
        try:
            qty = int(self.vars["qty"].get())
        except ValueError:
            messagebox.showwarning(self.app.t("product_title"), self.app.t("quantity_whole"), parent=self)
            return
        if qty < 1:
            messagebox.showwarning(self.app.t("product_title"), self.app.t("check_quantity"), parent=self)
            return
        # Keep legacy fields in the data model for backward compatibility, but V7 does not ask for them.
        self.result = {
            "name": name,
            "category": self.app.category_from_label(self.vars["category"].get()),
            "qty": qty,
            "sold_qty": 0,
            "buy_price": self.vars["buy_price"].get().strip(),
            "consumables": "0",
            "planned_sale": "0",
            "actual_sale": "0",
            "status": self.app.status_from_label(self.vars["status"].get(), ITEM_STATUSES),
            "serial_imei": "",
            "notes": self.notes.get("1.0", "end").strip(),
        }
        self.destroy()


class OrderDialog(tk.Toplevel):
    def __init__(self, parent, app, db, order_id=None, on_saved=None):
        super().__init__(parent)
        self.app = app
        self.db = db
        self.order_id = order_id
        self.on_saved = on_saved
        self.items = []
        self.title(self.app.t("edit_order") if order_id else self.app.t("create_order"))
        self.configure(bg=BG)
        self.geometry("1180x820")
        self.minsize(1030, 720)
        self.transient(parent)
        self.grab_set()

        self.vars = {
            "amazon_order_id": tk.StringVar(),
            "store": tk.StringVar(),
            "purchase_date": tk.StringVar(value=datetime.now().strftime("%Y-%m-%d")),
            "tracking": tk.StringVar(),
            "carrier_slug": tk.StringVar(value=""),
            "tracking_status": tk.StringVar(value=""),
            "tracking_substatus": tk.StringVar(value=""),
            "tracking_message": tk.StringVar(value=""),
            "tracking_updated_at": tk.StringVar(value=""),
            "aftership_tracking_id": tk.StringVar(value=""),
            "courier_tracking_link": tk.StringVar(value=""),
            "status": tk.StringVar(value=self.app.status_label("Ordered")),
            "shipping": tk.StringVar(value="0"),
            "tax": tk.StringVar(value="0"),
            "other_expenses": tk.StringVar(value="0"),
            "refunded": tk.BooleanVar(value=False),
            "refund_amount": tk.StringVar(value="0"),
            "buyer_percent": tk.StringVar(value=f"{self.app.default_buyer_percent:g}"),
            "buyer_sent": tk.BooleanVar(value=False),
            "buyer_paid": tk.BooleanVar(value=False),
            "buyer_amount": tk.StringVar(value="0"),
        }
        self._build()
        if order_id:
            self._load(order_id)
        self._refresh_items()
        self._recalc()
        self.app.fade_in_window(self)

    def _build(self):
        top = tk.Frame(self, bg=BG)
        top.pack(fill="x", padx=22, pady=(18, 10))
        title_box = tk.Frame(top, bg=BG)
        title_box.pack(side="left")
        tk.Label(title_box, text=self.app.t("order_details"), bg=BG, fg=TEXT, font=FONT_TITLE).pack(anchor="w")
        tk.Label(title_box, text=self.app.t("edit_order") if self.order_id else self.app.t("create_order"),
                 bg=BG, fg=MUTED, font=FONT_SMALL).pack(anchor="w", pady=(2, 0))
        self.app.button(top, self.app.t("save_order"), self.save, radius=18, height=44).pack(side="right")

        form_card = RoundedCard(self, fill=CARD, border=BORDER, radius=22, height=292, content_inset=10)
        form_card.pack(fill="x", padx=22, pady=(0, 12))
        form = form_card.body
        inputs = [("store", "store", 0, 0), ("order_id", "amazon_order_id", 0, 2),
                  ("purchase_date", "purchase_date", 1, 0), ("tracking", "tracking", 1, 2)]
        for label_key, key, row, col in inputs:
            tk.Label(form, text=self.app.t(label_key), bg=CARD, fg=MUTED, font=FONT).grid(row=row, column=col, sticky="w", padx=(10, 8), pady=7)
            field = RoundedEntry(form, textvariable=self.vars[key], fill=CARD_2, radius=14, height=40)
            field.grid(row=row, column=col + 1, sticky="ew", padx=(0, 12), pady=5)
        tk.Label(form, text=self.app.t("carrier"), bg=CARD, fg=MUTED, font=FONT).grid(row=2, column=0, sticky="w", padx=(10, 8), pady=7)
        self.carrier_name_var = tk.StringVar(value=self.app.t("carrier_auto"))
        carrier_values = [self.app.t("carrier_auto")] + [name for name in TRACKING_CARRIERS if name != "Auto detect"]
        RoundedCombo(form, textvariable=self.carrier_name_var, values=carrier_values, state="readonly", height=40).grid(row=2, column=1, sticky="ew", padx=(0, 12), pady=5)
        tk.Label(form, text=self.app.t("delivery_status"), bg=CARD, fg=MUTED, font=FONT).grid(row=2, column=2, sticky="w", padx=(10, 8), pady=7)
        self.delivery_status_label = tk.Label(form, text=self.app.t("delivery.unknown"), bg=CARD, fg=BLUE, font=FONT_BOLD, anchor="w", justify="left")
        self.delivery_status_label.grid(row=2, column=3, sticky="ew", padx=(0, 12), pady=5)
        tk.Label(form, text=self.app.t("order_status"), bg=CARD, fg=MUTED, font=FONT).grid(row=3, column=0, sticky="w", padx=(10, 8), pady=7)
        RoundedCombo(form, textvariable=self.vars["status"], values=[self.app.status_label(x) for x in ORDER_STATUSES], state="readonly", height=40).grid(row=3, column=1, sticky="ew", padx=(0, 12), pady=5)
        self.track_now_btn = self.app.button(form, self.app.t("tracking_update"), self._update_tracking_now, bg=CARD_3, hover=BORDER, radius=14, height=40)
        self.track_now_btn.grid(row=3, column=3, sticky="ew", padx=(0, 12), pady=5)
        self.delivery_detail_label = tk.Label(form, text=self.app.t("tracking_sync_note"), bg=CARD, fg=MUTED_2,
                                              font=("Segoe UI", 8), anchor="w", justify="left", wraplength=930)
        self.delivery_detail_label.grid(row=4, column=0, columnspan=4, sticky="ew", padx=10, pady=(4, 7))
        form.bind("<Configure>", lambda e: self.delivery_detail_label.configure(wraplength=max(500, e.width-30)), add="+")
        for c in (1, 3): form.grid_columnconfigure(c, weight=1)

        mid = tk.PanedWindow(self, orient="horizontal", bg=BG, sashwidth=10, relief="flat", bd=0, sashrelief="flat", handlesize=0)
        mid.pack(fill="both", expand=True, padx=22, pady=(0, 12))
        left_card = RoundedCard(mid, fill=CARD, border=BORDER, radius=24, content_inset=10)
        right_card = RoundedCard(mid, fill=CARD, border=BORDER, radius=24, content_inset=10)
        tk.Frame.configure(left_card, width=760); tk.Frame.configure(right_card, width=370)
        mid.add(left_card, stretch="always", minsize=590); mid.add(right_card, minsize=350)
        left = left_card.body
        # The financial controls can be taller than the window on laptops; make the right pane scrollable
        # instead of clipping the buyer/refund cards.
        right_scroll = ScrollableFrame(right_card.body, CARD)
        right_scroll.pack(fill="both", expand=True)
        right = right_scroll.inner

        head = tk.Frame(left, bg=CARD); head.pack(fill="x", padx=8, pady=(6, 8))
        tk.Label(head, text=self.app.t("products_in_order"), bg=CARD, fg=TEXT, font=FONT_SUBTITLE).pack(side="left")
        self.app.button(head, self.app.t("add_product"), self.add_item, radius=18, height=40).pack(side="right")

        cols = ("name", "category", "qty", "buy", "subtotal", "status")
        self.tree = ttk.Treeview(left, columns=cols, show="headings", height=16)
        headings = {"name": self.app.t("product"), "category": self.app.t("category"), "qty": self.app.t("qty"), "buy": self.app.t("buy_unit"), "subtotal": self.app.t("purchase_total"), "status": self.app.t("status")}
        widths = {"name": 220, "category": 155, "qty": 65, "buy": 115, "subtotal": 125, "status": 140}
        for c in cols:
            self.tree.heading(c, text=headings[c]); self.tree.column(c, width=widths[c], anchor="center" if c != "name" else "w")
        self.tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.tree.bind("<Double-1>", lambda _e: self.edit_item())
        item_btns = tk.Frame(left, bg=CARD); item_btns.pack(fill="x", padx=8, pady=(0, 5))
        self.app.button(item_btns, self.app.t("edit"), self.edit_item, bg=CARD_2, hover=BORDER, radius=18, height=40).pack(side="left", padx=(0, 8))
        self.app.button(item_btns, self.app.t("remove"), self.remove_item, bg="#3a1d28", hover="#512331", radius=18, height=40).pack(side="left")

        notes_row = tk.Frame(left, bg=CARD); notes_row.pack(fill="x", padx=8, pady=(4, 2))
        tk.Label(notes_row, text=self.app.t("notes"), bg=CARD, fg=MUTED, font=FONT_SMALL).pack(anchor="w")
        self.notes = RoundedText(notes_row, fill=CARD_2, radius=13, height=72, text_height=3)
        self.notes.pack(fill="x", pady=(4, 0))

        # Expenses: only shipping + consumables are needed for new orders.
        tk.Label(right, text=self.app.t("order_expenses"), bg=CARD, fg=TEXT, font=FONT_SUBTITLE).pack(anchor="w", padx=8, pady=(2, 4))
        for label_key, key in [("shipping", "shipping"), ("other_expenses", "other_expenses")]:
            row = tk.Frame(right, bg=CARD); row.pack(fill="x", padx=8, pady=2)
            tk.Label(row, text=self.app.t(label_key), bg=CARD, fg=MUTED, font=FONT).pack(anchor="w")
            e = CurrencyEntry(row, self.app, textvariable=self.vars[key], fill=CARD_2, radius=13, height=34)
            e.pack(fill="x", pady=(4, 0)); e.bind("<KeyRelease>", lambda _e: self._recalc())

        refund_card = RoundedCard(right, fill=CARD_2, border=BORDER, radius=18, height=156, content_inset=8)
        refund_card.pack(fill="x", padx=8, pady=(10, 7))
        rf = refund_card.body
        cb = tk.Checkbutton(rf, text=self.app.t("refund_received"), variable=self.vars["refunded"], command=self._toggle_refund,
                            bg=CARD_2, fg=TEXT, selectcolor=SIDEBAR, activebackground=CARD_2, activeforeground=TEXT,
                            font=FONT_BOLD, bd=0, highlightthickness=0)
        cb.pack(anchor="w", padx=4, pady=(4, 3))
        line = tk.Frame(rf, bg=CARD_2); line.pack(fill="x", padx=4)
        tk.Label(line, text=self.app.t("refund_amount"), bg=CARD_2, fg=MUTED, font=FONT_SMALL).pack(side="left")
        self.app.button(line, self.app.t("full_refund_fill"), self._fill_full_refund, bg=CARD_3, hover=BORDER, radius=12, height=28, padx=10).pack(side="right")
        self.refund_entry = CurrencyEntry(rf, self.app, textvariable=self.vars["refund_amount"], fill=CARD, radius=12, height=34)
        self.refund_entry.pack(fill="x", padx=4, pady=(5, 2)); self.refund_entry.bind("<KeyRelease>", lambda _e: self._recalc())
        self.refund_expected_label = tk.Label(rf, text="—", bg=CARD_2, fg=MUTED, font=("Segoe UI", 8))
        self.refund_expected_label.pack(anchor="w", padx=5, pady=(0, 2))

        buyer_card = RoundedCard(right, fill=CARD_2, border=BORDER, radius=18, height=180, content_inset=8)
        buyer_card.pack(fill="x", padx=8, pady=(7, 7))
        bf = buyer_card.body
        tk.Label(bf, text=self.app.t("buyer_section"), bg=CARD_2, fg=TEXT, font=FONT_BOLD).pack(anchor="w", padx=4, pady=(4, 3))
        tk.Label(bf, text=self.app.t("buyer_percent"), bg=CARD_2, fg=MUTED, font=FONT_SMALL).pack(anchor="w", padx=4)
        self.buyer_percent_entry = RoundedEntry(bf, textvariable=self.vars["buyer_percent"], fill=CARD, radius=12, height=34, numeric=True, max_decimals=2)
        self.buyer_percent_entry.pack(fill="x", padx=4, pady=(4, 4)); self.buyer_percent_entry.bind("<KeyRelease>", lambda _e: self._buyer_percent_changed())
        self.buyer_expected_label = tk.Label(bf, text="—", bg=CARD_2, fg=BLUE, font=FONT_BOLD)
        self.buyer_expected_label.pack(anchor="w", padx=5, pady=(1, 5))
        sent_cb = tk.Checkbutton(bf, text=self.app.t("buyer_sent"), variable=self.vars["buyer_sent"], command=self._toggle_buyer_sent,
                                 bg=CARD_2, fg=TEXT, selectcolor=SIDEBAR, activebackground=CARD_2, activeforeground=TEXT,
                                 font=FONT_BOLD, bd=0, highlightthickness=0)
        sent_cb.pack(anchor="w", padx=4, pady=(0, 2))
        cb2 = tk.Checkbutton(bf, text=self.app.t("buyer_paid"), variable=self.vars["buyer_paid"], command=self._toggle_buyer_paid,
                             bg=CARD_2, fg=TEXT, selectcolor=SIDEBAR, activebackground=CARD_2, activeforeground=TEXT,
                             font=FONT_BOLD, bd=0, highlightthickness=0)
        cb2.pack(anchor="w", padx=4, pady=(0, 2))
        self.buyer_amount_entry = CurrencyEntry(bf, self.app, textvariable=self.vars["buyer_amount"], fill=CARD, radius=12, height=34)
        self.buyer_amount_entry.pack(fill="x", padx=4, pady=(2, 4)); self.buyer_amount_entry.bind("<KeyRelease>", lambda _e: self._recalc())

        totals_card = RoundedCard(self, fill=CARD, border=BORDER, radius=22, height=112, content_inset=9)
        totals_card.pack(fill="x", padx=22, pady=(0, 18))
        totals = totals_card.body; self.total_labels = {}
        metrics = [
            ("cash_outflow", "gross_expenses", TEXT),
            ("refund_total_short", "refund", AMBER),
            ("buyer_payouts", "buyer_received", BLUE),
            ("capital_tied", "capital_tied", AMBER),
            ("profit_now", "realized_profit", TEXT),
            ("projected_profit", "projected_profit", GREEN),
        ]
        for i, (title_key, key, color) in enumerate(metrics):
            f = tk.Frame(totals, bg=CARD); f.grid(row=0, column=i, sticky="nsew", padx=7, pady=8)
            tk.Label(f, text=self.app.t(title_key), bg=CARD, fg=MUTED, font=("Segoe UI", 9)).pack()
            lbl = tk.Label(f, text="—", bg=CARD, fg=color, font=FONT_SUBTITLE); lbl.pack(pady=(4, 0))
            self.total_labels[key] = lbl; totals.grid_columnconfigure(i, weight=1)

        self._toggle_refund(); self._toggle_buyer_sent(); self._toggle_buyer_paid()

    def _load(self, order_id):
        order = self.db.get_order(order_id)
        if not order: return
        for k in ("amazon_order_id", "store", "purchase_date", "tracking", "carrier_slug", "tracking_status",
                  "tracking_substatus", "tracking_message", "tracking_updated_at", "aftership_tracking_id",
                  "courier_tracking_link", "shipping", "other_expenses", "refund_amount", "buyer_percent", "buyer_amount"):
            if k in order.keys(): self.vars[k].set(order[k] or "")
        slug = self.vars["carrier_slug"].get()
        self.carrier_name_var.set(TRACKING_SLUG_TO_NAME.get(slug, self.app.t("carrier_auto")))
        self._refresh_delivery_status_label()
        self.vars["tax"].set(order["tax"] if "tax" in order.keys() else 0)
        self.vars["status"].set(self.app.status_label(order["status"] or "Ordered"))
        self.vars["refunded"].set(bool(order["refunded"]))
        self.vars["buyer_sent"].set(bool(order["buyer_sent"]) if "buyer_sent" in order.keys() else False)
        self.vars["buyer_paid"].set(bool(order["buyer_paid"]) if "buyer_paid" in order.keys() else False)
        self.notes.insert("1.0", order["notes"] or "")
        self.items = [dict(row) for row in self.db.get_items(order_id)]
        self._toggle_refund(); self._toggle_buyer_sent(); self._toggle_buyer_paid()

    def _refresh_delivery_status_label(self):
        tag = self.vars["tracking_status"].get() if "tracking_status" in self.vars else ""
        if hasattr(self, "delivery_status_label"):
            self.delivery_status_label.config(
                text=self.app.delivery_label(tag),
                fg=GREEN if tag == "Delivered" else AMBER if tag in ("Exception", "AttemptFail") else BLUE
            )
        if hasattr(self, "delivery_detail_label"):
            message = self.vars["tracking_message"].get().strip()
            updated = self.vars["tracking_updated_at"].get().strip()
            if message or updated:
                pieces = []
                if message:
                    pieces.append(message)
                if updated:
                    pieces.append(f"{self.app.t('delivery_last_update')}: {updated}")
                self.delivery_detail_label.config(text="  •  ".join(pieces), fg=MUTED)
            else:
                self.delivery_detail_label.config(text=self.app.t("tracking_sync_note"), fg=MUTED_2)

    def _update_tracking_now(self):
        number = self.vars["tracking"].get().strip()
        if not number:
            messagebox.showinfo(self.app.t("tracking"), self.app.t("tracking_no_number"), parent=self)
            return
        if not self.app.aftership_api_key:
            messagebox.showinfo(self.app.t("tracking"), self.app.t("tracking_no_key"), parent=self)
            return
        carrier_name = self.carrier_name_var.get()
        slug = TRACKING_CARRIERS.get(carrier_name, "") if carrier_name != self.app.t("carrier_auto") else ""
        order_title = self.vars["amazon_order_id"].get().strip()
        if hasattr(self, "track_now_btn"):
            self.track_now_btn.set_text(self.app.t("tracking_updating"))

        def worker():
            try:
                result = aftership_track(self.app.aftership_api_key, number, slug, order_title)
                err = None
            except Exception as exc:
                result, err = None, str(exc)
            try:
                self.after(0, lambda: self._tracking_dialog_result(result, err))
            except tk.TclError:
                pass
        threading.Thread(target=worker, daemon=True).start()

    def _tracking_dialog_result(self, result, error):
        if not self.winfo_exists():
            return
        if hasattr(self, "track_now_btn"):
            self.track_now_btn.set_text(self.app.t("tracking_update"))
        if error:
            messagebox.showwarning(self.app.t("tracking"), self.app.t("tracking_error", error=error), parent=self)
            return
        for key, value in result.items():
            if key in self.vars:
                self.vars[key].set(value or "")
        if result.get("carrier_slug"):
            self.carrier_name_var.set(TRACKING_SLUG_TO_NAME.get(result["carrier_slug"], self.carrier_name_var.get()))
        self._refresh_delivery_status_label()
        current = self.app.status_from_label(self.vars["status"].get(), ORDER_STATUSES)
        mapped = self.app.order_status_for_delivery(result.get("tracking_status", ""), current)
        if mapped != current:
            self.vars["status"].set(self.app.status_label(mapped))

    def add_item(self):
        dlg = ItemDialog(self, self.app); self.wait_window(dlg)
        if dlg.result:
            self.items.append(dlg.result); self._refresh_items(); self._recalc()

    def _selected_index(self):
        sel = self.tree.selection()
        if not sel: return None
        try: return int(sel[0])
        except ValueError: return None

    def edit_item(self):
        idx = self._selected_index()
        if idx is None:
            messagebox.showinfo(self.app.t("products"), self.app.t("select_product"), parent=self); return
        dlg = ItemDialog(self, self.app, self.items[idx]); self.wait_window(dlg)
        if dlg.result:
            # Preserve any legacy item-only cost/sale fields that V7 intentionally hides.
            old = self.items[idx]
            for key in ("consumables", "planned_sale", "actual_sale", "sold_qty"):
                if key in old and D(old.get(key, 0)) != 0:
                    dlg.result[key] = old[key]
            self.items[idx] = dlg.result; self._refresh_items(); self._recalc()

    def remove_item(self):
        idx = self._selected_index()
        if idx is None: return
        del self.items[idx]; self._refresh_items(); self._recalc()

    def _refresh_items(self):
        for x in self.tree.get_children(): self.tree.delete(x)
        for idx, i in enumerate(self.items):
            subtotal = D(i.get("buy_price", 0)) * D(i.get("qty", 0))
            self.tree.insert("", "end", iid=str(idx), values=(
                i.get("name", "—"), self.app.category_label(i.get("category", "Other")), i.get("qty", 0), self.app.money(i.get("buy_price", 0)),
                self.app.money(subtotal), self.app.status_label(i.get("status", "Ordered") if i.get("status", "Ordered") in ITEM_STATUSES else "Ordered")
            ))
        self._recalc()

    def _purchase_total(self):
        return sum((D(i.get("buy_price", 0)) * D(i.get("qty", 0)) for i in self.items), Decimal("0"))

    def _fill_full_refund(self):
        self.vars["refunded"].set(True)
        self.vars["refund_amount"].set(str(self._purchase_total()))
        self._toggle_refund(keep_value=True)

    def _toggle_refund(self, keep_value=False):
        state = "normal" if self.vars["refunded"].get() else "disabled"
        self.refund_entry.config(state=state)
        if state == "normal" and D(self.vars["refund_amount"].get()) == 0:
            # Normal workflow: refund equals the full product total. Keep editable for real-world exceptions.
            self.vars["refund_amount"].set(str(self._purchase_total()))
            current = self.app.status_from_label(self.vars["status"].get(), ORDER_STATUSES)
            if current in ("Ordered", "In transit", "Received"):
                self.vars["status"].set(self.app.status_label("Refund received"))
        elif state == "disabled" and not keep_value:
            self.vars["refund_amount"].set("0")
        self._recalc()

    def _toggle_buyer_sent(self):
        if self.vars["buyer_sent"].get():
            current = self.app.status_from_label(self.vars["status"].get(), ORDER_STATUSES)
            if current != "Completed":
                self.vars["status"].set(self.app.status_label("Sent to buyer"))
        self._recalc()

    def _buyer_percent_changed(self):
        # If payout is not confirmed, only the expected amount changes. If it is confirmed and
        # still equals the old automatic estimate, refresh the amount to the new estimate.
        if self.vars["buyer_paid"].get():
            expected = self._purchase_total() * max(Decimal("0"), min(Decimal("100"), D(self.vars["buyer_percent"].get()))) / Decimal("100")
            self.vars["buyer_amount"].set(str(expected))
        self._recalc()

    def _toggle_buyer_paid(self):
        state = "normal" if self.vars["buyer_paid"].get() else "disabled"
        self.buyer_amount_entry.config(state=state)
        if state == "normal":
            self.vars["buyer_sent"].set(True)
            self.vars["status"].set(self.app.status_label("Completed"))
            if D(self.vars["buyer_amount"].get()) == 0:
                expected = self._purchase_total() * max(Decimal("0"), min(Decimal("100"), D(self.vars["buyer_percent"].get()))) / Decimal("100")
                self.vars["buyer_amount"].set(str(expected))
        else:
            self.vars["buyer_amount"].set("0")
        self._recalc()

    def _current_order_dict(self):
        return {
            "shipping": self.vars["shipping"].get(), "tax": self.vars["tax"].get(),
            "other_expenses": self.vars["other_expenses"].get(), "refunded": int(self.vars["refunded"].get()),
            "refund_amount": self.vars["refund_amount"].get(), "buyer_percent": self.vars["buyer_percent"].get(),
            "buyer_sent": int(self.vars["buyer_sent"].get()), "buyer_paid": int(self.vars["buyer_paid"].get()),
            "buyer_amount": self.vars["buyer_amount"].get(),
        }

    def _recalc(self):
        if not hasattr(self, "total_labels"): return
        t = order_totals(self._current_order_dict(), self.items)
        if hasattr(self, "buyer_expected_label"):
            loss_pct = Decimal("100") - t["buyer_percent"]
            self.buyer_expected_label.config(
                text=f"{self.app.t('buyer_expected')}: {self.app.money(t['buyer_expected'])}   •   {self.app.t('buyer_discount')} {loss_pct:.0f}%: {self.app.money(t['buyer_discount'])}"
            )
        if hasattr(self, "refund_expected_label"):
            self.refund_expected_label.config(text=f"{self.app.t('expected_refund')}: {self.app.money(t['expected_refund'])}")
        values = {
            "gross_expenses": t["gross_expenses"], "refund": t["refund"], "buyer_received": t["buyer_received"],
            "capital_tied": t["capital_tied"], "realized_profit": t["realized_profit"], "projected_profit": t["projected_profit"],
        }
        for key, val in values.items():
            color = None
            if key in ("realized_profit", "projected_profit"): color = GREEN if val >= 0 else RED
            if key == "capital_tied": color = AMBER if val > 0 else GREEN
            self.total_labels[key].config(text=self.app.money(val), **({"fg": color} if color else {}))

    def save(self):
        order_id = self.vars["amazon_order_id"].get().strip()
        if not order_id:
            messagebox.showwarning(self.app.t("orders"), self.app.t("enter_order_id"), parent=self); return
        if not self.items:
            messagebox.showwarning(self.app.t("orders"), self.app.t("add_one_product"), parent=self); return
        pct = D(self.vars["buyer_percent"].get())
        if pct < 0 or pct > 100:
            messagebox.showwarning(self.app.t("orders"), self.app.t("buyer_percent") + ": 0–100", parent=self); return
        # Financial inputs must be non-negative. Refund is normally exactly the product total.
        for key in ("shipping", "other_expenses", "refund_amount", "buyer_amount"):
            if D(self.vars[key].get()) < 0:
                messagebox.showwarning(self.app.t("orders"), f"{key}: >= 0", parent=self); return
        purchase_total = self._purchase_total()
        if self.vars["refunded"].get() and D(self.vars["refund_amount"].get()) > purchase_total:
            messagebox.showwarning(self.app.t("orders"), self.app.t("refund_amount") + " > " + self.app.t("purchase_total"), parent=self); return
        data = {k: v.get() for k, v in self.vars.items()}
        carrier_name = self.carrier_name_var.get()
        if carrier_name == self.app.t("carrier_auto"):
            data["carrier_slug"] = data.get("carrier_slug", "")
        else:
            data["carrier_slug"] = TRACKING_CARRIERS.get(carrier_name, data.get("carrier_slug", ""))
        data["status"] = self.app.status_from_label(self.vars["status"].get(), ORDER_STATUSES)
        data["refunded"] = self.vars["refunded"].get(); data["buyer_sent"] = self.vars["buyer_sent"].get(); data["buyer_paid"] = self.vars["buyer_paid"].get()
        data["notes"] = self.notes.get("1.0", "end").strip()
        try: datetime.strptime(data["purchase_date"], "%Y-%m-%d")
        except ValueError:
            messagebox.showwarning(self.app.t("orders"), self.app.t("date_format"), parent=self); return
        if self.order_id:
            self.db.update_order(self.order_id, data, self.items)
            saved_id = self.order_id
        else:
            saved_id = self.db.add_order(data, self.items)
        if self.on_saved: self.on_saved()
        if data.get("tracking") and self.app.aftership_api_key:
            self.app.after(180, lambda oid=saved_id: self.app.refresh_tracking_all(silent=True, order_ids=[oid]))
        self.destroy()


class ScrollableFrame(tk.Frame):
    def __init__(self, master, bg=None):
        bg = BG if bg is None else bg
        super().__init__(master, bg=bg)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = tk.Frame(self.canvas, bg=bg)
        self.window_id = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        self.inner.bind("<Configure>", self._sync_region)
        self.canvas.bind("<Configure>", self._sync_width)
        self.canvas.bind("<Enter>", lambda _e: self._bind_wheel())
        self.canvas.bind("<Leave>", lambda _e: self._unbind_wheel())

    def _sync_region(self, _event=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _sync_width(self, event):
        self.canvas.itemconfigure(self.window_id, width=event.width)

    def _bind_wheel(self):
        self.canvas.bind_all("<MouseWheel>", self._on_wheel)

    def _unbind_wheel(self):
        self.canvas.unbind_all("<MouseWheel>")

    def _on_wheel(self, event):
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")


class RoundedCard(tk.Frame):
    """Rounded panel with DPI-safe vertical sizing.

    Windows font metrics can become a few pixels taller at 125–150% display
    scaling.  Fixed-height cards therefore used to cut the bottom of labels.
    Every rounded card now treats ``height`` as a *minimum* and expands itself
    when its content requests more room.  This keeps curved corners intact and
    prevents text clipping throughout the application.
    """
    def __init__(self, master, fill=None, border=None, radius=18, height=None,
                 content_inset=6, auto_expand=True, **kwargs):
        fill = CARD if fill is None else fill
        border = BORDER if border is None else border
        try:
            outer_bg = master.cget("bg")
        except Exception:
            outer_bg = BG
        super().__init__(master, bg=outer_bg, bd=0, highlightthickness=0, **kwargs)
        self.fill = fill
        self.border = border
        self.radius = radius
        self.content_inset = max(3, int(content_inset))
        self._outer_bg = outer_bg
        self._fixed_height = int(height) if height else None
        self._auto_expand = bool(auto_expand)
        self._height_job = None
        if height:
            tk.Frame.configure(self, height=height)
            self.pack_propagate(False)
            self.grid_propagate(False)
        self.canvas = tk.Canvas(self, bg=outer_bg, bd=0, highlightthickness=0)
        self.canvas.place(x=0, y=0, relwidth=1, relheight=1)
        self.body = tk.Frame(self.canvas, bg=fill, bd=0, highlightthickness=0)
        self._body_window = self.canvas.create_window((self.content_inset, self.content_inset),
                                                       window=self.body, anchor="nw")
        self.bind("<Configure>", self._redraw)
        self.body.bind("<Configure>", self._queue_fit_height, add="+")
        self.after_idle(self._fit_height_to_content)

    def _queue_fit_height(self, _event=None):
        if not self._auto_expand:
            return
        if self._height_job:
            try:
                self.after_cancel(self._height_job)
            except Exception:
                pass
        self._height_job = self.after_idle(self._fit_height_to_content)

    def _fit_height_to_content(self):
        self._height_job = None
        if not self._auto_expand or not self.winfo_exists():
            return
        try:
            self.body.update_idletasks()
            requested = int(self.body.winfo_reqheight()) + self.content_inset * 2 + 4
            minimum = self._fixed_height or 0
            target = max(minimum, requested)
            current = int(self.winfo_height())
            configured = int(self.cget("height") or 0)
            # Grow immediately when text needs room.  Never shrink below the
            # originally requested minimum; avoiding shrink/grow loops keeps
            # grids and scroll regions stable.
            if target > max(current, configured) + 1:
                tk.Frame.configure(self, height=target)
                self.pack_propagate(False)
                self.grid_propagate(False)
                self.after_idle(self._redraw)
        except (tk.TclError, ValueError):
            pass

    def _rounded_polygon(self, x1, y1, x2, y2, r, **kwargs):
        r = max(2, min(r, (x2-x1)/2, (y2-y1)/2))
        points = [
            x1+r, y1, x2-r, y1,
            x2, y1, x2, y1+r,
            x2, y2-r, x2, y2,
            x2-r, y2, x1+r, y2,
            x1, y2, x1, y2-r,
            x1, y1+r, x1, y1,
        ]
        return self.canvas.create_polygon(points, smooth=True, splinesteps=32, **kwargs)

    def _redraw(self, event=None):
        w = max(2, event.width if event else self.winfo_width())
        h = max(2, event.height if event else self.winfo_height())
        self.canvas.delete("panel")
        # Keep a transparent 1 px safety margin to avoid clipped antialiasing.
        self._rounded_polygon(1, 1, w-2, h-2, self.radius,
                              fill=self.border, outline="", tags="panel")
        self._rounded_polygon(2, 2, w-3, h-3, max(self.radius-1, 2),
                              fill=self.fill, outline="", tags="panel")
        self.canvas.tag_lower("panel")
        inset = self.content_inset
        self.canvas.coords(self._body_window, inset, inset)
        self.canvas.itemconfigure(self._body_window,
                                  width=max(1, w-inset*2), height=max(1, h-inset*2))

    def set_border(self, color):
        self.border = color
        self._redraw()


class RoundedEntry(RoundedCard):
    """Rounded input wrapper. Optional numeric validation blocks stray characters."""
    def __init__(self, master, textvariable=None, fill=None, border=None, radius=13,
                 height=40, fg=None, font=FONT, width=None, numeric=False, integer=False,
                 max_decimals=2, **kwargs):
        fill = CARD_2 if fill is None else fill
        border = BORDER if border is None else border
        fg = TEXT if fg is None else fg
        super().__init__(master, fill=fill, border=border, radius=radius,
                         height=height, content_inset=6)
        if width:
            tk.Frame.configure(self, width=width)
        self._numeric = bool(numeric or integer)
        self._integer = bool(integer)
        self._max_decimals = int(max_decimals)
        if self._numeric:
            vcmd = (self.register(self._validate_numeric), "%P")
            kwargs.setdefault("validate", "key")
            kwargs.setdefault("validatecommand", vcmd)
        self.entry = tk.Entry(self.body, textvariable=textvariable, bg=fill, fg=fg,
                              insertbackground=TEXT, relief="flat", bd=0,
                              highlightthickness=0, font=font,
                              disabledbackground=fill, disabledforeground=MUTED_2, **kwargs)
        self.entry.pack(fill="both", expand=True, padx=4)
        self.entry.bind("<FocusIn>", lambda _e: self.set_border(ACCENT), add="+")
        self.entry.bind("<FocusOut>", lambda _e: self.set_border(BORDER), add="+")

    def _validate_numeric(self, proposed):
        if proposed == "":
            return True
        if self._integer:
            return proposed.isdigit()
        value = proposed.replace(",", ".")
        if value.count(".") > 1:
            return False
        if any((not ch.isdigit()) and ch != "." for ch in value):
            return False
        if "." in value:
            whole, frac = value.split(".", 1)
            if whole and not whole.isdigit():
                return False
            if frac and not frac.isdigit():
                return False
            if len(frac) > self._max_decimals:
                return False
        return True

    def get(self): return self.entry.get()
    def insert(self, *a, **k): return self.entry.insert(*a, **k)
    def delete(self, *a, **k): return self.entry.delete(*a, **k)
    def focus_set(self): return self.entry.focus_set()
    def bind(self, sequence=None, func=None, add=None):
        if not hasattr(self, "entry") or sequence in ("<Configure>", "<Enter>", "<Leave>"):
            return tk.Frame.bind(self, sequence, func, add)
        return self.entry.bind(sequence, func, add)
    def configure(self, cnf=None, **kw):
        if cnf: kw.update(cnf)
        entry_keys = {"state","fg","foreground","insertbackground","font","show","validate","validatecommand","width"}
        ek = {k:v for k,v in list(kw.items()) if k in entry_keys}
        for k in ek: kw.pop(k, None)
        if "foreground" in ek: ek["fg"] = ek.pop("foreground")
        if ek: self.entry.configure(**ek)
        if kw: super().configure(**kw)
    config = configure


class CurrencyEntry(RoundedCard):
    """Money input with a visual currency prefix and numeric-only editable value.

    The currency symbol is never stored in the StringVar, so calculations and the
    database continue to receive plain numbers while users always see the selected
    currency next to the amount.
    """
    def __init__(self, master, app, textvariable=None, fill=None, border=None, radius=13,
                 height=40, fg=None, font=FONT, width=None, max_decimals=2, **kwargs):
        super().__init__(master, fill=fill, border=border, radius=radius,
                         height=height, content_inset=6)
        fill = CARD_2 if fill is None else fill
        border = BORDER if border is None else border
        fg = TEXT if fg is None else fg
        self.app = app
        self._max_decimals = int(max_decimals)
        if width:
            tk.Frame.configure(self, width=width)
        prefix = tk.Label(self.body, text=app.currency, bg=fill, fg=app.accent,
                          font=("Segoe UI Semibold", 10), width=2, anchor="e")
        prefix.pack(side="left", padx=(3, 4))
        vcmd = (self.register(self._validate_money), "%P")
        self.entry = tk.Entry(self.body, textvariable=textvariable, bg=fill, fg=fg,
                              insertbackground=TEXT, relief="flat", bd=0, highlightthickness=0,
                              font=font, validate="key", validatecommand=vcmd,
                              disabledbackground=fill, disabledforeground=MUTED_2, **kwargs)
        self.entry.pack(side="left", fill="both", expand=True, padx=(0, 4))
        self.entry.bind("<FocusIn>", lambda _e: self.set_border(app.accent), add="+")
        self.entry.bind("<FocusOut>", lambda _e: self.set_border(BORDER), add="+")

    def _validate_money(self, proposed):
        if proposed == "":
            return True
        value = proposed.replace(",", ".")
        if value.count(".") > 1:
            return False
        if any((not ch.isdigit()) and ch != "." for ch in value):
            return False
        if "." in value:
            whole, frac = value.split(".", 1)
            if whole and not whole.isdigit():
                return False
            if frac and not frac.isdigit():
                return False
            if len(frac) > self._max_decimals:
                return False
        return True

    def get(self): return self.entry.get()
    def insert(self, *a, **k): return self.entry.insert(*a, **k)
    def delete(self, *a, **k): return self.entry.delete(*a, **k)
    def focus_set(self): return self.entry.focus_set()
    def bind(self, sequence=None, func=None, add=None):
        if not hasattr(self, "entry") or sequence in ("<Configure>", "<Enter>", "<Leave>"):
            return tk.Frame.bind(self, sequence, func, add)
        return self.entry.bind(sequence, func, add)
    def configure(self, cnf=None, **kw):
        if cnf: kw.update(cnf)
        entry_keys = {"state","fg","foreground","insertbackground","font","show","validate","validatecommand","width"}
        ek = {k:v for k,v in list(kw.items()) if k in entry_keys}
        for k in ek: kw.pop(k, None)
        if "foreground" in ek: ek["fg"] = ek.pop("foreground")
        if ek: self.entry.configure(**ek)
        if kw: super().configure(**kw)
    config = configure


class RoundedText(RoundedCard):
    def __init__(self, master, fill=None, border=None, radius=11, height=92,
                 fg=None, font=FONT, width=35, text_height=4):
        fill = CARD_2 if fill is None else fill
        border = BORDER if border is None else border
        fg = TEXT if fg is None else fg
        super().__init__(master, fill=fill, border=border, radius=radius,
                         height=height, content_inset=7)
        self.text = tk.Text(self.body, bg=fill, fg=fg, insertbackground=TEXT, relief="flat",
                            bd=0, highlightthickness=0, width=width, height=text_height, font=font)
        self.text.pack(fill="both", expand=True, padx=3, pady=2)
        self.text.bind("<FocusIn>", lambda _e: self.set_border(ACCENT), add="+")
        self.text.bind("<FocusOut>", lambda _e: self.set_border(BORDER), add="+")
    def get(self,*a,**k): return self.text.get(*a,**k)
    def insert(self,*a,**k): return self.text.insert(*a,**k)
    def delete(self,*a,**k): return self.text.delete(*a,**k)
    def bind(self,sequence=None,func=None,add=None):
        if not hasattr(self, "text") or sequence == "<Configure>":
            return tk.Frame.bind(self, sequence, func, add)
        return self.text.bind(sequence,func,add)
    def focus_set(self): return self.text.focus_set()


class RoundedCombo(RoundedCard):
    def __init__(self, master, textvariable=None, values=(), state="readonly", radius=13,
                 height=40, width=None):
        super().__init__(master, fill=CARD_2, border=BORDER, radius=radius,
                         height=height, content_inset=5)
        if width:
            self.configure(width=width)
        self.combo = ttk.Combobox(self.body, textvariable=textvariable, values=values,
                                  state=state, style="Rounded.TCombobox")
        self.combo.pack(fill="both", expand=True, padx=2, pady=1)
        self.combo.bind("<FocusIn>", lambda _e: self.set_border(ACCENT), add="+")
        self.combo.bind("<FocusOut>", lambda _e: self.set_border(BORDER), add="+")
        # A readonly ttk.Combobox has a native mouse-wheel binding on Windows.
        # That meant simply scrolling the Settings page while the pointer was
        # over Theme / Language / Currency / Tracking interval silently changed
        # the selected value.  Intercept the wheel at widget level and forward
        # it to the surrounding ScrollableFrame instead.  Values now change
        # only after an explicit selection/click.
        self.combo.bind("<MouseWheel>", self._forward_wheel_to_scroller, add="+")
        self.combo.bind("<Button-4>", self._forward_wheel_to_scroller, add="+")
        self.combo.bind("<Button-5>", self._forward_wheel_to_scroller, add="+")

    def _forward_wheel_to_scroller(self, event):
        parent = self.master
        while parent is not None:
            if hasattr(parent, "canvas") and hasattr(parent, "_on_wheel"):
                try:
                    if getattr(event, "num", None) == 4:
                        parent.canvas.yview_scroll(-1, "units")
                    elif getattr(event, "num", None) == 5:
                        parent.canvas.yview_scroll(1, "units")
                    else:
                        parent._on_wheel(event)
                except Exception:
                    pass
                break
            parent = getattr(parent, "master", None)
        # Stop ttk's class-level Combobox wheel handler from changing values.
        return "break"

    def get(self): return self.combo.get()
    def set(self, value): return self.combo.set(value)
    def bind(self,sequence=None,func=None,add=None):
        if not hasattr(self, "combo") or sequence == "<Configure>":
            return tk.Frame.bind(self, sequence, func, add)
        return self.combo.bind(sequence,func,add)


class ToggleSwitch(tk.Canvas):
    """Clean anti-aliased pill switch (V8.12).

    The switch is rendered from high-resolution transparent PNG frames rather
    than raw Canvas ovals.  The track has generous transparent breathing room,
    a fully circular 24 px knob, and no outside glow, preventing clipped or
    protruding edge pixels on Windows DPI scaling.
    """
    _image_cache = {}
    FRAME_COUNT = 21
    IMAGE_W = 72
    IMAGE_H = 42

    def __init__(self, master, app, variable, width=76, height=46):
        try:
            outer = master.cget("bg")
        except Exception:
            outer = CARD_2
        super().__init__(master, width=max(width, self.IMAGE_W+4),
                         height=max(height, self.IMAGE_H+4), bg=outer, bd=0,
                         highlightthickness=0, cursor="hand2", takefocus=1)
        self.app = app
        self.variable = variable
        self.hovered = False
        self._anim_job = None
        self._internal_change = False
        self._frame = self.FRAME_COUNT-1 if bool(self.variable.get()) else 0
        self._last_state = bool(self.variable.get())
        self._photo_ref = None

        self.bind("<Button-1>", self._toggle)
        self.bind("<Return>", self._toggle)
        self.bind("<space>", self._toggle)
        self.bind("<Enter>", lambda _e: self._set_hover(True))
        self.bind("<Leave>", lambda _e: self._set_hover(False))
        self.bind("<Configure>", lambda _e: self.redraw())
        try:
            self.variable.trace_add("write", self._on_variable_change)
        except Exception:
            pass
        self.after_idle(self.redraw)

    @classmethod
    def _sprite(cls, key, hover, frame):
        key = key if key in ACCENT_PRESETS else "violet"
        frame = max(0, min(cls.FRAME_COUNT-1, int(round(frame))))
        cache_key = (key, int(bool(hover)), frame)
        img = cls._image_cache.get(cache_key)
        if img is None:
            path = resource_path("assets", "toggles",
                                 f"{key}_{int(bool(hover))}_{frame}.png")
            try:
                img = tk.PhotoImage(file=path)
            except tk.TclError:
                img = None
            cls._image_cache[cache_key] = img
        return img

    def _set_hover(self, state):
        self.hovered = bool(state)
        self.redraw()

    def _toggle(self, _e=None):
        if self._anim_job:
            try:
                self.after_cancel(self._anim_job)
            except Exception:
                pass
            self._anim_job = None
        self._internal_change = True
        try:
            self.variable.set(not bool(self.variable.get()))
        finally:
            self._internal_change = False
        self._animate_to(bool(self.variable.get()))
        return "break"

    def _on_variable_change(self, *_):
        state = bool(self.variable.get())
        if self._internal_change:
            return
        if state != self._last_state and getattr(self.app, "animations_enabled", True):
            self._animate_to(state)
        else:
            self._last_state = state
            self._frame = self.FRAME_COUNT-1 if state else 0
            self.redraw()

    def _animate_to(self, state):
        self._last_state = bool(state)
        target = self.FRAME_COUNT-1 if state else 0
        if not getattr(self.app, "animations_enabled", True):
            self._frame = target
            self.redraw()
            return
        if self._anim_job:
            try:
                self.after_cancel(self._anim_job)
            except Exception:
                pass
            self._anim_job = None
        start = float(self._frame)
        delta = target - start
        # V8.14: cap UI animation work near 60 FPS. Fewer scheduled redraws
        # reduce Tk main-loop pressure while keeping the same ~220 ms duration.
        steps = 14
        i = 0

        def step():
            nonlocal i
            i += 1
            t = i / steps
            eased = t * t * (3 - 2 * t)
            self._frame = start + delta * eased
            self.redraw()
            if i < steps:
                self._anim_job = self.after(16, step)
            else:
                self._anim_job = None
                self._frame = target
                self.redraw()
        step()

    def _fallback_redraw(self):
        # Asset fallback: deliberately simple and inset far enough to avoid clipping.
        w = max(74, self.winfo_width())
        h = max(44, self.winfo_height())
        x1, y1, x2, y2 = 6, 8, w-6, h-8
        hh = y2-y1
        r = hh/2
        on = bool(self.variable.get())
        track = self.app.accent if on else "#26313D"
        self.create_rectangle(x1+r, y1, x2-r, y2, fill=track, outline="")
        self.create_oval(x1, y1, x1+hh, y2, fill=track, outline="")
        self.create_oval(x2-hh, y1, x2, y2, fill=track, outline="")
        knob_r = (hh-6)/2
        cx = (x2-r-2) if on else (x1+r+2)
        cy = (y1+y2)/2
        self.create_oval(cx-knob_r, cy-knob_r, cx+knob_r, cy+knob_r,
                         fill="#FFFFFF", outline="")

    def redraw(self):
        self.delete("all")
        frame = int(round(self._frame))
        img = self._sprite(getattr(self.app, "accent_key", "violet"),
                           self.hovered, frame)
        if img is None:
            self._fallback_redraw()
            return
        self._photo_ref = img
        # Extra transparent breathing room in the canvas prevents Windows DPI
        # rounding from ever shaving off the anti-aliased edge pixels.
        self.create_image(self.winfo_width()/2, self.winfo_height()/2,
                          image=img, anchor="center")


class AccentChip(tk.Canvas):
    def __init__(self, master, app, key, text, variable, **kwargs):
        try:
            outer = master.cget("bg")
        except Exception:
            outer = CARD_2
        super().__init__(master, width=132, height=40, bg=outer, bd=0, highlightthickness=0,
                         cursor="hand2", **kwargs)
        self.app = app
        self.key = key
        self.text = text
        self.variable = variable
        self.hovered = False
        self.bind("<Configure>", lambda _e: self.redraw())
        self.bind("<Enter>", lambda _e: self._hover(True))
        self.bind("<Leave>", lambda _e: self._hover(False))
        self.bind("<Button-1>", self._choose)
        try:
            self.variable.trace_add("write", lambda *_: self.redraw())
        except Exception:
            pass
        self.redraw()

    def _round(self, x1, y1, x2, y2, r, **kw):
        r=max(2,min(r,(x2-x1)/2,(y2-y1)/2))
        pts=[x1+r,y1,x2-r,y1,x2,y1,x2,y1+r,x2,y2-r,x2,y2,x2-r,y2,x1+r,y2,x1,y2,x1,y2-r,x1,y1+r,x1,y1]
        return self.create_polygon(pts,smooth=True,splinesteps=28,**kw)

    def _choose(self, _event=None):
        self.variable.set(self.key)

    def _hover(self, state):
        self.hovered=state
        self.redraw()

    def redraw(self):
        self.delete("all")
        w=max(10,self.winfo_width()); h=max(10,self.winfo_height())
        color=ACCENT_PRESETS[self.key][0]
        selected=self.variable.get()==self.key
        fill=blend_color(CARD_2, color, .10 if self.hovered else .04)
        border=color if selected else (blend_color(BORDER,color,.32) if self.hovered else BORDER)
        self._round(1,1,w-2,h-2,13,fill=fill,outline=border,width=2 if selected else 1)
        self.create_oval(12,h/2-5,22,h/2+5,fill=color,outline="")
        self.create_text(31,h/2,text=self.text,fill=TEXT,font=FONT_BOLD,anchor="w")
        if selected:
            self.create_text(w-15,h/2,text="✓",fill=color,font=("Segoe UI Semibold",11),anchor="center")


class AccentSelector(tk.Frame):
    def __init__(self, master, app, variable):
        super().__init__(master, bg=CARD_2, bd=0, highlightthickness=0)
        self.app=app; self.variable=variable
        choices=[("violet", app.t("accent.violet")), ("cyan", app.t("accent.cyan")), ("emerald", app.t("accent.emerald"))]
        for i,(key,text) in enumerate(choices):
            chip=AccentChip(self,app,key,text,variable)
            chip.grid(row=0,column=i,sticky="ew",padx=(0 if i==0 else 4,0))
            self.grid_columnconfigure(i,weight=1)


class RoundedProgress(tk.Canvas):
    def __init__(self, master, value=0, bg_track=CARD_3, fill=ACCENT, height=7, **kwargs):
        try: outer = master.cget("bg")
        except Exception: outer = CARD
        super().__init__(master, height=height, bg=outer, bd=0, highlightthickness=0, **kwargs)
        self.value=max(0.0,min(1.0,float(value))); self.track=bg_track; self.fill_color=fill
        self.bind("<Configure>", lambda _e:self.redraw())
    def _pill(self,x1,y1,x2,y2,color):
        r=max(1,(y2-y1)/2)
        self.create_oval(x1,y1,x1+2*r,y2,fill=color,outline="")
        self.create_oval(x2-2*r,y1,x2,y2,fill=color,outline="")
        if x2-x1>2*r: self.create_rectangle(x1+r,y1,x2-r,y2,fill=color,outline="")
    def redraw(self):
        self.delete("all"); w=max(2,self.winfo_width()); h=max(2,self.winfo_height())
        self._pill(0,0,w,h,self.track)
        fw=w*self.value
        if fw>1: self._pill(0,0,max(h,fw),h,self.fill_color)


class RoundedNavButton(tk.Canvas):
    def __init__(self, master, text, icon, command, app, height=46):
        super().__init__(master, height=height, bg=SIDEBAR, bd=0, highlightthickness=0, cursor="hand2")
        self.app = app
        self.text = text
        self.icon = icon
        self.command = command
        self.active = False
        self.hovered = False
        self._hover_progress = 0.0
        self._hover_job = None
        self.bind("<Configure>", lambda _e: self.redraw())
        self.bind("<Enter>", lambda _e: self._hover(True))
        self.bind("<Leave>", lambda _e: self._hover(False))
        self.bind("<Button-1>", lambda _e: self.command())

    def _hover(self, state):
        self.hovered = bool(state)
        target = 1.0 if self.hovered else 0.0
        if self._hover_job:
            try:
                self.after_cancel(self._hover_job)
            except Exception:
                pass
            self._hover_job = None
        if not getattr(self.app, "animations_enabled", True):
            self._hover_progress = target
            self.redraw()
            return
        start = self._hover_progress
        steps = 9
        def tick(i=1):
            t = i / steps
            eased = t * t * (3 - 2 * t)
            self._hover_progress = start + (target - start) * eased
            self.redraw()
            if i < steps:
                self._hover_job = self.after(16, tick, i + 1)
            else:
                self._hover_progress = target
                self._hover_job = None
                self.redraw()
        tick()

    def set_active(self, state):
        self.active = bool(state)
        self.redraw()

    def set_text(self, text):
        self.text = text
        self.redraw()

    def _round(self, x1,y1,x2,y2,r, **kw):
        pts=[x1+r,y1,x2-r,y1,x2,y1,x2,y1+r,x2,y2-r,x2,y2,x2-r,y2,x1+r,y2,x1,y2,x1,y2-r,x1,y1+r,x1,y1]
        return self.create_polygon(pts, smooth=True, splinesteps=24, **kw)

    def redraw(self):
        self.delete("all")
        w=max(self.winfo_width(),180); h=max(self.winfo_height(),46)
        fill = CARD_2 if self.active else blend_color(SIDEBAR, CARD, self._hover_progress)
        if self.active:
            self._round(3, 2, w-3, h-2, 13, fill=fill, outline="")
            self.create_line(5, 13, 5, h-13, fill=self.app.accent, width=3, capstyle=tk.ROUND)
        elif self._hover_progress > 0.01:
            self._round(3, 2, w-3, h-2, 13, fill=fill, outline="")
        fg = TEXT if self.active else MUTED
        self.create_text(20, h/2, text=self.icon, fill=self.app.accent if self.active else MUTED,
                         font=("Segoe UI Symbol", 14), anchor="w")
        self.create_text(54, h/2, text=self.text, fill=fg, font=FONT_BOLD, anchor="w")


class KpiCard(RoundedCard):
    def __init__(self, master, app, title, icon="•", hint="", value_color=TEXT):
        super().__init__(master, fill=CARD, border=BORDER, radius=18, height=128)
        self.app = app
        self._job = None
        self.bind("<Enter>", lambda _e: self.set_border(self.app.accent))
        self.bind("<Leave>", lambda _e: self.set_border(BORDER))
        root = self.body

        head = tk.Frame(root, bg=CARD)
        head.pack(fill="x", padx=16, pady=(14, 0))
        tk.Label(head, text=title, bg=CARD, fg=MUTED, font=FONT_BOLD).pack(side="left")
        icon_wrap = RoundedCard(head, fill=CARD_2, border=CARD_2, radius=9, height=28, content_inset=3)
        tk.Frame.configure(icon_wrap, width=30)
        icon_wrap.pack(side="right")
        tk.Label(icon_wrap.body, text=icon, bg=CARD_2, fg=self.app.accent,
                 font=("Segoe UI Semibold", 10)).pack(expand=True)

        self.value_label = tk.Label(root, text="—", bg=CARD, fg=value_color, font=("Segoe UI Semibold", 24))
        self.value_label.pack(anchor="w", padx=16, pady=(4, 2))
        self.hint_label = tk.Label(root, text=hint, bg=CARD, fg=MUTED_2, font=("Segoe UI", 8),
                                   justify="left", wraplength=250)
        self.hint_label.pack(anchor="w", padx=16, pady=(0, 14))

    def animate_number(self, target, formatter, color=None):
        if color:
            self.value_label.config(fg=color)
        target = D(target)
        if not self.app.animations_enabled:
            self.value_label.config(text=formatter(target))
            return
        if self._job:
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
            self._job = None
        steps = 18

        def tick(i=1):
            if not self.winfo_exists():
                return
            t = i / steps
            eased = 1 - (1 - t) ** 4
            value = target * Decimal(str(eased))
            self.value_label.config(text=formatter(value))
            if i < steps:
                self._job = self.after(16, tick, i + 1)
            else:
                self.value_label.config(text=formatter(target))
                self._job = None

        tick()


class FinancialChart(tk.Canvas):
    def __init__(self, master, app, data=None, **kwargs):
        super().__init__(master, bg=CARD, highlightthickness=0, bd=0, **kwargs)
        self.app = app
        self.data = data or []
        self.bind("<Configure>", lambda _e: self.redraw())

    def set_data(self, data):
        self.data = data or []
        self.redraw()

    def _short_money(self, value):
        if getattr(self.app, "sums_hidden", False): return "••••"
        value = float(value)
        if abs(value) >= 1_000_000:
            return f"{self.app.currency}{value/1_000_000:.1f}M"
        if abs(value) >= 1_000:
            return f"{self.app.currency}{value/1_000:.1f}K"
        return f"{self.app.currency}{value:.0f}"

    def redraw(self):
        self.delete("all")
        w = max(self.winfo_width(), 320)
        h = max(self.winfo_height(), 190)
        left, right, top, bottom = 56, 18, 18, 40
        plot_w = w - left - right
        plot_h = h - top - bottom

        if not self.data:
            self.create_text(w/2, h/2, text=self.app.t("month_no_data"), fill=MUTED, font=FONT)
            return

        max_val = max(max(float(x[1]), float(x[2])) for x in self.data)
        if max_val <= 0:
            max_val = 1

        for i in range(5):
            y = top + plot_h * i / 4
            value = max_val * (1 - i / 4)
            self.create_line(left, y, w-right, y, fill=GRID_LINE, width=1)
            self.create_text(left-8, y, text=self._short_money(value), fill=MUTED_2,
                             font=("Segoe UI", 8), anchor="e")

        groups = len(self.data)
        group_w = plot_w / max(groups, 1)
        bar_w = min(26, group_w * 0.28)
        for idx, (label, invested, projected) in enumerate(self.data):
            cx = left + group_w * idx + group_w / 2
            inv_h = plot_h * float(invested) / max_val
            rev_h = plot_h * float(projected) / max_val
            base = top + plot_h
            self.create_rectangle(cx-bar_w-2, base-inv_h, cx-2, base,
                                  fill=CARD_3, outline="")
            self.create_rectangle(cx+2, base-rev_h, cx+bar_w+2, base,
                                  fill=self.app.accent, outline="")
            self.create_text(cx, h-19, text=label, fill=MUTED, font=("Segoe UI", 8))

        ly = 8
        self.create_rectangle(w-220, ly, w-210, ly+10, fill=CARD_3, outline="")
        self.create_text(w-204, ly+5, text=self.app.t("invested"), fill=MUTED,
                         font=("Segoe UI", 8), anchor="w")
        self.create_rectangle(w-118, ly, w-108, ly+10, fill=self.app.accent, outline="")
        self.create_text(w-102, ly+5, text=self.app.t("projected_revenue_short"), fill=MUTED,
                         font=("Segoe UI", 8), anchor="w")


class DonutChart(tk.Canvas):
    def __init__(self, master, app, sold=0, stock=0, **kwargs):
        super().__init__(master, bg=CARD, highlightthickness=0, bd=0, **kwargs)
        self.app = app
        self.sold = sold
        self.stock = stock
        self.bind("<Configure>", lambda _e: self.redraw())

    def set_data(self, sold, stock):
        self.sold = max(int(sold), 0)
        self.stock = max(int(stock), 0)
        self.redraw()

    def redraw(self):
        self.delete("all")
        w = max(self.winfo_width(), 260)
        h = max(self.winfo_height(), 190)
        total = self.sold + self.stock
        size = min(w * 0.52, h * 0.70)
        x0 = 26
        y0 = (h-size)/2
        x1 = x0 + size
        y1 = y0 + size
        self.create_oval(x0, y0, x1, y1, outline=CARD_3, width=18)
        if total > 0:
            sold_extent = 360 * self.sold / total
            stock_extent = 360 - sold_extent
            self.create_arc(x0, y0, x1, y1, start=90, extent=-sold_extent,
                            style="arc", outline=self.app.accent, width=18)
            if stock_extent > 0:
                self.create_arc(x0, y0, x1, y1, start=90-sold_extent, extent=-stock_extent,
                                style="arc", outline=BLUE, width=18)
        cx = (x0+x1)/2
        cy = (y0+y1)/2
        self.create_text(cx, cy-7, text=str(total), fill=TEXT, font=("Segoe UI Semibold", 20))
        self.create_text(cx, cy+15, text=self.app.t("units"), fill=MUTED_2, font=("Segoe UI", 8))

        lx = x1 + 28
        self.create_oval(lx, h/2-28, lx+10, h/2-18, fill=self.app.accent, outline="")
        self.create_text(lx+18, h/2-23, text=f"{self.app.t('sold_label')}: {self.sold}",
                         fill=TEXT, font=FONT_SMALL, anchor="w")
        self.create_oval(lx, h/2+10, lx+10, h/2+20, fill=BLUE, outline="")
        self.create_text(lx+18, h/2+15, text=f"{self.app.t('stock')}: {self.stock}",
                         fill=TEXT, font=FONT_SMALL, anchor="w")


class TrendLineChart(tk.Canvas):
    """Two-series smooth line/area chart used on the premium dashboard."""
    def __init__(self, master, app, data=None, **kwargs):
        super().__init__(master, bg=CARD, highlightthickness=0, bd=0, **kwargs)
        self.app = app
        self.data = data or []
        self.bind("<Configure>", lambda _e: self.redraw())

    def set_data(self, data):
        self.data = data or []
        self.redraw()

    def _fmt(self, value):
        if getattr(self.app, "sums_hidden", False): return "••••"
        value = float(value)
        if abs(value) >= 1_000_000:
            return f"{self.app.currency}{value/1_000_000:.1f}M"
        if abs(value) >= 1_000:
            return f"{self.app.currency}{value/1_000:.1f}K"
        return f"{self.app.currency}{value:.0f}"

    def redraw(self):
        self.delete("all")
        w = max(self.winfo_width(), 480)
        h = max(self.winfo_height(), 250)
        left, right, top, bottom = 58, 20, 20, 38
        pw, ph = w-left-right, h-top-bottom
        if not self.data:
            self.create_text(w/2, h/2, text=self.app.t("month_no_data"), fill=MUTED, font=FONT)
            return
        vals = [max(float(r[1]), 0) for r in self.data] + [max(float(r[2]), 0) for r in self.data]
        maxv = max(vals + [1.0])
        maxv *= 1.12
        for i in range(5):
            y = top + ph*i/4
            self.create_line(left, y, w-right, y, fill=GRID_LINE, width=1)
            self.create_text(left-9, y, text=self._fmt(maxv*(1-i/4)), fill=MUTED_2,
                             font=("Segoe UI", 8), anchor="e")
        n=len(self.data)
        def pts(series_index):
            out=[]
            for i,row in enumerate(self.data):
                x=left + (pw*i/max(n-1,1))
                y=top + ph*(1-max(float(row[series_index]),0)/maxv)
                out.extend((x,y))
            return out
        p1=pts(1); p2=pts(2)
        # subtle area fills using many vertical translucent-looking strips (solid blended colors)
        base=top+ph
        for points, col in ((p1, blend_color(CARD, self.app.accent, .22)), (p2, blend_color(CARD, GREEN, .17))):
            for i in range(0, len(points)-2, 2):
                x1,y1,x2,y2=points[i],points[i+1],points[i+2],points[i+3]
                steps=max(int(abs(x2-x1)//5),1)
                for j in range(steps+1):
                    t=j/steps
                    x=x1+(x2-x1)*t; y=y1+(y2-y1)*t
                    self.create_line(x,y,x,base,fill=col,width=5)
        if len(p1)>=4:
            self.create_line(*p1, fill=self.app.accent, width=3, smooth=True, splinesteps=18)
            self.create_line(*p2, fill=GREEN, width=3, smooth=True, splinesteps=18)
        else:
            x,y=p1[0],p1[1]
            self.create_oval(x-3,y-3,x+3,y+3,fill=self.app.accent,outline="")
            x,y=p2[0],p2[1]
            self.create_oval(x-3,y-3,x+3,y+3,fill=GREEN,outline="")
        # point markers + x labels
        for i,row in enumerate(self.data):
            x=left + (pw*i/max(n-1,1))
            if i in (0,n-1) or n<=8 or i%2==0:
                self.create_text(x, h-18, text=str(row[0]), fill=MUTED_2, font=("Segoe UI",8))
        for points,col in ((p1,self.app.accent),(p2,GREEN)):
            for i in range(0,len(points),2):
                if i==len(points)-2 or i==0:
                    x,y=points[i],points[i+1]
                    self.create_oval(x-4,y-4,x+4,y+4,fill=col,outline=CARD,width=2)
        # legend
        self.create_oval(w-220, 8, w-210, 18, fill=self.app.accent, outline="")
        self.create_text(w-202,13,text=self.app.t("revenue_short"),fill=MUTED,font=("Segoe UI",8),anchor="w")
        self.create_oval(w-112, 8, w-102, 18, fill=GREEN, outline="")
        self.create_text(w-94,13,text=self.app.t("profit"),fill=MUTED,font=("Segoe UI",8),anchor="w")


class MultiDonutChart(tk.Canvas):
    def __init__(self, master, app, segments=None, center_value="0", center_label="", **kwargs):
        super().__init__(master, bg=CARD, highlightthickness=0, bd=0, **kwargs)
        self.app=app; self.segments=segments or []; self.center_value=center_value; self.center_label=center_label
        self.bind("<Configure>", lambda _e:self.redraw())

    def set_data(self, segments, center_value=None, center_label=None):
        self.segments=segments or []
        if center_value is not None: self.center_value=center_value
        if center_label is not None: self.center_label=center_label
        self.redraw()

    def redraw(self):
        self.delete("all")
        w=max(self.winfo_width(),300); h=max(self.winfo_height(),205)
        total=sum(max(float(v),0) for _n,v,_c in self.segments)
        size=min(h*.62,w*.36); x0=22; y0=(h-size)/2; x1=x0+size; y1=y0+size
        self.create_oval(x0,y0,x1,y1,outline=CARD_3,width=16)
        start=90
        if total>0:
            for name,val,col in self.segments:
                val=max(float(val),0)
                ext=360*val/total
                if ext>0:
                    self.create_arc(x0,y0,x1,y1,start=start,extent=-ext,style="arc",outline=col,width=16)
                start-=ext
        cx=(x0+x1)/2; cy=(y0+y1)/2
        self.create_text(cx,cy-9,text=str(self.center_value),fill=TEXT,font=("Segoe UI Semibold",18))
        label = str(self.center_label)
        if len(label) > 18:
            words = label.split()
            if len(words) > 1:
                mid = max(1, len(words)//2)
                label = " ".join(words[:mid]) + "\n" + " ".join(words[mid:])
        self.create_text(cx,cy+16,text=label,fill=MUTED_2,font=("Segoe UI",7),
                         justify="center", width=max(70, size-26))
        lx=x1+24; y=max(25,(h-len(self.segments)*29)/2)
        for name,val,col in self.segments[:6]:
            pct=(float(val)/total*100) if total else 0
            self.create_oval(lx,y,lx+9,y+9,fill=col,outline="")
            self.create_text(lx+16,y+4,text=name,fill=MUTED,font=("Segoe UI",8),anchor="w")
            self.create_text(w-16,y+4,text=f"{int(val)}   {pct:.0f}%",fill=TEXT,font=("Segoe UI",8),anchor="e")
            y+=29


class WeeklyBarChart(tk.Canvas):
    def __init__(self, master, app, data=None, **kwargs):
        super().__init__(master, bg=CARD, highlightthickness=0, bd=0, **kwargs)
        self.app=app; self.data=data or []
        self.bind("<Configure>", lambda _e:self.redraw())

    def redraw(self):
        self.delete("all")
        w=max(self.winfo_width(),360); h=max(self.winfo_height(),190)
        left,right,top,bottom=42,16,16,34; pw=w-left-right; ph=h-top-bottom
        if not self.data:
            self.create_text(w/2,h/2,text=self.app.t("month_no_data"),fill=MUTED,font=FONT); return
        maxv=max([float(v) for _d,v in self.data]+[1.0])*1.15
        for i in range(4):
            y=top+ph*i/3
            self.create_line(left,y,w-right,y,fill=GRID_LINE)
        gap=pw/max(len(self.data),1); bw=min(32,gap*.45); base=top+ph
        for i,(label,val) in enumerate(self.data):
            cx=left+gap*i+gap/2; bh=ph*float(val)/maxv
            self.create_rectangle(cx-bw/2,base-bh,cx+bw/2,base,fill=self.app.accent,outline="")
            self.create_rectangle(cx-bw/2,base-bh,cx+bw/2,base-bh+5,fill=BLUE,outline="")
            self.create_text(cx,h-16,text=label,fill=MUTED_2,font=("Segoe UI",8))


class StartupSplash(tk.Toplevel):
    """Fast, fully opaque startup splash drawn on a single Canvas."""

    TEXT = {
        "uk": {
            "tagline": "Замовлення • Refund • Tracking • Аналітика",
            "starting": "Запуск програми…",
            "database": "Перевірка локальних даних…",
            "settings": "Завантаження налаштувань…",
            "ui": "Підготовка інтерфейсу…",
            "dashboard": "Завантаження фінансового огляду…",
            "ready": "Усе готово",
            "ready_hint": "Refaund Manager готовий до роботи",
        },
        "en": {
            "tagline": "Orders • Refunds • Tracking • Analytics",
            "starting": "Starting…",
            "database": "Checking local data…",
            "settings": "Loading settings…",
            "ui": "Preparing interface…",
            "dashboard": "Loading financial overview…",
            "ready": "Ready",
            "ready_hint": "Refaund Manager is ready",
        },
        "ru": {
            "tagline": "Заказы • Refund • Tracking • Аналитика",
            "starting": "Запуск программы…",
            "database": "Проверка локальных данных…",
            "settings": "Загрузка настроек…",
            "ui": "Подготовка интерфейса…",
            "dashboard": "Загрузка финансового обзора…",
            "ready": "Готово",
            "ready_hint": "Refaund Manager готов к работе",
        },
    }

    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.progress = 4.0
        self.lang = "uk"
        self.accent = "#8b5cf6"
        self._finish_job = None

        self.overrideredirect(True)
        self.configure(bg=BG)
        try:
            self.attributes("-topmost", True)
        except tk.TclError:
            pass

        width, height = 660, 380
        self._canvas_w, self._canvas_h = width, height
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        x = max(0, (sw - width) // 2)
        y = max(0, (sh - height) // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")

        self.canvas = tk.Canvas(self, width=width, height=height, bg=BG,
                                highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self._draw_static()
        self.set_progress(self.progress, self.TEXT[self.lang]["starting"])

    @staticmethod
    def _mix(c1, c2, t):
        c1, c2 = c1.lstrip("#"), c2.lstrip("#")
        a = tuple(int(c1[i:i+2], 16) for i in (0, 2, 4))
        b = tuple(int(c2[i:i+2], 16) for i in (0, 2, 4))
        return "#%02x%02x%02x" % tuple(round(a[i] + (b[i]-a[i])*t) for i in range(3))

    def _round_rect(self, x1, y1, x2, y2, r, **kw):
        r = max(1, min(r, int((x2-x1)/2), int((y2-y1)/2)))
        points = [
            x1+r, y1, x2-r, y1,
            x2, y1, x2, y1+r,
            x2, y2-r, x2, y2,
            x2-r, y2, x1+r, y2,
            x1, y2, x1, y2-r,
            x1, y1+r, x1, y1,
        ]
        return self.canvas.create_polygon(points, smooth=True, splinesteps=28, **kw)

    def _draw_static(self):
        c = self.canvas
        for y in range(self._canvas_h):
            t = y / max(1, self._canvas_h - 1)
            c.create_line(0, y, self._canvas_w, y,
                          fill=self._mix("#0b0f14", "#0d131c", t))

        self._round_rect(22, 22, self._canvas_w-22, self._canvas_h-22, 28,
                         fill="#101720", outline="#253142", width=1)
        c.create_line(52, 46, self._canvas_w-52, 46, fill="#1f2a38", width=1)

        self.logo_bg = self._round_rect(56, 76, 128, 148, 20,
                                        fill="#111823", outline=self.accent, width=1)
        try:
            self.splash_logo_photo = tk.PhotoImage(file=resource_path("assets", "brand", "mountain_logo_sidebar_large.png"))
            c.create_image(92, 112, image=self.splash_logo_photo)
        except tk.TclError:
            self.splash_logo_photo = None
            c.create_text(92, 112, text="▲", fill="#ffffff",
                          font=("Segoe UI Semibold", 25))
        c.create_text(150, 86, anchor="nw", text=APP_NAME, fill=TEXT,
                      font=("Segoe UI Semibold", 24))
        c.create_text(self._canvas_w-58, 91, anchor="ne",
                      text=f"V{APP_VERSION}", fill=MUTED,
                      font=("Segoe UI Semibold", 10))
        self.tagline_text = c.create_text(151, 124, anchor="nw",
                                          text=self.TEXT[self.lang]["tagline"],
                                          fill=MUTED, font=("Segoe UI", 10))

        chip_y = 177
        chips = [("LOCAL DATA", GREEN), ("TRACKING", BLUE), ("ANALYTICS", AMBER)]
        x = 57
        for label, color in chips:
            w = 142 if label != "ANALYTICS" else 152
            self._round_rect(x, chip_y, x+w, chip_y+38, 16,
                             fill="#121b26", outline="#253142", width=1)
            c.create_oval(x+14, chip_y+14, x+24, chip_y+24, fill=color, outline="")
            c.create_text(x+34, chip_y+19, anchor="w", text=label, fill="#b9c6d8",
                          font=("Segoe UI Semibold", 8))
            x += w + 12

        self.status_text = c.create_text(58, 253, anchor="w", text="", fill=TEXT,
                                         font=("Segoe UI Semibold", 11))
        self.percent_text = c.create_text(self._canvas_w-58, 253, anchor="e", text="0%",
                                          fill=MUTED, font=("Segoe UI Semibold", 10))
        self._round_rect(58, 280, self._canvas_w-58, 294, 7,
                         fill="#202b39", outline="")
        self.progress_fill = None
        self.progress_glow = None
        self.hint_text = c.create_text(58, 324, anchor="w", text="",
                                       fill=MUTED_2, font=("Segoe UI", 9))

    def set_language(self, lang):
        self.lang = lang if lang in self.TEXT else "uk"
        self.canvas.itemconfigure(self.tagline_text,
                                  text=self.TEXT[self.lang]["tagline"])

    def set_accent(self, accent):
        if not accent:
            return
        self.accent = accent
        self.canvas.itemconfigure(self.logo_bg, outline=accent)
        self._render_progress()

    def set_progress(self, value, status=None):
        self.progress = max(0.0, min(100.0, float(value)))
        if status is not None:
            self.canvas.itemconfigure(self.status_text, text=status)
        self.canvas.itemconfigure(self.percent_text, text=f"{int(round(self.progress))}%")
        self._render_progress()
        try:
            self.update_idletasks()
        except tk.TclError:
            pass

    def _render_progress(self):
        c = self.canvas
        if self.progress_fill is not None:
            c.delete(self.progress_fill)
        if self.progress_glow is not None:
            c.delete(self.progress_glow)
        x1, y1, x2, y2 = 58, 280, self._canvas_w-58, 294
        usable = x2 - x1
        end = min(x2, x1 + max(14, usable * self.progress / 100.0))
        self.progress_fill = self._round_rect(x1, y1, end, y2, 7,
                                              fill=self.accent, outline="")
        if end - x1 > 20:
            cap = max(x1, end - 14)
            self.progress_glow = self._round_rect(
                cap, y1+2, end-2, y2-2, 5,
                fill=self._mix(self.accent, "#ffffff", 0.30), outline="")
        else:
            self.progress_glow = None

    def stage(self, value, key):
        text = self.TEXT.get(self.lang, self.TEXT["uk"]).get(key, key)
        self.set_progress(value, text)
        try:
            self.master.update_idletasks()
            self.master.update()
        except tk.TclError:
            pass

    def finish(self, callback):
        self.set_language(getattr(self.master, "language", self.lang))
        ready = self.TEXT[self.lang]["ready"]
        start = self.progress
        frames = 24
        delay = 15

        def step(i=0):
            try:
                exists = self.winfo_exists()
            except tk.TclError:
                exists = False
            if not exists:
                callback()
                return
            t = min(1.0, i / frames)
            eased = 1 - (1 - t) ** 3
            value = start + (100.0 - start) * eased
            if i > frames * 0.58:
                self.canvas.itemconfigure(self.status_text, text=ready)
            self.set_progress(value)
            if i < frames:
                self._finish_job = self.after(delay, lambda: step(i+1))
            else:
                self.canvas.itemconfigure(self.hint_text,
                    text=self.TEXT[self.lang]["ready_hint"])
                self._finish_job = self.after(130, lambda: self._close_and(callback))
        step()

    def _close_and(self, callback):
        try:
            self.attributes("-topmost", False)
        except tk.TclError:
            pass
        try:
            self.destroy()
        finally:
            callback()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        # Fully opaque startup: a black cover hides the UI while the splash is visible.
        self.configure(bg=BG)
        self.title(f"{APP_NAME} {APP_VERSION}")
        try:
            self._window_icon = tk.PhotoImage(file=resource_path("assets", "brand", "mountain_logo_128.png"))
            self.iconphoto(True, self._window_icon)
        except tk.TclError:
            self._window_icon = None
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        win_w = min(1600, max(1080, sw - 70))
        win_h = min(930, max(700, sh - 90))
        self.geometry(f"{win_w}x{win_h}")
        self.minsize(1080, 700)
        if sys.platform == "win32":
            try:
                self.state("zoomed")
            except tk.TclError:
                pass
        self.update_idletasks()
        self._startup_cover = tk.Frame(self, bg=BG, bd=0, highlightthickness=0)
        self._startup_cover.place(x=0, y=0, relwidth=1, relheight=1)
        self._startup_cover.lift()
        self._startup_splash = StartupSplash(self)
        self._startup_splash.stage(8, "starting")

        self.db = Database(DB_FILE)
        self._startup_splash.stage(22, "database")
        self.language = self.db.get_setting("language", "uk")
        if self.language not in I18N:
            self.language = "uk"
        self._startup_splash.set_language(self.language)
        self._startup_splash.stage(34, "settings")
        self.currency = self.db.get_setting("currency", "$") or "$"
        self.theme_key = self.db.get_setting("theme", "dark") or "dark"
        if self.theme_key not in THEME_PRESETS: self.theme_key = "dark"
        apply_theme_globals(self.theme_key)
        self.configure(bg=BG)
        self.sums_hidden = self.db.get_setting("hide_amounts", "0") == "1"
        self.system_tray_enabled = self.db.get_setting("system_tray", "0") == "1"
        self.update_manifest_url = self.db.get_setting("update_manifest_url", "") or ""
        self._tray_icon = None; self._tray_thread = None; self._tray_installing = False; self._force_exit = False; self._latest_update_url = ""; self._auto_update_checked = False; self._auto_update_dialog = None
        self.animations_enabled = self.db.get_setting("animations", "1") != "0"
        self.accent_key = self.db.get_setting("accent", "violet")
        try:
            self.default_buyer_percent = max(0.0, min(100.0, float(self.db.get_setting("default_buyer_percent", "70") or 70)))
        except (TypeError, ValueError):
            self.default_buyer_percent = 70.0
        stored_aftership_key = self.db.get_setting("aftership_api_key", "") or ""
        remember_default = "1" if stored_aftership_key else "0"
        self.remember_aftership_key = self.db.get_setting("remember_aftership_key", remember_default) != "0"
        self.aftership_api_key = stored_aftership_key if self.remember_aftership_key else ""
        self.aftership_connection_state = "unknown"
        self.aftership_connection_error = ""
        try:
            self.tracking_refresh_minutes = int(self.db.get_setting("tracking_refresh_minutes", "30") or 30)
        except (TypeError, ValueError):
            self.tracking_refresh_minutes = 30
        if self.tracking_refresh_minutes not in (15, 30, 60):
            self.tracking_refresh_minutes = 30
        self._tracking_refresh_job = None
        self._tracking_refresh_running = False
        if self.accent_key not in ACCENT_PRESETS:
            self.accent_key = "violet"
        self._apply_accent(self.accent_key)
        self._startup_splash.set_accent(self.accent)
        self._startup_splash.stage(46, "settings")
        self.current_page = "dashboard"
        self.search_entry = None
        self._toast_job = None
        self._is_fullscreen = False
        self._settings_autosave_job = None
        self._settings_autosave_rebuild = False
        self._settings_autosave_busy = False
        # Navigation transition state.  Page changes requested from the sidebar
        # are serialized so rapid clicks cannot leave half-finished animations.
        self._page_transition_running = False
        self._page_transition_pending = None
        self._page_transition_jobs = []
        self._page_transition_overlay = None

        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self._startup_splash.stage(56, "ui")

        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass
        self._style_widgets()
        self._startup_splash.stage(66, "ui")
        self._build_shell()
        self._startup_cover.lift()
        self._startup_splash.lift()
        self._startup_splash.stage(79, "ui")
        self._bind_shortcuts()
        self.show_dashboard()
        self._startup_cover.lift()
        self._startup_splash.lift()
        self._startup_splash.stage(92, "dashboard")
        self.after(60, lambda: self._startup_splash.finish(self._reveal_main_window))
        self.after(2800, self._tracking_auto_tick)
        if self.system_tray_enabled:
            self.after(1200, self._ensure_tray_icon)
        # Quiet startup update check. It never blocks the UI. If a newer online
        # version exists, the user gets a single friendly prompt.
        self.after(1800, self._auto_check_for_updates)

    def _reveal_main_window(self):
        try:
            cover = getattr(self, "_startup_cover", None)
            if cover is not None and cover.winfo_exists():
                cover.destroy()
            self.lift()
            if sys.platform == "win32":
                try:
                    self.state("zoomed")
                except tk.TclError:
                    pass
            self._set_window_alpha_safe(1.0)
            self.focus_force()
        except tk.TclError:
            pass

    def _apply_accent(self, key):
        global ACCENT, ACCENT_HOVER
        self.accent_key = key if key in ACCENT_PRESETS else "violet"
        ACCENT, ACCENT_HOVER = ACCENT_PRESETS[self.accent_key]
        self.accent, self.accent_hover = ACCENT, ACCENT_HOVER

    def t(self, key, **kwargs):
        return tr(self.language, key, **kwargs)

    def money(self, value):
        if getattr(self, "sums_hidden", False): return "••••••"
        return money(value, self.currency)

    def category_label(self, canonical):
        canonical = canonical if canonical in ITEM_CATEGORIES else "Other"
        return self.t(f"category.{canonical}")

    def category_from_label(self, label):
        for canonical in ITEM_CATEGORIES:
            if label in (canonical, self.category_label(canonical)): return canonical
        return "Other"

    def theme_label(self, key): return self.t(f"theme.{key}")
    def theme_from_label(self, label):
        for key in THEME_PRESETS:
            if label in (key, self.theme_label(key)): return key
        return "dark"

    def status_label(self, canonical):
        return self.t(f"status.{canonical}")

    def status_from_label(self, label, allowed):
        for canonical in allowed:
            if label == self.status_label(canonical) or label == canonical:
                return canonical
        return allowed[0]

    def delivery_label(self, tag):
        return self.t(f"delivery.{tag}") if tag in DELIVERY_TAGS else self.t("delivery.unknown")

    def order_status_for_delivery(self, tag, current):
        # Never overwrite the financial/business part of the workflow with a courier scan.
        if current in ("Refund received", "Sent to buyer", "Completed", "Cancelled"):
            return current
        if tag == "Delivered":
            return "Received"
        if tag in ("InTransit", "OutForDelivery", "AvailableForPickup", "AttemptFail", "Exception"):
            return "In transit"
        if tag in ("Pending", "InfoReceived"):
            return "Ordered" if current == "Ordered" else current
        return current

    def _tracking_auto_tick(self):
        self._tracking_refresh_job = None
        if self.aftership_api_key:
            self.refresh_tracking_all(silent=True)
        self._schedule_tracking_tick()

    def _schedule_tracking_tick(self):
        if self._tracking_refresh_job:
            try:
                self.after_cancel(self._tracking_refresh_job)
            except Exception:
                pass
        self._tracking_refresh_job = self.after(max(1, self.tracking_refresh_minutes) * 60 * 1000, self._tracking_auto_tick)

    def refresh_tracking_all(self, silent=False, order_ids=None):
        if self._tracking_refresh_running:
            return
        if not self.aftership_api_key:
            if not silent:
                self.show_toast(self.t("tracking_no_key"), "warning", duration=4200)
            return
        wanted = set(order_ids or [])
        orders = []
        for row in self.db.fetch_orders():
            d = dict(row)
            if wanted and d["id"] not in wanted:
                continue
            number = (d.get("tracking") or "").strip()
            if not number:
                continue
            if not wanted and d.get("status") in ("Completed", "Cancelled"):
                continue
            orders.append({"id": d["id"], "tracking": number, "carrier_slug": d.get("carrier_slug") or "",
                           "order_id": d.get("amazon_order_id") or "", "status": d.get("status") or "Ordered"})
        if not orders:
            return
        self._tracking_refresh_running = True
        if not silent:
            self.show_toast(self.t("tracking_updating"), "info", duration=2200)
        api_key = self.aftership_api_key

        def worker():
            results = []
            for item in orders:
                try:
                    data = aftership_track(api_key, item["tracking"], item["carrier_slug"], item["order_id"])
                    results.append((item, data, None))
                except Exception as exc:
                    results.append((item, None, str(exc)))
            try:
                self.after(0, lambda: self._apply_tracking_results(results, silent))
            except tk.TclError:
                pass
        threading.Thread(target=worker, daemon=True).start()

    def _apply_tracking_results(self, results, silent):
        self._tracking_refresh_running = False
        success = 0
        first_error = None
        for item, data, error in results:
            if error:
                first_error = first_error or error
                continue
            current = item["status"]
            mapped = self.order_status_for_delivery(data.get("tracking_status", ""), current)
            self.db.update_tracking(item["id"], data, mapped if mapped != current else None)
            success += 1
        if self.current_page == "orders":
            try:
                self._fill_orders_tree()
            except Exception:
                pass
        elif self.current_page == "dashboard":
            self.show_dashboard()
        if not silent:
            if success:
                self.show_toast(self.t("tracking_updated"), "success", duration=2600)
            elif first_error:
                self.show_toast(self.t("tracking_error", error=first_error), "error", duration=4800)

    def button(self, master, text, command=None, **kwargs):
        kwargs.setdefault("bg", self.accent)
        kwargs.setdefault("hover", self.accent_hover)
        # Secondary buttons use card surfaces.  Their label must follow the
        # current theme instead of staying hard-coded white (which disappeared
        # almost completely on the light theme).
        if "fg" not in kwargs and kwargs.get("bg") in (CARD, CARD_2, CARD_3, BORDER):
            kwargs["fg"] = TEXT
        return AnimatedButton(
            master, text=text, command=command,
            animations_getter=lambda: self.animations_enabled, **kwargs
        )

    def _style_widgets(self):
        self.style.configure(
            "Treeview", background=CARD, fieldbackground=CARD, foreground=TEXT,
            rowheight=40, bordercolor=CARD, lightcolor=CARD, darkcolor=CARD,
            borderwidth=0, relief="flat", font=FONT
        )
        self.style.configure(
            "Treeview.Heading", background=CARD_2, foreground=TEXT, relief="flat",
            font=FONT_BOLD, padding=(8, 10)
        )
        self.style.map("Treeview", background=[("selected", self.accent)], foreground=[("selected", "white")])
        self.style.map("Treeview.Heading", background=[("active", CARD_3)])
        self.style.configure(
            "TCombobox", fieldbackground=CARD_2, background=CARD_2, foreground=TEXT,
            arrowcolor=TEXT, bordercolor=CARD_2, lightcolor=CARD_2, darkcolor=CARD_2,
            relief="flat", borderwidth=0, padding=7
        )
        self.style.configure(
            "Rounded.TCombobox", fieldbackground=CARD_2, background=CARD_2, foreground=TEXT,
            arrowcolor=TEXT, bordercolor=CARD_2, lightcolor=CARD_2, darkcolor=CARD_2,
            relief="flat", borderwidth=0, padding=6
        )
        for style_name in ("TCombobox", "Rounded.TCombobox"):
            self.style.map(style_name,
                fieldbackground=[("readonly", CARD_2), ("focus", CARD_2)],
                background=[("readonly", CARD_2), ("focus", CARD_2)],
                foreground=[("readonly", TEXT), ("focus", TEXT)],
                selectbackground=[("readonly", CARD_2)],
                selectforeground=[("readonly", TEXT)])
        self.style.configure("Vertical.TScrollbar", background=CARD_2, troughcolor=BG, bordercolor=BG,
                             arrowcolor=MUTED, relief="flat")
        self.option_add("*TCombobox*Listbox.background", CARD_2)
        self.option_add("*TCombobox*Listbox.foreground", TEXT)
        self.option_add("*TCombobox*Listbox.selectBackground", CARD_3)
        self.option_add("*TCombobox*Listbox.selectForeground", TEXT)

    def _bind_shortcuts(self):
        self.bind_all("<Control-n>", lambda _e: self.new_order())
        self.bind_all("<Control-N>", lambda _e: self.new_order())
        self.bind_all("<Control-f>", lambda _e: self.focus_order_search())
        self.bind_all("<Control-F>", lambda _e: self.focus_order_search())
        self.bind_all("<F5>", lambda _e: self.refresh_current())
        self.bind_all("<F11>", self.toggle_fullscreen)
        self.bind_all("<Escape>", self.exit_fullscreen)

    def toggle_fullscreen(self, _event=None):
        """Toggle borderless fullscreen with F11."""
        self._is_fullscreen = not self._is_fullscreen
        try:
            self.attributes("-fullscreen", self._is_fullscreen)
        except tk.TclError:
            # Fallback for window managers that do not support -fullscreen.
            if self._is_fullscreen:
                try:
                    self.state("zoomed")
                except tk.TclError:
                    pass
        if not self._is_fullscreen and sys.platform == "win32":
            self.after(40, lambda: self.state("zoomed"))
        return "break"

    def exit_fullscreen(self, _event=None):
        """Leave fullscreen with Escape without closing the app."""
        if self._is_fullscreen:
            self._is_fullscreen = False
            try:
                self.attributes("-fullscreen", False)
            except tk.TclError:
                pass
            if sys.platform == "win32":
                self.after(40, lambda: self.state("zoomed"))
        return "break"

    def _build_shell(self):
        self.sidebar = tk.Frame(self, bg=SIDEBAR, width=330)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        # Mountain brand header.  The logo is intentionally shown without any
        # surrounding badge/frame: just the crisp transparent artwork on the
        # sidebar.  A dark variant is used automatically in Light theme.
        brand = tk.Frame(self.sidebar, bg=SIDEBAR)
        brand.pack(fill="x", padx=18, pady=(18, 22))
        logo_slot = tk.Frame(brand, bg=SIDEBAR, width=90, height=66)
        logo_slot.pack(side="left")
        logo_slot.pack_propagate(False)
        try:
            logo_file = "mountain_logo_sidebar_v825_light.png" if self.theme_key == "light" else "mountain_logo_sidebar_v825.png"
            self.brand_logo_photo = tk.PhotoImage(file=resource_path("assets", "brand", logo_file))
            tk.Label(logo_slot, image=self.brand_logo_photo, bg=SIDEBAR, bd=0,
                     highlightthickness=0).place(relx=0.5, rely=0.5, anchor="center")
        except tk.TclError:
            self.brand_logo_photo = None
            tk.Label(logo_slot, text="▲", bg=SIDEBAR, fg=TEXT,
                     font=("Segoe UI Semibold", 28)).place(relx=0.5, rely=0.5, anchor="center")

        texts = tk.Frame(brand, bg=SIDEBAR)
        texts.pack(side="left", padx=(8, 0), fill="x", expand=True)
        tk.Label(texts, text="Refaund Manager", bg=SIDEBAR, fg=TEXT,
                 font=("Segoe UI Semibold", 13)).pack(anchor="w", pady=(7, 0))
        self.subtitle_label = tk.Label(texts, text="Mountain", bg=SIDEBAR, fg=MUTED,
                                       font=("Segoe UI", 9))
        self.subtitle_label.pack(anchor="w", pady=(2, 0))

        tk.Label(self.sidebar, text=self.t("overview").upper(), bg=SIDEBAR, fg=MUTED_2,
                 font=("Segoe UI Semibold", 8)).pack(anchor="w", padx=22, pady=(2, 8))

        self.nav_container = tk.Frame(self.sidebar, bg=SIDEBAR)
        self.nav_container.pack(fill="x", padx=10)
        self.nav_buttons = {}
        # Keep the sidebar intentionally minimal, matching the reference layout.
        # Products / Sales / Refunds / Expenses remain part of the data model but
        # no longer clutter the main navigation.
        self.nav_defs = [
            ("dashboard", "dashboard", "⌂", lambda: self.navigate_to("dashboard")),
            ("orders", "orders", "▣", lambda: self.navigate_to("orders")),
            ("analytics", "analytics", "⌁", lambda: self.navigate_to("analytics")),
            ("instructions", "instructions", "?", lambda: self.navigate_to("instructions")),
            ("settings", "settings", "⚙", lambda: self.navigate_to("settings")),
        ]
        for page, key, icon, cmd in self.nav_defs:
            b = RoundedNavButton(self.nav_container, self.t(key), icon, cmd, self)
            b.pack(fill="x", pady=3)
            self.nav_buttons[page] = (b, icon, key)

        tk.Frame(self.sidebar, bg=SIDEBAR).pack(fill="both", expand=True)

        info_card = RoundedCard(self.sidebar, fill=CARD, border=BORDER, radius=16, height=144, content_inset=7)
        info_card.pack(fill="x", padx=14, pady=(0, 12))
        info = info_card.body
        tk.Label(info, text="●  LOCAL DATA", bg=CARD, fg=GREEN,
                 font=("Segoe UI Semibold", 8)).pack(anchor="w", padx=12, pady=(10, 3))
        self.saved_label = tk.Label(info, text=self.t("data_saved"), bg=CARD, fg=MUTED,
                                    font=("Segoe UI", 9), justify="left", wraplength=250)
        self.saved_label.pack(anchor="w", fill="x", padx=12, pady=(0, 3))
        self.version_label = tk.Label(info, text=self.t("version", version=APP_VERSION), bg=CARD, fg=MUTED_2,
                                      font=("Segoe UI", 9), justify="left", wraplength=250)
        self.version_label.pack(anchor="w", fill="x", padx=12, pady=(1, 1))
        self.made_by_label = tk.Label(info, text="Made by Maki", bg=CARD, fg=TEXT,
                                      font=("Segoe UI Semibold", 9), justify="left")
        self.made_by_label.pack(anchor="w", padx=12, pady=(2, 0))
        self.mountain_footer_label = tk.Label(info, text="Mountain", bg=CARD, fg=MUTED,
                                              font=("Segoe UI", 8), justify="left")
        self.mountain_footer_label.pack(anchor="w", padx=12, pady=(0, 8))

        self.content = tk.Frame(self, bg=BG)
        self.content.pack(side="left", fill="both", expand=True)

    def _refresh_shell_texts(self):
        self.subtitle_label.config(text="Mountain")
        self.saved_label.config(text=self.t("data_saved"))
        self.version_label.config(text=self.t("version", version=APP_VERSION))
        for page, (b, _icon, key) in self.nav_buttons.items():
            b.set_text(self.t(key))
        self._set_active(self.current_page)

    def _startup_animation(self):
        # V8.14 performance fix: never animate the alpha of the whole Windows
        # window. DWM composition of a large translucent Tk window is expensive
        # and can look like 20 FPS on some PCs. Keep the app fully opaque.
        self._set_window_alpha_safe(1.0)

    def fade_in_window(self, window):
        # Keep dialogs fully opaque as well. Their content animations remain, but
        # Windows never has to continuously composite a translucent Toplevel.
        try:
            window.attributes("-alpha", 1.0)
        except tk.TclError:
            pass

    def _page_renderer(self, name):
        return {
            "dashboard": self.show_dashboard,
            "orders": self.show_orders,
            "analytics": self.show_analytics,
            "instructions": self.show_instructions,
            "settings": self.show_settings,
        }.get(name, self.show_dashboard)

    @staticmethod
    def _ease_out_cubic(t):
        t = max(0.0, min(1.0, float(t)))
        return 1.0 - (1.0 - t) ** 3

    @staticmethod
    def _ease_in_out_cubic(t):
        t = max(0.0, min(1.0, float(t)))
        return 4 * t * t * t if t < 0.5 else 1 - ((-2 * t + 2) ** 3) / 2

    def _set_window_alpha_safe(self, value):
        try:
            self.attributes("-alpha", max(0.0, min(1.0, float(value))))
        except tk.TclError:
            pass

    def _finish_page_transition(self):
        """Finish the lightweight V8.15 navigation animation."""
        overlay = getattr(self, "_page_transition_overlay", None)
        if overlay is not None:
            try:
                if overlay.winfo_exists():
                    overlay.destroy()
            except tk.TclError:
                pass
        self._page_transition_overlay = None
        self._page_transition_running = False
        self._page_transition_jobs.clear()

        pending = self._page_transition_pending
        self._page_transition_pending = None
        if pending and pending != self.current_page:
            self.after_idle(lambda p=pending: self.navigate_to(p))

    def _transition_overlay_geometry(self):
        self.update_idletasks()
        try:
            x = self.content.winfo_x()
            y = self.content.winfo_y()
            w = max(1, self.content.winfo_width())
            h = max(1, self.content.winfo_height())
        except tk.TclError:
            return 0, 0, 1, 1
        return x, y, w, h

    def navigate_to(self, name):
        """Switch pages with a tiny accent sweep instead of moving a full page.

        V8.15 intentionally animates only a very small 3 px indicator.  Large
        Tk frames, tables and charts are never translated or made translucent,
        which avoids the low-FPS look seen with page wipes/slides on Windows.
        The actual page is swapped once, around the middle of the sweep.
        """
        if name not in ("dashboard", "orders", "analytics", "instructions", "settings"):
            name = "dashboard"

        if self._page_transition_running:
            self._page_transition_pending = name
            return

        if name == self.current_page:
            return

        if not self.animations_enabled:
            self._page_renderer(name)()
            return

        self._page_transition_running = True
        self._page_transition_pending = None
        self._set_window_alpha_safe(1.0)

        x, y, w, _h = self._transition_overlay_geometry()
        # Small, opaque navigation cue.  It lives at the very top of the content
        # and is the only object that moves during a page change.
        track_h = 3
        indicator_w = max(72, min(150, int(w * 0.10)))
        indicator = tk.Frame(self, bg=self.accent, bd=0, highlightthickness=0)
        indicator.place(x=x, y=y, width=indicator_w, height=track_h)
        indicator.lift()
        self._page_transition_overlay = indicator

        # Keep the animation short.  14 small-frame updates over ~170 ms feels
        # responsive while being dramatically cheaper than redrawing a full page.
        frames = 14
        frame_ms = 12
        switched = {"done": False}

        def swap_page():
            if switched["done"]:
                return
            switched["done"] = True
            target = self._page_transition_pending or name
            self._page_transition_pending = None
            try:
                self._page_renderer(target)()
                self.update_idletasks()
            except tk.TclError:
                self._finish_page_transition()

        def animate(i=0):
            if not self.winfo_exists():
                return
            if i >= frames // 2 and not switched["done"]:
                swap_page()
                if not self._page_transition_running:
                    return

            t = self._ease_in_out_cubic(i / frames)
            # Sweep left -> right while keeping the moving area tiny.
            travel = max(0, w - indicator_w)
            px = x + round(travel * t)
            try:
                if indicator.winfo_exists():
                    indicator.place_configure(x=px, y=y, width=indicator_w, height=track_h)
            except tk.TclError:
                self._finish_page_transition()
                return

            if i < frames:
                job = self.after(frame_ms, animate, i + 1)
                self._page_transition_jobs.append(job)
            else:
                if not switched["done"]:
                    swap_page()
                self._finish_page_transition()

        animate()

    def _clear(self):
        # A spacer can still exist for a few milliseconds if another subsystem
        # refreshes the current page.  Destroying all children is safe; the
        # transition finalizer tolerates an already-destroyed spacer.
        for w in self.content.winfo_children():
            w.destroy()

    def _set_active(self, name):
        self.current_page = name
        for key, (b, _icon, _label) in self.nav_buttons.items():
            b.set_active(key == name)

    def _header(self, title_key, subtitle_key, action_text=None, action=None, secondary=None, show_search=False):
        header = tk.Frame(self.content, bg=BG)
        header.pack(fill="x", padx=24, pady=(18, 12))

        left = tk.Frame(header, bg=BG)
        left.pack(side="left")
        tk.Label(left, text=self.t(title_key), bg=BG, fg=TEXT,
                 font=("Segoe UI Semibold", 23)).pack(anchor="w")
        tk.Label(left, text=self.t(subtitle_key), bg=BG, fg=MUTED,
                 font=("Segoe UI", 9)).pack(anchor="w", pady=(2, 0))

        right = tk.Frame(header, bg=BG)
        right.pack(side="right")
        privacy_text = self.t("show_amounts") if self.sums_hidden else self.t("hide_amounts")
        self.button(right, privacy_text, self.toggle_amount_visibility, bg=CARD_2, hover=CARD_3, radius=14, height=40, padx=12).pack(side="left", padx=(0,8))
        if secondary:
            self.button(right, secondary[0], secondary[1], bg=CARD_2, hover=CARD_3).pack(side="left", padx=(0, 8))
        if action_text and action:
            self.button(right, action_text, action).pack(side="left")

        if show_search:
            search_card = RoundedCard(header, fill=CARD, border=BORDER, radius=14, height=42)
            search_card.pack(side="right", padx=(0, 12), ipadx=1)
            search_card.configure(width=340)
            search_card.pack_propagate(False)
            search_wrap = search_card.body
            tk.Label(search_wrap, text="⌕", bg=CARD, fg=MUTED, font=("Segoe UI", 14)).pack(side="left", padx=(10, 4))
            e = tk.Entry(search_wrap, bg=CARD, fg=MUTED_2, insertbackground=TEXT, relief="flat",
                         bd=0, width=31, font=("Segoe UI", 9))
            e.insert(0, self.t("search_global"))
            e.pack(side="left", padx=(2, 10), pady=7)
            def focus_in(_e):
                if e.get() == self.t("search_global"):
                    e.delete(0, "end"); e.config(fg=TEXT)
            def focus_out(_e):
                if not e.get().strip():
                    e.insert(0, self.t("search_global")); e.config(fg=MUTED_2)
            def do_search(_e=None):
                q=e.get().strip()
                if q and q != self.t("search_global"):
                    self.show_orders()
                    self.after(60, lambda: self._apply_external_search(q))
            e.bind("<FocusIn>", focus_in); e.bind("<FocusOut>", focus_out); e.bind("<Return>", do_search)
        return header

    def _apply_external_search(self, q):
        if hasattr(self, "search_var"):
            self.search_var.set(q)
        if self.search_entry and self.search_entry.winfo_exists():
            self.search_entry.delete(0, "end")
            self.search_entry.insert(0, q)
            self.search_entry.config(fg=TEXT)
        self._fill_orders_tree()

    def _section_header(self, parent, title, hint=None, right_text=None):
        row = tk.Frame(parent, bg=CARD)
        row.pack(fill="x", padx=16, pady=(14, 10))
        left = tk.Frame(row, bg=CARD)
        left.pack(side="left", fill="x", expand=True)
        tk.Label(left, text=title, bg=CARD, fg=TEXT, font=FONT_SUBTITLE).pack(anchor="w", pady=(0, 1))
        if hint:
            hint_label = tk.Label(left, text=hint, bg=CARD, fg=MUTED_2, font=("Segoe UI", 8),
                                  justify="left", anchor="w", wraplength=520)
            hint_label.pack(anchor="w", fill="x", pady=(3, 2))
            left.bind("<Configure>", lambda e, lbl=hint_label: lbl.configure(wraplength=max(180, e.width - 8)), add="+")
        if right_text:
            badge = AnimatedButton(row, text=right_text, command=None, bg=CARD_2, hover=CARD_2, fg=MUTED,
                                   animations_getter=lambda: False, radius=10, height=28, padx=10, font=FONT_SMALL)
            badge.configure(cursor="arrow")
            badge.pack(side="right")
        return row

    def _get_all_with_totals(self):
        result = []
        for order in self.db.fetch_orders():
            items = self.db.get_items(order["id"])
            result.append((order, items, order_totals(order, items)))
        return result

    def _stats(self, all_data=None):
        all_data = all_data if all_data is not None else self._get_all_with_totals()
        total_expenses = sum((t["gross_expenses"] for _, _, t in all_data), Decimal("0"))
        buyer_received = sum((t["buyer_received"] for _, _, t in all_data), Decimal("0"))
        buyer_expected = sum((t["buyer_expected"] for _, _, t in all_data), Decimal("0"))
        realized_profit = sum((t["realized_profit"] for _, _, t in all_data), Decimal("0"))
        projected_profit = sum((t["projected_profit"] for _, _, t in all_data), Decimal("0"))
        refund_total = sum((t["refund"] for _, _, t in all_data), Decimal("0"))
        refunds = sum(1 for o, _, _ in all_data if o["refunded"])
        total_units = sum(sum(int(i["qty"] or 0) for i in items) for _, items, _ in all_data)
        sent_units = sum(
            sum(int(i["qty"] or 0) for i in items)
            for o, items, t in all_data
            if t.get("buyer_sent") or t.get("buyer_paid") or (o["status"] in ("Sent to buyer", "Completed"))
        )
        stock_units = max(total_units - sent_units, 0)
        inventory_value = sum(
            t["purchase"] for o, _items, t in all_data
            if not (t.get("buyer_sent") or t.get("buyer_paid") or (o["status"] in ("Sent to buyer", "Completed")))
        )
        capital_tied = sum((t["capital_tied"] for _, _, t in all_data), Decimal("0"))
        count = len(all_data)
        roi = projected_profit / total_expenses * 100 if total_expenses > 0 else Decimal("0")
        avg_order = total_expenses / count if count else Decimal("0")
        refund_rate = Decimal(refunds) / Decimal(count) * 100 if count else Decimal("0")
        active = sum(1 for o, _, _ in all_data if (o["status"] or "Ordered") not in ("Completed", "Cancelled"))
        completed = sum(1 for o, _, _ in all_data if (o["status"] or "Ordered") == "Completed")
        return {
            "total_expenses": total_expenses, "realized_revenue": buyer_received,
            "projected_revenue": buyer_expected, "realized_profit": realized_profit,
            "projected_profit": projected_profit, "refund_total": refund_total, "refunds": refunds,
            "buyer_received": buyer_received, "buyer_expected": buyer_expected, "capital_tied": capital_tied,
            "total_units": total_units, "sold_units": sent_units, "stock_units": stock_units,
            "inventory_value": inventory_value, "count": count, "roi": roi, "avg_order": avg_order,
            "refund_rate": refund_rate, "active": active, "completed": completed,
        }

    def _monthly_data(self, all_data):
        grouped = defaultdict(lambda: [Decimal("0"), Decimal("0")])
        for order, _items, totals in all_data:
            raw = (order["purchase_date"] or "")[:7]
            try: label = datetime.strptime(raw, "%Y-%m").strftime("%Y-%m")
            except ValueError: label = raw or "—"
            grouped[label][0] += totals["gross_expenses"]
            grouped[label][1] += totals["refund"] + totals["buyer_expected"]
        keys = sorted(grouped.keys())[-6:]
        return [(k, grouped[k][0], grouped[k][1]) for k in keys]

    def _top_products(self, all_data):
        agg = {}
        for order, items, totals in all_data:
            pct = totals["buyer_percent"] / Decimal("100")
            refunded_ratio = (totals["refund"] / totals["purchase"]) if totals["purchase"] > 0 else Decimal("0")
            for i in items:
                name = (i["name"] or "—").strip() or "—"; key = name.lower()
                if key not in agg: agg[key] = {"name": name, "qty": 0, "sold": 0, "cost": Decimal("0"), "rev": Decimal("0")}
                qty = int(i["qty"] or 0); subtotal = D(i["buy_price"]) * qty
                item_refund = subtotal * refunded_ratio
                payout = subtotal * pct
                contribution = item_refund + payout - subtotal
                agg[key]["qty"] += qty
                if totals.get("buyer_sent") or totals["buyer_paid"] or order["status"] in ("Sent to buyer", "Completed"): agg[key]["sold"] += qty
                agg[key]["cost"] += subtotal
                agg[key]["rev"] += subtotal + contribution
        rows=[]
        for x in agg.values():
            profit=x["rev"]-x["cost"]; per=profit/x["qty"] if x["qty"] else Decimal("0")
            rows.append((x["name"],x["qty"],x["sold"],profit,per))
        rows.sort(key=lambda r:r[3], reverse=True)
        return rows

    def _trend_data(self, all_data):
        grouped = defaultdict(lambda: [Decimal("0"), Decimal("0")])
        for order, _items, totals in all_data:
            raw=order["purchase_date"] or ""
            try: key=datetime.strptime(raw,"%Y-%m-%d").strftime("%Y-%m-%d")
            except ValueError: key=raw or "—"
            grouped[key][0] += totals["refund"] + totals["buyer_expected"]
            grouped[key][1] += totals["projected_profit"]
        keys=sorted(grouped.keys())[-10:]; rows=[]
        for key in keys:
            try: label=datetime.strptime(key,"%Y-%m-%d").strftime("%d.%m")
            except ValueError: label=key[-5:] if len(key)>5 else key
            rows.append((label,grouped[key][0],grouped[key][1]))
        return rows

    def _weekly_data(self, all_data):
        vals=[Decimal("0") for _ in range(7)]
        for order,_items,totals in all_data:
            try: wd=datetime.strptime(order["purchase_date"] or "","%Y-%m-%d").weekday()
            except ValueError: continue
            vals[wd]+=totals["buyer_received"]
        names={"uk":["Пн","Вт","Ср","Чт","Пт","Сб","Нд"],"en":["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],"ru":["Пн","Вт","Ср","Чт","Пт","Сб","Вс"]}[self.language]
        return list(zip(names,vals))

    def _status_segments(self, all_data):
        counts=defaultdict(int)
        colors=[self.accent, GREEN, BLUE, AMBER, RED, PURPLE]
        for o,_items,_t in all_data:
            counts[o["status"] or "Ordered"] += 1
        seg=[]
        for idx,status in enumerate(ORDER_STATUSES):
            if counts[status]:
                seg.append((self.status_label(status), counts[status], colors[idx % len(colors)]))
        return seg

    def show_dashboard(self):
        self._clear()
        self._set_active("dashboard")
        self._header("dashboard_title", "dashboard_subtitle", self.t("new_order"), self.new_order,
                     secondary=(self.t("refresh"), self.show_dashboard), show_search=True)

        scroll = ScrollableFrame(self.content, BG)
        scroll.pack(fill="both", expand=True, pady=(0, 10))
        body = scroll.inner
        all_data = self._get_all_with_totals()
        s = self._stats(all_data)

        # --- top KPI row: six rounded cards, same visual rhythm as the reference ---
        cards = tk.Frame(body, bg=BG)
        cards.pack(fill="x", padx=24, pady=(0, 14))
        cards.grid_rowconfigure(0, minsize=128)
        kpis = [
            (self.t("total_invested_short"), s["total_expenses"], "▣", TEXT, "money"),
            (self.t("refund_total_short"), s["refund_total"], "↶", AMBER, "money"),
            (self.t("revenue_short"), s["buyer_received"], "↗", BLUE, "money"),
            (self.t("net_profit_short"), s["projected_profit"], "●", GREEN if s["projected_profit"] >= 0 else RED, "money"),
            (self.t("capital_tied"), s["capital_tied"], "◇", AMBER if s["capital_tied"] > 0 else GREEN, "money"),
            (self.t("roi_short"), s["roi"], "%", GREEN if s["roi"] >= 0 else RED, "pct"),
        ]
        for i, (title, value, icon, color, kind) in enumerate(kpis):
            card = KpiCard(cards, self, title, icon, "", color)
            card.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 6, 0 if i == 5 else 6))
            cards.grid_columnconfigure(i, weight=1, uniform="premium_kpi")
            if kind == "money":
                card.animate_number(value, lambda v: self.money(v), color)
            elif kind == "pct":
                card.animate_number(value, lambda v: f"{v:.1f}%", color)
            else:
                card.animate_number(value, lambda v: str(int(v)), color)

        # --- large central analytics card + two right-side rounded cards ---
        main = tk.Frame(body, bg=BG)
        main.pack(fill="x", padx=24, pady=(0, 14))
        main.grid_columnconfigure(0, weight=2)
        main.grid_columnconfigure(1, weight=1)
        main.grid_rowconfigure(0, minsize=192)
        main.grid_rowconfigure(1, minsize=192)

        trend_card = RoundedCard(main, fill=CARD, border=BORDER, radius=20, height=396)
        trend_card.grid(row=0, column=0, rowspan=2, sticky="nsew", padx=(0, 7))
        trend_box = trend_card.body
        self._section_header(trend_box, self.t("revenue_profit_trend"), self.t("trend_hint"), "30D")
        TrendLineChart(trend_box, self, self._trend_data(all_data), height=330).pack(fill="both", expand=True, padx=8, pady=(0, 10))

        status_card = RoundedCard(main, fill=CARD, border=BORDER, radius=20, height=192)
        status_card.grid(row=0, column=1, sticky="nsew", padx=(7, 0), pady=(0, 7))
        status_box = status_card.body
        self._section_header(status_box, self.t("order_status_chart"), right_text=self.t("view_all"))
        MultiDonutChart(status_box, self, self._status_segments(all_data), str(s["count"]), self.t("total_orders_short"), height=136).pack(fill="both", expand=True, padx=6, pady=(0, 7))

        stock_card = RoundedCard(main, fill=CARD, border=BORDER, radius=20, height=192)
        stock_card.grid(row=1, column=1, sticky="nsew", padx=(7, 0), pady=(7, 0))
        stock_box = stock_card.body
        self._section_header(stock_box, self.t("sold_vs_stock"), right_text=self.t("view_all"))
        stock_segments = [
            (self.t("sold_label"), s["sold_units"], self.accent),
            (self.t("stock"), s["stock_units"], GREEN),
        ]
        MultiDonutChart(stock_box, self, stock_segments, str(s["total_units"]), self.t("units"), height=136).pack(fill="both", expand=True, padx=6, pady=(0, 7))

        # --- three equal rounded cards underneath, like the reference composition ---
        bottom = tk.Frame(body, bg=BG)
        bottom.pack(fill="x", padx=24, pady=(0, 14))
        bottom.grid_columnconfigure(0, weight=3)
        bottom.grid_columnconfigure(1, weight=2)
        bottom.grid_columnconfigure(2, weight=2)
        bottom.grid_rowconfigure(0, minsize=320)

        top_card = RoundedCard(bottom, fill=CARD, border=BORDER, radius=20, height=320)
        top_card.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        top_box = top_card.body
        self._section_header(top_box, self.t("top_profitable"), right_text=self.t("view_all"))
        cols = ("product", "sold", "profit", "per")
        tree = ttk.Treeview(top_box, columns=cols, show="headings", height=6)
        for c, h, wid, anchor in [
            ("product", self.t("product_name_short"), 210, "w"),
            ("sold", self.t("sold_label"), 70, "center"),
            ("profit", self.t("profit"), 105, "e"),
            ("per", self.t("unit_profit"), 105, "e")]:
            tree.heading(c, text=h); tree.column(c, width=wid, anchor=anchor)
        tree.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self._configure_tree_tags(tree)
        for idx, (name, qty, sold, profit, per) in enumerate(self._top_products(all_data)[:6]):
            tree.insert("", "end", tags=("even" if idx % 2 == 0 else "odd",),
                        values=(name, sold, self.money(profit), self.money(per)))

        weekly_card = RoundedCard(bottom, fill=CARD, border=BORDER, radius=20, height=320)
        weekly_card.grid(row=0, column=1, sticky="nsew", padx=7)
        weekly_box = weekly_card.body
        self._section_header(weekly_box, self.t("weekly_sales"), self.t("weekly_hint"))
        WeeklyBarChart(weekly_box, self, self._weekly_data(all_data), height=202).pack(fill="both", expand=True, padx=6, pady=(0, 6))
        total_week = sum((v for _d, v in self._weekly_data(all_data)), Decimal("0"))
        tk.Label(weekly_box, text=self.money(total_week), bg=CARD, fg=TEXT,
                 font=("Segoe UI Semibold", 18)).pack(anchor="w", padx=16, pady=(0, 2))
        tk.Label(weekly_box, text=self.t("revenue_short"), bg=CARD, fg=MUTED_2,
                 font=("Segoe UI", 8)).pack(anchor="w", padx=16, pady=(0, 12))

        refund_card = RoundedCard(bottom, fill=CARD, border=BORDER, radius=20, height=320)
        refund_card.grid(row=0, column=2, sticky="nsew", padx=(7, 0))
        refund_box = refund_card.body
        self._section_header(refund_box, self.t("refund_overview"), right_text=self.t("view_all"))
        refund_segments = [
            (self.t("refund_orders"), s["refunds"], RED),
            (self.t("no_refund"), max(s["count"] - s["refunds"], 0), CARD_3),
        ]
        MultiDonutChart(refund_box, self, refund_segments, str(s["refunds"]), self.t("refund_orders"), height=202).pack(fill="both", expand=True, padx=6, pady=(0, 2))
        refund_info = RoundedCard(refund_box, fill=CARD_2, border=BORDER, radius=12, height=58, content_inset=7)
        refund_info.pack(fill="x", padx=12, pady=(0, 12))
        tk.Label(refund_info.body, text=f"{self.t('refund_sum')}:  {self.money(s['refund_total'])}",
                 bg=CARD_2, fg=AMBER, font=FONT_BOLD).pack(anchor="w", padx=10, pady=(10, 12))

        # Recent orders kept as a final rounded table card.
        recent_card = RoundedCard(body, fill=CARD, border=BORDER, radius=20, height=260)
        recent_card.pack(fill="x", padx=24, pady=(0, 16))
        recent = recent_card.body
        self._section_header(recent, self.t("recent_orders"), right_text=f"{s['count']} {self.t('order_count_label')}")
        if not all_data:
            tk.Label(recent, text=self.t("no_orders_yet"), bg=CARD, fg=MUTED, font=FONT, pady=26).pack(fill="x")
        else:
            cols = ("store", "order", "date", "products", "expenses", "revenue", "profit", "status", "refund")
            tree = ttk.Treeview(recent, columns=cols, show="headings", height=5)
            heads = [self.t("store"), self.t("order_id"), self.t("date"), self.t("products"), self.t("expenses"),
                     self.t("revenue"), self.t("profit"), self.t("status"), self.t("refund")]
            for c, h in zip(cols, heads):
                tree.heading(c, text=h); tree.column(c, width=110, anchor="center")
            tree.column("store", width=125, anchor="w")
            tree.column("order", width=150, anchor="w")
            tree.pack(fill="both", expand=True, padx=12, pady=(0, 12))
            self._configure_tree_tags(tree)
            for idx, (o, items, t) in enumerate(all_data[:8]):
                names = ", ".join(i["name"] for i in items[:2])
                if len(items) > 2:
                    names += f" +{len(items)-2}"
                tree.insert("", "end", tags=("even" if idx % 2 == 0 else "odd",), values=(
                    o["store"] or "—", o["amazon_order_id"], o["purchase_date"], names,
                    self.money(t["gross_expenses"]), self.money(t["realized_revenue"]),
                    self.money(t["projected_profit"]), self.status_label(o["status"]),
                    "✓" if o["refunded"] else "—"
                ))

    def _dashboard_edit(self, tree):
        sel = tree.selection()
        if not sel:
            return
        iid = sel[0]
        try:
            order_id = int(iid.split("-")[-1])
        except Exception:
            return
        OrderDialog(self, self, self.db, order_id=order_id, on_saved=self._after_save)

    def _configure_tree_tags(self, tree):
        tree.tag_configure("even", background=CARD)
        tree.tag_configure("odd", background=ROW_ALT)
        tree.tag_configure("refund", foreground=AMBER)
        tree.tag_configure("completed", foreground=GREEN)
        tree.tag_configure("cancelled", foreground=RED)

    def _row_tag(self, order, idx):
        if order["refunded"]:
            return "refund"
        status = order["status"] or "Ordered"
        if status == "Completed":
            return "completed"
        if status == "Cancelled":
            return "cancelled"
        return "even" if idx % 2 == 0 else "odd"

    def show_orders(self):
        self._clear()
        self._set_active("orders")
        self._header("orders_title", "orders_subtitle", self.t("new_order"), self.new_order,
                     secondary=(self.t("tracking_update_all"), lambda: self.refresh_tracking_all(silent=False)))

        all_data = self._get_all_with_totals()
        s = self._stats(all_data)
        mini = tk.Frame(self.content, bg=BG)
        mini.pack(fill="x", padx=28, pady=(0, 10))
        mini_specs = [
            (self.t("orders_count"), str(s["count"]), TEXT),
            (self.t("active_orders"), str(s["active"]), BLUE),
            (self.t("refunds_count"), str(s["refunds"]), AMBER),
            (self.t("projected_profit"), self.money(s["projected_profit"]), GREEN if s["projected_profit"] >= 0 else RED),
        ]
        for i, (label, value, color) in enumerate(mini_specs):
            card = RoundedCard(mini, fill=CARD, border=BORDER, radius=16, height=72, content_inset=7)
            card.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 5, 0 if i == 3 else 5))
            mini.grid_columnconfigure(i, weight=1, uniform="ordermini")
            inner = card.body
            tk.Label(inner, text=label, bg=CARD, fg=MUTED_2, font=("Segoe UI", 8)).pack(anchor="w", padx=6, pady=(4, 1))
            tk.Label(inner, text=value, bg=CARD, fg=color, font=("Segoe UI Semibold", 13)).pack(anchor="w", padx=6, pady=(0, 4))

        bar = tk.Frame(self.content, bg=BG)
        bar.pack(fill="x", padx=28, pady=(0, 10))
        search_card = RoundedCard(bar, fill=CARD, border=BORDER, radius=14, height=42, content_inset=5)
        search_card.pack(side="left", fill="x", expand=True)
        search_box = search_card.body
        tk.Label(search_box, text="⌕", bg=CARD, fg=MUTED, font=("Segoe UI", 14)).pack(side="left", padx=(5, 4))
        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(search_box, textvariable=self.search_var, bg=CARD, fg=TEXT, insertbackground=TEXT,
                                     relief="flat", bd=0, highlightthickness=0, font=FONT)
        self.search_entry.pack(side="left", fill="both", expand=True, padx=(0, 6), pady=2)
        self.search_var.trace_add("write", lambda *_: self._fill_orders_tree())

        # Filters live on a dedicated row so they remain readable at 125–150% Windows scaling.
        filters_row = tk.Frame(self.content, bg=BG)
        filters_row.pack(fill="x", padx=28, pady=(0, 10))
        self.category_filter_var = tk.StringVar(value=self.t("all_categories"))
        self.status_filter_var = tk.StringVar(value=self.t("all_statuses"))
        self.refund_filter_var = tk.StringVar(value=self.t("all_refunds"))

        category_values = [self.t("all_categories")] + [self.category_label(x) for x in ITEM_CATEGORIES]
        category_combo = RoundedCombo(filters_row, textvariable=self.category_filter_var, values=category_values,
                                      state="readonly", height=42, width=220)
        category_combo.pack(side="left", padx=(0, 8))

        status_values = [self.t("all_statuses")] + [self.status_label(sx) for sx in ORDER_STATUSES]
        status_combo = RoundedCombo(filters_row, textvariable=self.status_filter_var, values=status_values,
                                    state="readonly", height=42, width=185)
        status_combo.pack(side="left", padx=(0, 8))
        refund_combo = RoundedCombo(filters_row, textvariable=self.refund_filter_var,
                                    values=[self.t("all_refunds"), self.t("refunded_only"), self.t("without_refund")],
                                    state="readonly", height=42, width=180)
        refund_combo.pack(side="left")

        self.category_filter_var.trace_add("write", lambda *_: self._fill_orders_tree())
        self.status_filter_var.trace_add("write", lambda *_: self._fill_orders_tree())
        self.refund_filter_var.trace_add("write", lambda *_: self._fill_orders_tree())

        hint = self.t("search_placeholder")
        self.search_entry.insert(0, hint)
        self.search_entry.config(fg=MUTED_2)

        def on_focus_in(_e):
            if self.search_entry.get() == hint:
                self.search_entry.delete(0, "end")
                self.search_entry.config(fg=TEXT)
            search_card.set_border(self.accent)
        def on_focus_out(_e):
            if not self.search_entry.get():
                self.search_entry.insert(0, hint)
                self.search_entry.config(fg=MUTED_2)
            search_card.set_border(BORDER)
        self.search_entry.bind("<FocusIn>", on_focus_in)
        self.search_entry.bind("<FocusOut>", on_focus_out)

        action_row = tk.Frame(self.content, bg=BG)
        action_row.pack(fill="x", padx=28, pady=(0, 10))
        self.button(action_row, self.t("delete"), self.delete_selected, bg="#3a1d28", hover="#512331", radius=16).pack(side="right")
        self.button(action_row, self.t("edit"), self.edit_selected, bg=CARD_2, hover=BORDER, radius=16).pack(side="right", padx=(0, 8))
        self.button(action_row, self.t("export_csv"), self.export_csv, bg=CARD_2, hover=BORDER, radius=16).pack(side="right", padx=(0, 8))
        self.button(action_row, self.t("clear_filters"), self._reset_filters, bg=CARD_2, hover=BORDER, radius=16).pack(side="right", padx=(0, 8))

        table_card = RoundedCard(self.content, fill=CARD, border=BORDER, radius=20, content_inset=8)
        table_card.pack(fill="both", expand=True, padx=28, pady=(0, 22))
        box = table_card.body
        cols = ("store", "order", "date", "items", "category", "expenses", "refund", "buyer", "margin", "profit", "status", "carrier", "delivery", "tracking")
        self.orders_tree = ttk.Treeview(box, columns=cols, show="headings")
        heads = {
            "store": self.t("store"), "order": self.t("order_id"), "date": self.t("date"), "items": self.t("items"), "category": self.t("category"), "expenses": self.t("cash_outflow"),
            "refund": self.t("refund"), "buyer": self.t("revenue"), "margin": self.t("buyer_percent"),
            "profit": self.t("projected_profit"), "status": self.t("status"), "carrier": self.t("carrier"),
            "delivery": self.t("delivery_status"), "tracking": self.t("tracking")
        }
        for c in cols:
            self.orders_tree.heading(c, text=heads[c])
            self.orders_tree.column(c, anchor="center", width=104)
        self.orders_tree.column("store", anchor="w", width=145)
        self.orders_tree.column("order", anchor="w", width=180)
        self.orders_tree.column("category", anchor="w", width=210)
        self.orders_tree.column("expenses", width=135)
        self.orders_tree.column("buyer", width=145)
        self.orders_tree.column("margin", width=120)
        self.orders_tree.column("profit", width=150)
        self.orders_tree.column("status", width=145)
        self.orders_tree.column("carrier", anchor="w", width=140)
        self.orders_tree.column("delivery", anchor="w", width=180)
        self.orders_tree.column("tracking", anchor="w", width=180)
        xscroll = ttk.Scrollbar(box, orient="horizontal", command=self.orders_tree.xview)
        self.orders_tree.configure(xscrollcommand=xscroll.set)
        xscroll.pack(side="bottom", fill="x", padx=5, pady=(0, 4))
        self.orders_tree.pack(fill="both", expand=True, padx=5, pady=(5, 0))
        self._configure_tree_tags(self.orders_tree)
        self.orders_tree.bind("<Double-1>", lambda _e: self.edit_selected())
        self._fill_orders_tree()

    def _reset_filters(self):
        if hasattr(self, "category_filter_var"):
            self.category_filter_var.set(self.t("all_categories"))
        if hasattr(self, "status_filter_var"):
            self.status_filter_var.set(self.t("all_statuses"))
        if hasattr(self, "refund_filter_var"):
            self.refund_filter_var.set(self.t("all_refunds"))
        if hasattr(self, "search_var"):
            self.search_var.set("")
        if self.search_entry and self.search_entry.winfo_exists():
            self.search_entry.delete(0, "end")
            self.search_entry.insert(0, self.t("search_placeholder"))
            self.search_entry.config(fg=MUTED_2)
        self._fill_orders_tree()

    def _fill_orders_tree(self):
        if not hasattr(self, "orders_tree") or not self.orders_tree.winfo_exists():
            return
        q = self.search_var.get().strip().lower() if hasattr(self, "search_var") else ""
        if q == self.t("search_placeholder").lower():
            q = ""
        category_filter = self.category_filter_var.get() if hasattr(self, "category_filter_var") else self.t("all_categories")
        status_filter = self.status_filter_var.get() if hasattr(self, "status_filter_var") else self.t("all_statuses")
        refund_filter = self.refund_filter_var.get() if hasattr(self, "refund_filter_var") else self.t("all_refunds")
        selected_category = None if category_filter == self.t("all_categories") else self.category_from_label(category_filter)
        for x in self.orders_tree.get_children():
            self.orders_tree.delete(x)
        row_idx = 0
        for order, items, t in self._get_all_with_totals():
            status_text = self.status_label(order["status"] or "Ordered")
            carrier_name = TRACKING_SLUG_TO_NAME.get(order["carrier_slug"] or "", "") if "carrier_slug" in order.keys() else ""
            delivery = self.delivery_label(order["tracking_status"] or "") if "tracking_status" in order.keys() else self.delivery_label("")
            item_terms = " ".join(f"{i['name']} {self.category_label(i['category'] if 'category' in i.keys() else 'Other')}" for i in items)
            hay = f"{order['store']} {order['amazon_order_id']} {order['tracking']} {carrier_name} {delivery} {order['status']} {status_text} " + item_terms
            if q and q not in hay.lower():
                continue
            if selected_category and not any((i["category"] if "category" in i.keys() else "Other") == selected_category for i in items):
                continue
            if status_filter != self.t("all_statuses") and status_filter != status_text:
                continue
            if refund_filter == self.t("refunded_only") and not order["refunded"]:
                continue
            if refund_filter == self.t("without_refund") and order["refunded"]:
                continue
            tag = self._row_tag(order, row_idx)
            categories = []
            for i in items:
                canonical = i["category"] if "category" in i.keys() else "Other"
                label = self.category_label(canonical)
                if label not in categories:
                    categories.append(label)
            categories_text = ", ".join(categories) if categories else self.category_label("Other")
            self.orders_tree.insert("", "end", iid=str(order["id"]), tags=(tag,), values=(
                order["store"] or "—", order["amazon_order_id"], order["purchase_date"], sum(i["qty"] for i in items), categories_text,
                self.money(t["gross_expenses"]), self.money(t["refund"]) if order["refunded"] else "—",
                self.money(t["buyer_received"]) if t["buyer_paid"] else self.money(t["buyer_expected"]) + "*",
                f"{t['buyer_percent']:.1f}%", self.money(t["projected_profit"]), status_text,
                carrier_name or "—", delivery, order["tracking"] or "—"
            ))
            row_idx += 1

    def _simple_data_page(self, page, title_key, subtitle_key, columns, rows, widths=None):
        self._clear()
        self._set_active(page)
        self._header(title_key, subtitle_key, self.t("new_order"), self.new_order,
                     secondary=(self.t("refresh"), lambda: self.refresh_current()))
        wrap_card=RoundedCard(self.content,fill=CARD,border=BORDER,radius=20,content_inset=8)
        wrap_card.pack(fill="both",expand=True,padx=24,pady=(0,18))
        wrap=wrap_card.body
        inner=tk.Frame(wrap,bg=CARD); inner.pack(fill="both",expand=True,padx=5,pady=5)
        keys=[c[0] for c in columns]
        tree=ttk.Treeview(inner,columns=keys,show="headings")
        for idx,(key,label) in enumerate(columns):
            tree.heading(key,text=label)
            tree.column(key,width=(widths[idx] if widths else 120),anchor="w" if idx in (0,1) else "center")
        y=ttk.Scrollbar(inner,orient="vertical",command=tree.yview)
        tree.configure(yscrollcommand=y.set)
        tree.pack(side="left",fill="both",expand=True); y.pack(side="right",fill="y")
        self._configure_tree_tags(tree)
        for idx,row in enumerate(rows):
            tree.insert("","end",tags=("even" if idx%2==0 else "odd",),values=row)
        if not rows:
            # Tree stays visible; a small message above it makes the empty state clear.
            note=tk.Label(wrap,text=self.t("month_no_data"),bg=CARD,fg=MUTED,font=FONT)
            note.place(relx=.5,rely=.5,anchor="center")

    def show_products(self):
        all_data=self._get_all_with_totals(); rows=[]
        for order,items,_t in all_data:
            for i in items:
                unit_profit=D(i["planned_sale"])-(D(i["buy_price"])+D(i["consumables"]))
                rows.append((i["name"],order["amazon_order_id"],i["qty"],i["sold_qty"],self.money(i["buy_price"]),self.money(i["planned_sale"]),self.money(unit_profit),self.status_label(i["status"] or "Ordered")))
        cols=[("product",self.t("product_name")),("order",self.t("order_id")),("qty",self.t("qty")),("sold",self.t("sold_label")),("buy",self.t("buy_unit")),("sale",self.t("plan_sale")),("profit",self.t("unit_profit")),("status",self.t("status"))]
        self._simple_data_page("products","products_title","products_subtitle",cols,rows,[250,190,70,70,110,110,110,120])

    def show_sales(self):
        all_data=self._get_all_with_totals(); rows=[]
        for order,items,_t in all_data:
            for i in items:
                sold=int(i["sold_qty"] or 0)
                if sold<=0: continue
                revenue=D(i["actual_sale"])*sold
                cost=(D(i["buy_price"])+D(i["consumables"]))*sold
                rows.append((i["name"],order["amazon_order_id"],sold,self.money(i["actual_sale"]),self.money(revenue),self.money(revenue-cost),order["purchase_date"]))
        cols=[("product",self.t("product_name")),("order",self.t("order_id")),("sold",self.t("sold_label")),("unit",self.t("actual_sale_unit")),("revenue",self.t("revenue")),("profit",self.t("profit")),("date",self.t("date"))]
        self._simple_data_page("sales","sales_title","sales_subtitle",cols,rows,[260,190,80,120,120,120,110])

    def show_refunds(self):
        rows=[]
        for order,items,t in self._get_all_with_totals():
            if not order["refunded"]: continue
            rows.append((order["amazon_order_id"],order["purchase_date"],sum(int(i["qty"] or 0) for i in items),self.money(t["gross_expenses"]),self.money(t["refund"]),self.status_label(order["status"] or "Ordered"),order["tracking"] or "—"))
        cols=[("order",self.t("order_id")),("date",self.t("date")),("items",self.t("items")),("cost",self.t("expenses")),("refund",self.t("refund_sum")),("status",self.t("status")),("tracking",self.t("tracking"))]
        self._simple_data_page("refunds","refunds_title","refunds_subtitle",cols,rows,[200,110,80,120,120,130,220])

    def show_expenses(self):
        rows=[]
        for order,items,t in self._get_all_with_totals():
            buy=sum((D(i["buy_price"])*D(i["qty"]) for i in items),Decimal("0"))
            cons=sum((D(i["consumables"])*D(i["qty"]) for i in items),Decimal("0"))
            rows.append((order["amazon_order_id"],order["purchase_date"],self.money(buy),self.money(cons),self.money(order["shipping"]),self.money(order["tax"]),self.money(order["other_expenses"]),self.money(t["gross_expenses"])))
        cols=[("order",self.t("order_id")),("date",self.t("date")),("buy",self.t("buy_cost")),("cons",self.t("consumables")),("ship",self.t("shipping")),("tax",self.t("tax")),("other",self.t("other_costs")),("total",self.t("order_cost"))]
        self._simple_data_page("expenses","expenses_title","expenses_subtitle",cols,rows,[190,105,110,110,100,100,100,120])

    def show_analytics(self):
        self._clear()
        self._set_active("analytics")
        self._header("analytics_title", "analytics_subtitle", self.t("export_csv"), self.export_csv,
                     secondary=(self.t("refresh"), self.show_analytics))
        scroll = ScrollableFrame(self.content, BG)
        scroll.pack(fill="both", expand=True, pady=(0, 16))
        body = scroll.inner
        all_data = self._get_all_with_totals()
        s = self._stats(all_data)
        if not all_data:
            empty_card = RoundedCard(body, fill=CARD, border=BORDER, radius=20, height=150, content_inset=8)
            empty_card.pack(fill="x", padx=28, pady=(0, 16))
            empty = empty_card.body
            tk.Label(empty, text="◫", bg=CARD, fg=self.accent, font=("Segoe UI", 30)).pack(pady=(17, 4))
            tk.Label(empty, text=self.t("no_analytics"), bg=CARD, fg=MUTED, font=FONT).pack(pady=(0, 14))
            return

        cards = tk.Frame(body, bg=BG)
        cards.pack(fill="x", padx=28, pady=(0, 12))
        specs = [
            (self.t("roi"), f"{s['roi']:.1f}%", "↗", GREEN if s["roi"] >= 0 else RED),
            (self.t("avg_order"), self.money(s["avg_order"]), "≈", TEXT),
            (self.t("refund_rate"), f"{s['refund_rate']:.1f}%", "↩", AMBER),
            (self.t("inventory_value"), self.money(s["inventory_value"]), "□", BLUE),
        ]
        for i, (title, value, icon, color) in enumerate(specs):
            card = KpiCard(cards, self, title, icon, "", color)
            card.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 5, 0 if i == 3 else 5))
            cards.grid_columnconfigure(i, weight=1, uniform="analkpi")
            card.value_label.config(text=value, fg=color)

        charts = tk.Frame(body, bg=BG)
        charts.pack(fill="x", padx=28, pady=(0, 12))
        charts.grid_columnconfigure(0, weight=2)
        charts.grid_columnconfigure(1, weight=1)
        perf_card = RoundedCard(charts, fill=CARD, border=BORDER, radius=20, height=320, content_inset=8)
        perf_card.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        perf = perf_card.body
        self._section_header(perf, self.t("performance"), self.t("performance_hint"))
        FinancialChart(perf, self, self._monthly_data(all_data), height=245).pack(fill="both", expand=True, padx=4, pady=(0, 5))
        inv_card = RoundedCard(charts, fill=CARD, border=BORDER, radius=20, height=320, content_inset=8)
        inv_card.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        inv = inv_card.body
        self._section_header(inv, self.t("inventory_health"), self.t("inventory_hint"))
        DonutChart(inv, self, s["sold_units"], s["stock_units"], height=245).pack(fill="both", expand=True, padx=3, pady=(0, 5))

        bottom = tk.Frame(body, bg=BG)
        bottom.pack(fill="x", padx=28, pady=(0, 16))
        bottom.grid_columnconfigure(0, weight=2)
        bottom.grid_columnconfigure(1, weight=1)

        top_card = RoundedCard(bottom, fill=CARD, border=BORDER, radius=20, height=390, content_inset=8)
        top_card.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        topbox = top_card.body
        self._section_header(topbox, self.t("top_products"), self.t("top_products_hint"))
        cols = ("product", "units", "sold", "profit", "per")
        tree = ttk.Treeview(topbox, columns=cols, show="headings", height=8)
        headers = [self.t("product_name_short"), self.t("units"), self.t("sold_label"), self.t("profit"), self.t("profit_per_unit")]
        for c, h in zip(cols, headers):
            tree.heading(c, text=h)
            tree.column(c, width=110, anchor="center")
        tree.column("product", width=260, anchor="w")
        tree.pack(fill="both", expand=True, padx=5, pady=(0, 5))
        self._configure_tree_tags(tree)
        for idx, row in enumerate(self._top_products(all_data)[:12]):
            name, qty, sold, profit, per = row
            tree.insert("", "end", tags=("even" if idx % 2 == 0 else "odd",), values=(
                name, qty, sold, self.money(profit), self.money(per)
            ))

        status_card = RoundedCard(bottom, fill=CARD, border=BORDER, radius=20, height=390, content_inset=8)
        status_card.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        statusbox = status_card.body
        self._section_header(statusbox, self.t("status_breakdown"))
        counts = defaultdict(int)
        for o, _items, _t in all_data:
            counts[o["status"] or "Ordered"] += 1
        total = max(len(all_data), 1)
        content = tk.Frame(statusbox, bg=CARD)
        content.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        for status in ORDER_STATUSES:
            count = counts[status]
            if count == 0 and status not in ("Ordered", "Completed"):
                continue
            row = tk.Frame(content, bg=CARD)
            row.pack(fill="x", pady=6)
            tk.Label(row, text=self.status_label(status), bg=CARD, fg=TEXT, font=FONT_SMALL).pack(side="left")
            tk.Label(row, text=str(count), bg=CARD, fg=MUTED, font=FONT_SMALL).pack(side="right")
            RoundedProgress(content, value=count/total, fill=self.accent, height=6).pack(fill="x", pady=(1, 0))

    def show_instructions(self):
        """Modern, language-aware guide without empty grid cells."""
        self._clear()
        self.current_page = "instructions"
        self._set_active("instructions")
        self._header("instructions_title", "instructions_subtitle")

        scroll = ScrollableFrame(self.content, BG)
        scroll.pack(fill="both", expand=True, pady=(0, 16))
        body = scroll.inner

        # Hero / quick-start card.
        hero_shell = RoundedCard(body, fill=CARD, border=BORDER, radius=24,
                                 height=196, content_inset=10)
        hero_shell.pack(fill="x", padx=28, pady=(0, 14))
        hero = hero_shell.body

        hero_head = tk.Frame(hero, bg=CARD)
        hero_head.pack(fill="x", padx=16, pady=(15, 4))
        badge = tk.Label(hero_head, text="✓", bg=self.accent, fg="#ffffff",
                         font=("Segoe UI Semibold", 12), width=2, height=1)
        badge.pack(side="left", padx=(0, 10))
        tk.Label(hero_head, text=self.t("guide_quick_title"), bg=CARD, fg=TEXT,
                 font=("Segoe UI Semibold", 16)).pack(side="left", anchor="w")

        hero_text = tk.Label(hero, text=self.t("guide_quick_text"), bg=CARD, fg=MUTED,
                             font=("Segoe UI", 10), justify="left", anchor="w",
                             wraplength=1100)
        hero_text.pack(fill="x", padx=16, pady=(5, 12))
        hero.bind("<Configure>", lambda e, lbl=hero_text: lbl.configure(
            wraplength=max(340, e.width - 40)), add="+")

        flow = tk.Frame(hero, bg=CARD)
        flow.pack(fill="x", padx=16, pady=(0, 15))
        for i in range(3):
            flow.grid_columnconfigure(i, weight=1, uniform="guideflow")
        flow_items = [
            ("01", self.t("guide_phase1_title"), self.accent),
            ("02", self.t("guide_phase2_title"), PURPLE),
            ("03", self.t("guide_phase3_title"), GREEN),
        ]
        for col, (num, label, color) in enumerate(flow_items):
            item = tk.Frame(flow, bg=CARD_2, bd=0, highlightthickness=1,
                            highlightbackground=BORDER, highlightcolor=BORDER)
            item.grid(row=0, column=col, sticky="ew",
                      padx=(0, 6) if col == 0 else ((6, 6) if col == 1 else (6, 0)))
            tk.Label(item, text=num, bg=CARD_2, fg=color,
                     font=("Segoe UI Semibold", 9)).pack(side="left", padx=(12, 8), pady=10)
            label_widget = tk.Label(item, text=label, bg=CARD_2, fg=TEXT,
                                    font=("Segoe UI Semibold", 9), anchor="w")
            label_widget.pack(side="left", fill="x", expand=True, padx=(0, 10), pady=10)

        # Three full-width phases.  Each phase contains exactly three steps, so
        # there are no empty cells regardless of window width or DPI scaling.
        phases = [
            ("guide_phase1_title", "guide_phase1_subtitle", self.accent,
             [("guide_step1_title", "guide_step1_text"),
              ("guide_step2_title", "guide_step2_text"),
              ("guide_step3_title", "guide_step3_text")]),
            ("guide_phase2_title", "guide_phase2_subtitle", PURPLE,
             [("guide_step4_title", "guide_step4_text"),
              ("guide_step5_title", "guide_step5_text"),
              ("guide_step6_title", "guide_step6_text")]),
            ("guide_phase3_title", "guide_phase3_subtitle", GREEN,
             [("guide_step7_title", "guide_step7_text"),
              ("guide_step8_title", "guide_step8_text"),
              ("guide_step9_title", "guide_step9_text")]),
        ]

        for phase_index, (phase_title, phase_subtitle, color, phase_steps) in enumerate(phases):
            shell = RoundedCard(body, fill=CARD, border=BORDER, radius=22,
                                height=382, content_inset=10)
            shell.pack(fill="x", padx=28, pady=(0, 14))
            card = shell.body

            phase_head = tk.Frame(card, bg=CARD)
            phase_head.pack(fill="x", padx=15, pady=(14, 3))
            marker = tk.Frame(phase_head, bg=color, width=5, height=38)
            marker.pack(side="left", fill="y", padx=(0, 11))
            marker.pack_propagate(False)
            title_box = tk.Frame(phase_head, bg=CARD)
            title_box.pack(side="left", fill="x", expand=True)
            tk.Label(title_box, text=self.t(phase_title), bg=CARD, fg=TEXT,
                     font=("Segoe UI Semibold", 14), anchor="w").pack(fill="x")
            subtitle = tk.Label(title_box, text=self.t(phase_subtitle), bg=CARD, fg=MUTED,
                                font=FONT_SMALL, justify="left", anchor="w",
                                wraplength=1050)
            subtitle.pack(fill="x", pady=(2, 0))

            rows = tk.Frame(card, bg=CARD)
            rows.pack(fill="both", expand=True, padx=15, pady=(8, 14))
            for local_idx, (title_key, text_key) in enumerate(phase_steps):
                row = tk.Frame(rows, bg=CARD_2, bd=0, highlightthickness=1,
                               highlightbackground=BORDER, highlightcolor=BORDER)
                row.pack(fill="x", pady=(0, 7 if local_idx < 2 else 0))

                number_text = str(phase_index * 3 + local_idx + 1)
                bubble = tk.Label(row, text=number_text, bg=color, fg="#ffffff",
                                  font=("Segoe UI Semibold", 10), width=3, height=1)
                bubble.pack(side="left", padx=(11, 10), pady=11, anchor="n")

                text_box = tk.Frame(row, bg=CARD_2)
                text_box.pack(side="left", fill="both", expand=True, padx=(0, 12), pady=(9, 10))
                tk.Label(text_box, text=self.t(title_key), bg=CARD_2, fg=TEXT,
                         font=("Segoe UI Semibold", 10), justify="left",
                         anchor="w").pack(fill="x")
                detail = tk.Label(text_box, text=self.t(text_key), bg=CARD_2, fg=MUTED,
                                  font=FONT_SMALL, justify="left", anchor="w",
                                  wraplength=1000)
                detail.pack(fill="x", pady=(3, 0))
                row.bind("<Configure>", lambda e, lbl=detail: lbl.configure(
                    wraplength=max(300, e.width - 95)), add="+")

        # Formula card makes the financial logic visible at a glance.
        formula_shell = RoundedCard(body, fill=CARD, border=BORDER, radius=22,
                                    height=218, content_inset=10)
        formula_shell.pack(fill="x", padx=28, pady=(0, 14))
        formula = formula_shell.body
        tk.Label(formula, text=self.t("guide_formula_title"), bg=CARD, fg=AMBER,
                 font=("Segoe UI Semibold", 14)).pack(anchor="w", padx=15, pady=(14, 8))

        for idx, (text_key, color) in enumerate((("guide_formula_now", self.accent),
                                                ("guide_formula_final", GREEN))):
            line = tk.Frame(formula, bg=CARD_2, bd=0, highlightthickness=1,
                            highlightbackground=BORDER, highlightcolor=BORDER)
            line.pack(fill="x", padx=15, pady=(0, 7))
            tk.Label(line, text="●", bg=CARD_2, fg=color,
                     font=("Segoe UI", 9)).pack(side="left", padx=(11, 8), pady=9)
            lbl = tk.Label(line, text=self.t(text_key), bg=CARD_2, fg=TEXT,
                           font=("Segoe UI Semibold", 10), justify="left", anchor="w",
                           wraplength=1000)
            lbl.pack(side="left", fill="x", expand=True, padx=(0, 10), pady=9)
            line.bind("<Configure>", lambda e, l=lbl: l.configure(
                wraplength=max(300, e.width - 55)), add="+")

        example = tk.Label(formula, text=self.t("guide_formula_example"), bg=CARD, fg=MUTED,
                           font=FONT_SMALL, justify="left", anchor="w", wraplength=1050)
        example.pack(fill="x", padx=15, pady=(3, 14))
        formula.bind("<Configure>", lambda e, lbl=example: lbl.configure(
            wraplength=max(320, e.width - 38)), add="+")

        # Utilities: no empty card; both sides always contain useful content.
        bottom = tk.Frame(body, bg=BG)
        bottom.pack(fill="x", padx=28, pady=(0, 22))
        bottom.grid_columnconfigure(0, weight=1, uniform="guidebottom")
        bottom.grid_columnconfigure(1, weight=1, uniform="guidebottom")

        for col, title_key, text_key, accent_color in (
            (0, "guide_shortcuts_title", "guide_shortcuts_text", self.accent),
            (1, "guide_tip_title", "guide_tip_text", GREEN),
        ):
            shell = RoundedCard(bottom, fill=CARD, border=BORDER, radius=20,
                                height=166, content_inset=9)
            shell.grid(row=0, column=col, sticky="nsew",
                       padx=(0, 6) if col == 0 else (6, 0))
            card = shell.body
            tk.Label(card, text=self.t(title_key), bg=CARD, fg=accent_color,
                     font=FONT_SUBTITLE).pack(anchor="w", padx=13, pady=(14, 6))
            lbl = tk.Label(card, text=self.t(text_key), bg=CARD, fg=MUTED,
                           font=FONT_SMALL, justify="left", anchor="nw",
                           wraplength=470)
            lbl.pack(fill="both", expand=True, padx=13, pady=(0, 13))
            card.bind("<Configure>", lambda e, l=lbl: l.configure(
                wraplength=max(240, e.width - 32)), add="+")

    def show_settings(self):
        self._clear()
        self.current_page = "settings"
        self._set_active("settings")
        self._header("settings_title", "settings_subtitle")
        scroll = ScrollableFrame(self.content, BG)
        scroll.pack(fill="both", expand=True, pady=(0, 16))
        body = scroll.inner
        grid = tk.Frame(body, bg=BG)
        grid.pack(fill="both", expand=True, padx=28, pady=(0, 20))
        grid.grid_columnconfigure(0, weight=3)
        grid.grid_columnconfigure(1, weight=2)

        left_card = RoundedCard(grid, fill=CARD, border=BORDER, radius=22, height=1540, content_inset=10)
        left_card.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        left = left_card.body
        right = tk.Frame(grid, bg=BG)
        right.grid(row=0, column=1, sticky="nsew", padx=(7, 0))

        # A compact status row replaces the old manual Save button.
        top_row = tk.Frame(left, bg=CARD)
        top_row.pack(fill="x", padx=16, pady=(14, 4))
        title_box = tk.Frame(top_row, bg=CARD)
        title_box.pack(side="left", fill="x", expand=True)
        tk.Label(title_box, text=self.t("appearance"), bg=CARD, fg=TEXT,
                 font=FONT_SUBTITLE).pack(anchor="w")
        tk.Label(title_box, text=self.t("autosave_settings_hint"), bg=CARD, fg=MUTED_2,
                 font=("Segoe UI", 8), justify="left", wraplength=430).pack(anchor="w", pady=(3, 0))
        self.settings_autosave_label = tk.Label(top_row, text="●  " + self.t("autosaved"),
                                                bg=CARD, fg=GREEN, font=FONT_SMALL)
        self.settings_autosave_label.pack(side="right", anchor="n", padx=(10, 0), pady=(2, 0))

        self.settings_language_var = tk.StringVar(value=LANGUAGE_NAMES[self.language])
        self.settings_currency_var = tk.StringVar(value=self.currency)
        self.settings_theme_var = tk.StringVar(value=self.theme_label(self.theme_key))
        self.settings_tray_var = tk.BooleanVar(value=self.system_tray_enabled)
        self.settings_update_url_var = tk.StringVar(value=self.update_manifest_url)
        self.settings_animations_var = tk.BooleanVar(value=self.animations_enabled)
        self.settings_default_buyer_var = tk.StringVar(value=f"{self.default_buyer_percent:g}")
        self.settings_accent_var = tk.StringVar(value=self.accent_key)
        self.settings_aftership_key_var = tk.StringVar(value=self.aftership_api_key)
        self.settings_remember_aftership_var = tk.BooleanVar(value=self.remember_aftership_key)
        self.settings_tracking_interval_var = tk.StringVar(value={15: self.t("minutes_15"), 30: self.t("minutes_30"), 60: self.t("minutes_60")}.get(self.tracking_refresh_minutes, self.t("minutes_30")))

        def setting_group(parent, title, hint, min_height=148):
            group_card = RoundedCard(parent, fill=CARD_2, border=BORDER, radius=16,
                                     height=min_height, content_inset=9)
            group_card.pack(fill="x", padx=8, pady=6)
            group = group_card.body
            tk.Label(group, text=title, bg=CARD_2, fg=TEXT, font=FONT_BOLD).pack(
                anchor="w", padx=8, pady=(8, 4))
            hint_label = tk.Label(group, text=hint, bg=CARD_2, fg=MUTED, font=FONT_SMALL,
                                  wraplength=420, justify="left", anchor="w")
            hint_label.pack(anchor="w", fill="x", padx=8, pady=(0, 9))
            def _fit_hint(event, lbl=hint_label):
                lbl.configure(wraplength=max(220, event.width - 20))
            group.bind("<Configure>", _fit_hint, add="+")
            return group

        lang_group = setting_group(left, self.t("language"), self.t("language_hint"), 150)
        lang_combo = RoundedCombo(lang_group, textvariable=self.settings_language_var,
                                  values=list(LANGUAGE_NAMES.values()), state="readonly", height=40)
        lang_combo.pack(fill="x", padx=6, pady=(0, 7))

        currency_group = setting_group(left, self.t("currency"), self.t("currency_hint"), 150)
        currency_combo = RoundedCombo(currency_group, textvariable=self.settings_currency_var,
                                      values=["$", "€", "₴"], state="readonly", height=40)
        currency_combo.pack(fill="x", padx=6, pady=(0, 7))

        theme_group = setting_group(left, self.t("theme"), self.t("theme_hint"), 150)
        theme_combo = RoundedCombo(theme_group, textvariable=self.settings_theme_var, values=[self.theme_label("dark"), self.theme_label("light")], state="readonly", height=40)
        theme_combo.pack(fill="x", padx=6, pady=(0,7))

        tray_card = RoundedCard(left, fill=CARD_2, border=BORDER, radius=16, height=142, content_inset=9)
        tray_card.pack(fill="x", padx=8, pady=6)
        tray_group = tray_card.body
        tk.Label(tray_group, text=self.t("system_tray"), bg=CARD_2, fg=TEXT, font=FONT_BOLD).pack(anchor="w", padx=7, pady=(8,4))
        tray_hint = tk.Label(tray_group, text=self.t("system_tray_hint"), bg=CARD_2, fg=MUTED, font=FONT_SMALL, wraplength=420, justify="left", anchor="w")
        tray_hint.pack(fill="x", padx=7, pady=(0,7)); tray_group.bind("<Configure>", lambda e: tray_hint.configure(wraplength=max(220,e.width-20)), add="+")
        tray_row=tk.Frame(tray_group,bg=CARD_2); tray_row.pack(fill="x",padx=7,pady=(0,7))
        ToggleSwitch(tray_row,self,self.settings_tray_var).pack(side="left",padx=(0,10))
        tk.Label(tray_row,text=self.t("system_tray"),bg=CARD_2,fg=TEXT,font=FONT_BOLD).pack(side="left")

        buyer_group = setting_group(left, self.t("default_buyer_percent"), self.t("default_buyer_percent_hint"), 158)
        buyer_entry = RoundedEntry(buyer_group, textvariable=self.settings_default_buyer_var,
                                   fill=CARD, radius=13, height=40, numeric=True, max_decimals=2)
        buyer_entry.pack(fill="x", padx=6, pady=(0, 7))

        accent_group = setting_group(left, self.t("accent_color"), self.t("accent_hint"), 158)
        AccentSelector(accent_group, self, self.settings_accent_var).pack(fill="x", padx=6, pady=(0, 8))

        anim_card = RoundedCard(left, fill=CARD_2, border=BORDER, radius=16,
                                height=132, content_inset=9)
        anim_card.pack(fill="x", padx=8, pady=6)
        anim_group = anim_card.body
        tk.Label(anim_group, text=self.t("animations"), bg=CARD_2, fg=TEXT,
                 font=FONT_BOLD).pack(anchor="w", padx=7, pady=(8, 4))
        anim_hint = tk.Label(anim_group, text=self.t("animations_hint"), bg=CARD_2, fg=MUTED,
                             font=FONT_SMALL, wraplength=420, justify="left", anchor="w")
        anim_hint.pack(anchor="w", fill="x", padx=7, pady=(0, 9))
        anim_group.bind("<Configure>", lambda e: anim_hint.configure(wraplength=max(220, e.width-20)), add="+")
        anim_row = tk.Frame(anim_group, bg=CARD_2)
        anim_row.pack(fill="x", padx=7, pady=(0, 8))
        ToggleSwitch(anim_row, self, self.settings_animations_var).pack(side="left", padx=(0, 10))
        tk.Label(anim_row, text=self.t("animations"), bg=CARD_2, fg=TEXT,
                 font=FONT_BOLD).pack(side="left")

        # Auto-save bindings.  Visual changes rebuild Settings after the click
        # finishes; numerical input saves on Enter/focus-out so typing is never
        # interrupted by a page rebuild.
        lang_combo.bind("<<ComboboxSelected>>", lambda _e: self._schedule_settings_autosave(rebuild=True, delay=90), add="+")
        currency_combo.bind("<<ComboboxSelected>>", lambda _e: self._schedule_settings_autosave(rebuild=False, delay=90), add="+")
        theme_combo.bind("<<ComboboxSelected>>", lambda _e: self._schedule_settings_autosave(rebuild=True, delay=90), add="+")
        self.settings_tray_var.trace_add("write", lambda *_: self._schedule_settings_autosave(rebuild=False, delay=90))
        buyer_entry.bind("<FocusOut>", lambda _e: self._schedule_settings_autosave(rebuild=False, delay=80), add="+")
        buyer_entry.bind("<Return>", lambda _e: self._schedule_settings_autosave(rebuild=False, delay=30), add="+")
        self.settings_animations_var.trace_add("write", lambda *_: self._schedule_settings_autosave(rebuild=False, delay=90))
        self.settings_accent_var.trace_add("write", lambda *_: self._schedule_settings_autosave(rebuild=True, delay=90))

        api_group = setting_group(left, self.t("tracking_api"), self.t("tracking_api_hint"), 330)
        tk.Label(api_group, text=self.t("aftership_api_key"), bg=CARD_2, fg=MUTED, font=FONT_SMALL).pack(anchor="w", padx=6, pady=(0, 4))
        api_key_entry = RoundedEntry(api_group, textvariable=self.settings_aftership_key_var, fill=CARD, radius=13, height=40, show="•")
        api_key_entry.pack(fill="x", padx=6, pady=(0, 6))

        api_actions = tk.Frame(api_group, bg=CARD_2)
        api_actions.pack(fill="x", padx=6, pady=(0, 7))
        self.settings_tracking_check_button = self.button(
            api_actions, self.t("tracking_check_connection"), self.check_tracking_connection,
            bg=self.accent, hover=self.accent_hover, radius=15, height=42
        )
        self.settings_tracking_check_button.pack(side="left", fill="x", expand=True)
        status_box = tk.Frame(api_actions, bg=CARD_2)
        status_box.pack(side="left", padx=(12, 2))
        state_text, state_color = self._tracking_connection_status_visual()
        self.settings_tracking_status_label = tk.Label(status_box, text="●  " + state_text, bg=CARD_2, fg=state_color, font=FONT_BOLD)
        self.settings_tracking_status_label.pack(anchor="e")

        remember_row = tk.Frame(api_group, bg=CARD_2)
        remember_row.pack(fill="x", padx=6, pady=(1, 3))
        ToggleSwitch(remember_row, self, self.settings_remember_aftership_var).pack(side="left", padx=(0, 10))
        remember_text = tk.Label(remember_row, text=self.t("remember_api_key"), bg=CARD_2, fg=TEXT, font=FONT_BOLD, anchor="w")
        remember_text.pack(side="left", fill="x", expand=True)
        remember_hint = tk.Label(api_group, text=self.t("remember_api_key_hint"), bg=CARD_2, fg=MUTED_2, font=("Segoe UI", 8),
                                 wraplength=420, justify="left", anchor="w")
        remember_hint.pack(anchor="w", fill="x", padx=6, pady=(0, 4))
        key_hint = tk.Label(api_group, text=self.t("aftership_api_key_hint"), bg=CARD_2, fg=MUTED_2, font=("Segoe UI", 8),
                            wraplength=420, justify="left", anchor="w")
        key_hint.pack(anchor="w", fill="x", padx=6, pady=(0, 6))
        def _fit_api_hints(e):
            width = max(220, e.width - 20)
            key_hint.configure(wraplength=width)
            remember_hint.configure(wraplength=width)
        api_group.bind("<Configure>", _fit_api_hints, add="+")
        api_key_entry.bind("<KeyRelease>", lambda _e: self._mark_tracking_key_unverified(), add="+")
        api_key_entry.bind("<FocusOut>", lambda _e: self._schedule_settings_autosave(rebuild=False, delay=60), add="+")
        api_key_entry.bind("<Return>", lambda _e: self.check_tracking_connection(), add="+")
        self.settings_remember_aftership_var.trace_add("write", lambda *_: self._schedule_settings_autosave(rebuild=False, delay=40))

        interval_group = setting_group(left, self.t("tracking_refresh_interval"), self.t("tracking_refresh_hint"), 158)
        interval_combo = RoundedCombo(interval_group, textvariable=self.settings_tracking_interval_var,
                                      values=[self.t("minutes_15"), self.t("minutes_30"), self.t("minutes_60")],
                                      state="readonly", height=40)
        interval_combo.pack(fill="x", padx=6, pady=(0, 7))
        interval_combo.bind("<<ComboboxSelected>>", lambda _e: self._schedule_settings_autosave(rebuild=False, delay=60), add="+")

        data_card_shell = RoundedCard(right, fill=CARD, border=BORDER, radius=20, height=338, content_inset=9)
        data_card_shell.pack(fill="x", pady=(0, 12))
        data_card = data_card_shell.body
        self._section_header(data_card, self.t("data_tools"), self.t("data_tools_hint"))
        path_shell = RoundedCard(data_card, fill=CARD_2, border=BORDER, radius=14, height=106, content_inset=8)
        path_shell.pack(fill="x", padx=8, pady=(0, 9))
        path_card = path_shell.body
        tk.Label(path_card, text=self.t("database_path"), bg=CARD_2, fg=MUTED,
                 font=FONT_SMALL).pack(anchor="w", padx=5, pady=(6, 3))
        path_label = tk.Label(path_card, text=DB_FILE, bg=CARD_2, fg=TEXT,
                              font=("Consolas", 8), wraplength=430, justify="left", anchor="w")
        path_label.pack(anchor="w", fill="x", padx=5, pady=(0, 7))
        path_card.bind("<Configure>", lambda e: path_label.configure(wraplength=max(180, e.width-14)), add="+")
        actions = tk.Frame(data_card, bg=CARD)
        actions.pack(fill="x", padx=8, pady=(0, 9))
        self.button(actions, self.t("backup_db"), self.backup_database,
                    bg=CARD_2, hover=BORDER, radius=16, height=42).pack(fill="x", pady=3)
        self.button(actions, self.t("export_csv"), self.export_csv,
                    bg=CARD_2, hover=BORDER, radius=16, height=42).pack(fill="x", pady=3)
        self.button(actions, self.t("open_data_folder"), self.open_data_folder,
                    bg=CARD_2, hover=BORDER, radius=16, height=42).pack(fill="x", pady=3)

        updates_shell = RoundedCard(right, fill=CARD, border=BORDER, radius=20, height=310, content_inset=9)
        updates_shell.pack(fill="x", pady=(0,12)); updates_card=updates_shell.body
        self._section_header(updates_card, self.t("updates"), self.t("updates_hint"))
        tk.Label(updates_card,text=self.t("current_version",version=APP_VERSION),bg=CARD,fg=TEXT,font=FONT_BOLD).pack(anchor="w",padx=8,pady=(0,6))
        tk.Label(updates_card,text=self.t("update_source"),bg=CARD,fg=MUTED,font=FONT_SMALL).pack(anchor="w",padx=8,pady=(0,4))
        update_entry=RoundedEntry(updates_card,textvariable=self.settings_update_url_var,fill=CARD_2,radius=13,height=40); update_entry.pack(fill="x",padx=8,pady=(0,5))
        update_hint=tk.Label(updates_card,text=self.t("update_source_hint"),bg=CARD,fg=MUTED_2,font=("Segoe UI",8),wraplength=430,justify="left",anchor="w"); update_hint.pack(fill="x",padx=8,pady=(0,8))
        self.settings_update_url_var.trace_add("write",lambda *_:self._schedule_settings_autosave(rebuild=False,delay=350))
        self.settings_update_status_label=tk.Label(updates_card,text="",bg=CARD,fg=MUTED,font=FONT_SMALL,anchor="w"); self.settings_update_status_label.pack(fill="x",padx=8,pady=(0,5))
        self.settings_update_button=self.button(updates_card,self.t("check_updates"),self.check_for_updates,bg=CARD_2,hover=BORDER,radius=16,height=42); self.settings_update_button.pack(fill="x",padx=8,pady=(0,6))
        self.settings_update_open_button=self.button(updates_card,self.t("open_update"),self.open_update_page,bg=CARD_2,hover=BORDER,radius=16,height=40); self.settings_update_open_button.pack(fill="x",padx=8,pady=(0,4)); self.settings_update_open_button.configure(state="disabled")

        shortcut_shell = RoundedCard(right, fill=CARD, border=BORDER, radius=20, height=214, content_inset=9)
        shortcut_shell.pack(fill="x", pady=(0, 12))
        shortcut_card = shortcut_shell.body
        self._section_header(shortcut_card, self.t("keyboard_shortcuts"))
        for text in (self.t("shortcut_new"), self.t("shortcut_search"),
                     self.t("shortcut_refresh"), self.t("shortcut_fullscreen")):
            tk.Label(shortcut_card, text=text, bg=CARD, fg=MUTED, font=FONT_SMALL,
                     justify="left", anchor="w", wraplength=430).pack(anchor="w", fill="x", padx=8, pady=4)

        about_shell = RoundedCard(right, fill=CARD, border=BORDER, radius=20, height=196, content_inset=9)
        about_shell.pack(fill="x")
        about = about_shell.body
        self._section_header(about, self.t("about"))
        tk.Label(about, text=f"{APP_NAME}  {APP_VERSION}  •  Made by Maki", bg=CARD, fg=TEXT,
                 font=FONT_BOLD).pack(anchor="w", padx=8, pady=(0, 5))
        about_label = tk.Label(about, text=self.t("about_text"), bg=CARD, fg=MUTED,
                               font=FONT_SMALL, wraplength=430, justify="left", anchor="w")
        about_label.pack(anchor="w", fill="x", padx=8, pady=(0, 10))
        about.bind("<Configure>", lambda e: about_label.configure(wraplength=max(180, e.width-18)), add="+")

    def _tracking_connection_status_visual(self):
        state = getattr(self, "aftership_connection_state", "unknown")
        if state == "connected":
            return self.t("tracking_connected_ok"), GREEN
        if state == "checking":
            return self.t("tracking_checking"), AMBER
        if state == "error":
            return self.t("tracking_connection_error"), RED
        return self.t("tracking_not_verified"), MUTED

    def _refresh_tracking_connection_status(self):
        if hasattr(self, "settings_tracking_status_label") and self.settings_tracking_status_label.winfo_exists():
            text, color = self._tracking_connection_status_visual()
            self.settings_tracking_status_label.configure(text="●  " + text, fg=color)

    def _mark_tracking_key_unverified(self):
        current = self.settings_aftership_key_var.get().strip() if hasattr(self, "settings_aftership_key_var") else ""
        if current != self.aftership_api_key or self.aftership_connection_state in ("connected", "error"):
            self.aftership_connection_state = "unknown"
            self.aftership_connection_error = ""
            self._refresh_tracking_connection_status()
        self._schedule_settings_autosave(rebuild=False, delay=240)

    def check_tracking_connection(self):
        key = self.settings_aftership_key_var.get().strip() if hasattr(self, "settings_aftership_key_var") else self.aftership_api_key.strip()
        if not key:
            self.aftership_connection_state = "error"
            self.aftership_connection_error = self.t("tracking_enter_key")
            self._refresh_tracking_connection_status()
            self.show_toast(self.t("tracking_enter_key"), "warning", duration=3200)
            return
        self.aftership_api_key = key
        self.aftership_connection_state = "checking"
        self.aftership_connection_error = ""
        self._refresh_tracking_connection_status()
        if hasattr(self, "settings_tracking_check_button"):
            try:
                self.settings_tracking_check_button.configure(state="disabled")
            except Exception:
                pass
        self._schedule_settings_autosave(rebuild=False, delay=0)

        def worker():
            try:
                verify_aftership_key(key)
                error = None
            except Exception as exc:
                error = str(exc)
            try:
                self.after(0, lambda: self._finish_tracking_connection_check(key, error))
            except tk.TclError:
                pass
        threading.Thread(target=worker, daemon=True).start()

    def _finish_tracking_connection_check(self, checked_key, error):
        if hasattr(self, "settings_tracking_check_button"):
            try:
                self.settings_tracking_check_button.configure(state="normal")
            except Exception:
                pass
        current = self.settings_aftership_key_var.get().strip() if hasattr(self, "settings_aftership_key_var") else self.aftership_api_key
        if current != checked_key:
            self.aftership_connection_state = "unknown"
            self.aftership_connection_error = ""
            self._refresh_tracking_connection_status()
            return
        if error:
            self.aftership_connection_state = "error"
            self.aftership_connection_error = error
            self._refresh_tracking_connection_status()
            self.show_toast(self.t("tracking_error", error=error), "error", duration=5200)
        else:
            self.aftership_connection_state = "connected"
            self.aftership_connection_error = ""
            self._refresh_tracking_connection_status()
            self.show_toast(self.t("tracking_connected_ok"), "success", duration=2600)
            self._schedule_settings_autosave(rebuild=False, delay=0)

    def _schedule_settings_autosave(self, rebuild=False, delay=140):
        """Debounce Settings changes and persist them without a Save button."""
        self._settings_autosave_rebuild = bool(rebuild or getattr(self, "_settings_autosave_rebuild", False))
        job = getattr(self, "_settings_autosave_job", None)
        if job:
            try:
                self.after_cancel(job)
            except Exception:
                pass
        self._settings_autosave_job = self.after(delay, self._autosave_settings)

    def _autosave_settings(self):
        self._settings_autosave_job = None
        rebuild = bool(getattr(self, "_settings_autosave_rebuild", False))
        self._settings_autosave_rebuild = False
        if getattr(self, "_settings_autosave_busy", False):
            return
        required = ("settings_language_var", "settings_currency_var", "settings_theme_var", "settings_tray_var", "settings_update_url_var", "settings_animations_var",
                    "settings_default_buyer_var", "settings_accent_var", "settings_aftership_key_var",
                    "settings_remember_aftership_var", "settings_tracking_interval_var")
        if not all(hasattr(self, name) for name in required):
            return
        self._settings_autosave_busy = True
        try:
            selected_name = self.settings_language_var.get()
            new_lang = next((code for code, name in LANGUAGE_NAMES.items() if name == selected_name), self.language)
            new_currency = self.settings_currency_var.get() or "$"
            if new_currency not in ("$", "€", "₴"):
                new_currency = self.currency
            new_theme = self.theme_from_label(self.settings_theme_var.get())
            new_tray = bool(self.settings_tray_var.get())
            new_update_url = self.settings_update_url_var.get().strip()
            new_animations = bool(self.settings_animations_var.get())
            try:
                raw = self.settings_default_buyer_var.get().strip().replace(",", ".")
                new_default_buyer = max(0.0, min(100.0, float(raw))) if raw else self.default_buyer_percent
            except ValueError:
                new_default_buyer = self.default_buyer_percent
            new_accent = self.settings_accent_var.get()
            if new_accent not in ACCENT_PRESETS:
                new_accent = self.accent_key
            new_aftership_key = self.settings_aftership_key_var.get().strip()
            new_remember_aftership = bool(self.settings_remember_aftership_var.get())
            interval_map = {self.t("minutes_15"): 15, self.t("minutes_30"): 30, self.t("minutes_60"): 60}
            new_tracking_interval = interval_map.get(self.settings_tracking_interval_var.get(), self.tracking_refresh_minutes)

            language_changed = new_lang != self.language
            theme_changed = new_theme != self.theme_key
            accent_changed = new_accent != self.accent_key
            self.language = new_lang
            self.currency = new_currency
            self.theme_key = new_theme
            self.system_tray_enabled = new_tray
            self.update_manifest_url = new_update_url
            self.animations_enabled = new_animations
            self.default_buyer_percent = new_default_buyer
            self.aftership_api_key = new_aftership_key
            self.remember_aftership_key = new_remember_aftership
            self.tracking_refresh_minutes = new_tracking_interval
            if theme_changed:
                apply_theme_globals(self.theme_key); self.configure(bg=BG)
            if accent_changed:
                self._apply_accent(new_accent)

            self.db.set_setting("language", self.language)
            self.db.set_setting("currency", self.currency)
            self.db.set_setting("theme", self.theme_key)
            self.db.set_setting("system_tray", "1" if self.system_tray_enabled else "0")
            self.db.set_setting("update_manifest_url", self.update_manifest_url)
            self.db.set_setting("animations", "1" if self.animations_enabled else "0")
            self.db.set_setting("default_buyer_percent", f"{self.default_buyer_percent:g}")
            self.db.set_setting("accent", self.accent_key)
            self.db.set_setting("remember_aftership_key", "1" if self.remember_aftership_key else "0")
            self.db.set_setting("aftership_api_key", self.aftership_api_key if self.remember_aftership_key else "")
            self.db.set_setting("tracking_refresh_minutes", str(self.tracking_refresh_minutes))
            self._schedule_tracking_tick()
            if self.system_tray_enabled: self._ensure_tray_icon()
            else: self._stop_tray_icon()

            if accent_changed or theme_changed:
                self._style_widgets()

            if rebuild or language_changed or accent_changed or theme_changed:
                # Rebuild after saving so every visible caption/accent updates at once.
                self.sidebar.destroy()
                self.content.destroy()
                self._build_shell()
                self.show_settings()
            elif hasattr(self, "settings_autosave_label") and self.settings_autosave_label.winfo_exists():
                self.settings_autosave_label.configure(text="●  " + self.t("autosaved"), fg=GREEN)
        finally:
            self._settings_autosave_busy = False

    def toggle_amount_visibility(self):
        self.sums_hidden = not bool(self.sums_hidden)
        self.db.set_setting("hide_amounts", "1" if self.sums_hidden else "0")
        self.refresh_current()

    @staticmethod
    def _version_tuple(value):
        nums=[]
        for part in str(value).strip().lstrip("vV").split("."):
            try: nums.append(int(part))
            except ValueError: nums.append(0)
        return tuple((nums+[0,0,0])[:3])

    def _configured_update_manifest_url(self):
        source=(self.update_manifest_url or "").strip()
        if source:
            return source
        # Developer-friendly bundled config: put the permanent raw manifest URL
        # in update_config.json once before distributing the app. End users then
        # never need to configure anything.
        try:
            cfg_path=resource_path("update_config.json")
            if os.path.exists(cfg_path):
                with open(cfg_path,"r",encoding="utf-8") as fh:
                    cfg=json.load(fh) or {}
                source=str(cfg.get("manifest_url") or "").strip()
        except Exception:
            source=""
        return source

    def _load_update_manifest(self):
        source=self._configured_update_manifest_url()
        if source:
            req=urllib.request.Request(source,headers={"User-Agent":f"{APP_NAME}/{APP_VERSION}","Cache-Control":"no-cache"})
            with urllib.request.urlopen(req,timeout=8) as resp:
                return json.loads(resp.read().decode("utf-8",errors="replace"))
        local=os.path.join(app_data_dir(),UPDATE_MANIFEST_FILE)
        if not os.path.exists(local): local=resource_path(UPDATE_MANIFEST_FILE)
        with open(local,"r",encoding="utf-8") as fh: return json.load(fh)

    def _auto_check_for_updates(self):
        if self._auto_update_checked:
            return
        self._auto_update_checked=True
        def worker():
            try:
                manifest=self._load_update_manifest(); error=None
            except Exception as exc:
                manifest=None; error=str(exc)
            try:
                self.after(0,lambda:self._finish_auto_update_check(manifest,error))
            except tk.TclError:
                pass
        threading.Thread(target=worker,daemon=True).start()

    def _finish_auto_update_check(self,manifest,error):
        # Startup checks stay silent on connection errors or when already current.
        if error or not manifest:
            return
        latest=str(manifest.get("version") or APP_VERSION).strip()
        if self._version_tuple(latest) <= self._version_tuple(APP_VERSION):
            return
        url=str(manifest.get("download_url") or manifest.get("url") or "").strip()
        self._latest_update_url=url
        notes=str(manifest.get("notes") or "").strip()
        self._show_update_prompt(latest,url,notes)

    def _show_update_prompt(self,latest,url,notes=""):
        if getattr(self,"_auto_update_dialog",None) is not None:
            try:
                if self._auto_update_dialog.winfo_exists():
                    self._auto_update_dialog.lift(); return
            except tk.TclError:
                pass
        dlg=tk.Toplevel(self)
        self._auto_update_dialog=dlg
        dlg.title(self.t("auto_update_title"))
        dlg.configure(bg=BG)
        dlg.transient(self)
        dlg.resizable(False,False)
        dlg.protocol("WM_DELETE_WINDOW",lambda:self._close_update_prompt())
        try:
            if self._window_icon is not None: dlg.iconphoto(True,self._window_icon)
        except tk.TclError:
            pass
        shell=RoundedCard(dlg,fill=CARD,border=BORDER,radius=22,height=300,content_inset=14,auto_expand=True)
        shell.pack(fill="both",expand=True,padx=14,pady=14)
        body=shell.body
        head=tk.Frame(body,bg=CARD); head.pack(fill="x",padx=8,pady=(6,8))
        try:
            logo=tk.PhotoImage(file=resource_path("assets","brand","mountain_logo_128.png"))
            self._update_prompt_logo=logo
            tk.Label(head,image=logo,bg=CARD,bd=0,highlightthickness=0,width=54,height=54).pack(side="left",padx=(0,12))
        except tk.TclError:
            self._update_prompt_logo=None
        texts=tk.Frame(head,bg=CARD); texts.pack(side="left",fill="x",expand=True)
        tk.Label(texts,text=self.t("auto_update_title"),bg=CARD,fg=TEXT,font=("Segoe UI Semibold",16)).pack(anchor="w")
        tk.Label(texts,text=f"Refaund Manager  {APP_VERSION}  →  {latest}",bg=CARD,fg=self.accent,font=("Segoe UI Semibold",10)).pack(anchor="w",pady=(3,0))
        msg=self.t("auto_update_body",version=latest)
        tk.Label(body,text=msg,bg=CARD,fg=TEXT,font=("Segoe UI",10),justify="left",anchor="w",wraplength=470).pack(fill="x",padx=8,pady=(6,5))
        if notes:
            tk.Label(body,text=self.t("auto_update_notes",notes=notes),bg=CARD,fg=MUTED,font=("Segoe UI",9),justify="left",anchor="w",wraplength=470).pack(fill="x",padx=8,pady=(0,10))
        actions=tk.Frame(body,bg=CARD); actions.pack(fill="x",padx=8,pady=(10,4))
        self.button(actions,self.t("auto_update_later"),self._close_update_prompt,bg=CARD_2,hover=CARD_3,radius=15,height=42).pack(side="right",padx=(8,0))
        update_btn=self.button(actions,self.t("auto_update_now"),lambda:self._accept_update(url),bg=self.accent,hover=self.accent_hover,radius=15,height=42)
        update_btn.pack(side="right")
        if not url:
            update_btn.configure(state="disabled")
        dlg.update_idletasks()
        w=max(540,dlg.winfo_reqwidth()); h=max(300,dlg.winfo_reqheight())
        x=self.winfo_rootx()+max(0,(self.winfo_width()-w)//2); y=self.winfo_rooty()+max(0,(self.winfo_height()-h)//2)
        dlg.geometry(f"{w}x{h}+{x}+{y}")
        dlg.lift(); dlg.focus_force()

    def _close_update_prompt(self):
        dlg=getattr(self,"_auto_update_dialog",None); self._auto_update_dialog=None
        if dlg is not None:
            try: dlg.destroy()
            except tk.TclError: pass

    def _accept_update(self,url):
        self._close_update_prompt()
        if url:
            try: webbrowser.open(url)
            except Exception: pass

    def check_for_updates(self):
        if hasattr(self,"settings_update_button"): self.settings_update_button.configure(state="disabled")
        if hasattr(self,"settings_update_status_label"): self.settings_update_status_label.configure(text=self.t("checking_updates"),fg=AMBER)
        def worker():
            try: manifest=self._load_update_manifest(); error=None
            except Exception as exc: manifest=None; error=str(exc)
            try: self.after(0,lambda:self._finish_update_check(manifest,error))
            except tk.TclError: pass
        threading.Thread(target=worker,daemon=True).start()

    def _finish_update_check(self,manifest,error):
        if hasattr(self,"settings_update_button"): self.settings_update_button.configure(state="normal")
        if error:
            text=self.t("update_error",error=error)
            if hasattr(self,"settings_update_status_label"): self.settings_update_status_label.configure(text=text,fg=RED)
            self.show_toast(text,"error",duration=4200); return
        latest=str((manifest or {}).get("version",APP_VERSION)); url=str((manifest or {}).get("download_url") or (manifest or {}).get("url") or "").strip(); self._latest_update_url=url
        newer=self._version_tuple(latest)>self._version_tuple(APP_VERSION)
        text=self.t("update_available",version=latest) if newer else self.t("up_to_date",version=APP_VERSION)
        if hasattr(self,"settings_update_status_label"): self.settings_update_status_label.configure(text=text,fg=AMBER if newer else GREEN)
        if hasattr(self,"settings_update_open_button"): self.settings_update_open_button.configure(state="normal" if newer and url else "disabled")
        self.show_toast(text,"info" if newer else "success",duration=2600)

    def open_update_page(self):
        if self._latest_update_url:
            try: webbrowser.open(self._latest_update_url)
            except Exception: pass

    def _tray_image(self):
        try:
            from PIL import Image, ImageDraw
        except Exception:
            return None
        img=Image.new("RGBA",(64,64),(0,0,0,0)); draw=ImageDraw.Draw(img)
        draw.rounded_rectangle((4,4,60,60),radius=16,fill=(17,24,35,255),outline=(74,88,108,255),width=1)
        try:
            logo=Image.open(resource_path("assets","brand","mountain_logo.png")).convert("RGBA")
            logo.thumbnail((48,48), Image.Resampling.LANCZOS)
            img.alpha_composite(logo,((64-logo.width)//2,(64-logo.height)//2))
        except Exception:
            draw.polygon([(15,42),(31,18),(49,42)],fill="white")
        return img

    def _tray_dependencies_available(self):
        try:
            import pystray  # noqa: F401
            from PIL import Image, ImageDraw  # noqa: F401
            return True
        except Exception:
            return False

    def _install_tray_dependencies_async(self):
        """Install optional tray dependencies locally without freezing the UI."""
        if self._tray_installing or getattr(sys, "frozen", False):
            return
        self._tray_installing = True
        if self.current_page == "settings":
            self.show_toast(self.t("tray_installing"), "info", duration=3500)

        def worker():
            ok=False; err=""
            try:
                deps=os.path.join(app_data_dir(), ".deps")
                os.makedirs(deps, exist_ok=True)
                # Make sure pip exists for the exact interpreter running app.py.
                try:
                    subprocess.run([sys.executable, "-m", "pip", "--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20, check=True)
                except Exception:
                    subprocess.run([sys.executable, "-m", "ensurepip", "--upgrade"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=90, check=True)
                cp=subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--upgrade", "--target", deps, "Pillow>=10.0", "pystray>=0.19"],
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=180)
                if cp.returncode != 0:
                    raise RuntimeError((cp.stdout or "pip install failed")[-800:])
                if deps not in sys.path:
                    sys.path.insert(0, deps)
                importlib.invalidate_caches()
                # Remove failed partial imports before retry.
                for name in list(sys.modules):
                    if name == "pystray" or name.startswith("pystray.") or name == "PIL" or name.startswith("PIL."):
                        sys.modules.pop(name, None)
                ok=self._tray_dependencies_available()
            except Exception as exc:
                err=str(exc)
            try:
                self.after(0, lambda: self._finish_tray_dependency_install(ok, err))
            except tk.TclError:
                pass
        threading.Thread(target=worker, daemon=True).start()

    def _finish_tray_dependency_install(self, ok, error=""):
        self._tray_installing = False
        if ok:
            if self.current_page == "settings":
                self.show_toast(self.t("tray_installed"), "success", duration=2600)
            self._ensure_tray_icon()
        else:
            self.system_tray_enabled=False
            self.db.set_setting("system_tray", "0")
            if hasattr(self, "settings_tray_var"):
                try:
                    self.settings_tray_var.set(False)
                except Exception:
                    pass
            if self.current_page == "settings":
                self.show_toast(self.t("tray_unavailable") + (f" ({error[:120]})" if error else ""), "warning", duration=5200)

    def _ensure_tray_icon(self):
        if self._tray_icon is not None or not self.system_tray_enabled:
            return
        if not self._tray_dependencies_available():
            # Source launch: self-heal by installing into .deps. Frozen EXE should
            # already contain these modules via build_exe.bat.
            if not getattr(sys, "frozen", False):
                self._install_tray_dependencies_async()
                return
            self.system_tray_enabled=False; self.db.set_setting("system_tray","0")
            if self.current_page=="settings": self.show_toast(self.t("tray_unavailable"),"warning",duration=4200)
            return
        try:
            import pystray
            image=self._tray_image()
            if image is None: raise RuntimeError("Pillow unavailable")
            def op(*_):
                try:self.after(0,self._show_from_tray)
                except tk.TclError:pass
            def hide(*_):
                try:self.after(0,self.withdraw)
                except tk.TclError:pass
            def quit_app(*_):
                try:self.after(0,self._exit_application)
                except tk.TclError:pass
            menu=pystray.Menu(pystray.MenuItem(self.t("tray_open"),op,default=True),pystray.MenuItem(self.t("tray_hide"),hide),pystray.Menu.SEPARATOR,pystray.MenuItem(self.t("tray_exit"),quit_app))
            self._tray_icon=pystray.Icon(APP_NAME,image,APP_NAME,menu); self._tray_thread=threading.Thread(target=self._tray_icon.run,daemon=True); self._tray_thread.start()
        except Exception:
            self._tray_icon=None; self.system_tray_enabled=False; self.db.set_setting("system_tray","0")
            if self.current_page=="settings": self.show_toast(self.t("tray_unavailable"),"warning",duration=4200)

    def _stop_tray_icon(self):
        icon=self._tray_icon; self._tray_icon=None
        if icon is not None:
            try:icon.stop()
            except Exception:pass

    def _show_from_tray(self):
        try:
            self.deiconify(); self.lift(); self.focus_force()
            if sys.platform=="win32" and not self._is_fullscreen:
                try:self.state("zoomed")
                except tk.TclError:pass
        except tk.TclError:pass

    def _exit_application(self):
        self._force_exit=True; self.on_close()

    def save_settings(self):
        """Backward-compatible alias used by older code; Settings now auto-save."""
        self._schedule_settings_autosave(rebuild=True, delay=0)

    def backup_database(self):
        folder = os.path.join(app_data_dir(), "backups")
        os.makedirs(folder, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(folder, f"amazon_resale_{stamp}.db")
        dest = sqlite3.connect(path)
        try:
            self.db.conn.backup(dest)
        finally:
            dest.close()
        self.show_toast(self.t("backup_created", path=path), "success", duration=4200)
        return path

    def export_csv(self):
        folder = os.path.join(app_data_dir(), "exports")
        os.makedirs(folder, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(folder, f"amazon_resale_export_{stamp}.csv")
        headers = [
            "Store", "Order ID", "Purchase date", "Tracking", "Carrier", "Delivery status", "Delivery event",
            "Order status", "Product", "Category", "Qty", "Buy price/unit", "Product subtotal", "Shipping", "Consumables", "Total cash out",
            "Refund received", "Refund amount", "Expected refund", "Buyer percent", "Sent to buyer", "Buyer paid", "Buyer expected",
            "Buyer amount received", "Capital tied", "Result now", "Final projected result"
        ]
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f); writer.writerow(headers)
            for order, items, t in self._get_all_with_totals():
                for item in items:
                    subtotal = D(item["buy_price"]) * D(item["qty"])
                    writer.writerow([
                        order["store"], order["amazon_order_id"], order["purchase_date"], order["tracking"],
                        TRACKING_SLUG_TO_NAME.get(order["carrier_slug"] or "", order["carrier_slug"] or ""),
                        self.delivery_label(order["tracking_status"] or ""), order["tracking_message"] or "", order["status"],
                        item["name"], item["category"] if "category" in item.keys() else "Other", item["qty"], item["buy_price"], float(subtotal), float(t["shipping"]),
                        float(t["consumables"]), float(t["gross_expenses"]), int(order["refunded"] or 0),
                        float(t["refund"]), float(t["expected_refund"]), float(t["buyer_percent"]), int(t.get("buyer_sent", False)), int(t["buyer_paid"]), float(t["buyer_expected"]),
                        float(t["buyer_received"]), float(t["capital_tied"]), float(t["realized_profit"]),
                        float(t["projected_profit"])
                    ])
        self.show_toast(self.t("export_created", path=path), "success", duration=4200)
        return path

    def open_data_folder(self):
        path = app_data_dir()
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception as exc:
            messagebox.showinfo(self.t("local_data"), f"{path}\n\n{exc}", parent=self)

    def show_toast(self, text, kind="success", duration=2600):
        if hasattr(self, "_toast") and self._toast and self._toast.winfo_exists():
            self._toast.destroy()
        color = GREEN if kind == "success" else (RED if kind == "error" else self.accent)
        toast = RoundedCard(self, fill=CARD_2, border=color, radius=16, height=58, content_inset=6)
        tk.Frame.configure(toast, width=470)
        self._toast = toast
        toast.place(relx=1.0, rely=1.0, x=-24, y=-24, anchor="se")
        toast_body = toast.body
        tk.Label(toast_body, text="●", bg=CARD_2, fg=color, font=("Segoe UI", 10)).pack(side="left", padx=(6, 5), pady=8)
        tk.Label(toast_body, text=text, bg=CARD_2, fg=TEXT, font=FONT_SMALL, justify="left",
                 wraplength=410).pack(side="left", padx=(0, 8), pady=8)
        try:
            toast.lift()
        except Exception:
            pass
        if self._toast_job:
            try:
                self.after_cancel(self._toast_job)
            except Exception:
                pass
        self._toast_job = self.after(duration, lambda: toast.destroy() if toast.winfo_exists() else None)

    def focus_order_search(self):
        if self.current_page != "orders":
            self.navigate_to("orders")
            # The page transition is ~300 ms when animations are enabled.
            self.after(340 if self.animations_enabled else 80, self.focus_order_search)
            return
        if self.search_entry and self.search_entry.winfo_exists():
            hint = self.t("search_placeholder")
            if self.search_entry.get() == hint:
                self.search_entry.delete(0, "end")
                self.search_entry.config(fg=TEXT)
            self.search_entry.focus_set()

    def refresh_current(self):
        pages = {
            "dashboard": self.show_dashboard, "orders": self.show_orders,
            "products": self.show_products, "sales": self.show_sales,
            "refunds": self.show_refunds, "expenses": self.show_expenses,
            "analytics": self.show_analytics, "instructions": self.show_instructions,
            "settings": self.show_settings,
        }
        pages.get(self.current_page, self.show_dashboard)()

    def new_order(self):
        OrderDialog(self, self, self.db, on_saved=self._after_save)

    def edit_selected(self):
        sel = getattr(self, "orders_tree", None)
        if not sel:
            return
        selected = sel.selection()
        if not selected:
            messagebox.showinfo(self.t("orders"), self.t("select_order"), parent=self)
            return
        OrderDialog(self, self, self.db, order_id=int(selected[0]), on_saved=self._after_save)

    def delete_selected(self):
        sel = getattr(self, "orders_tree", None)
        if not sel:
            return
        selected = sel.selection()
        if not selected:
            return
        order_id = int(selected[0])
        order = self.db.get_order(order_id)
        if messagebox.askyesno(
            self.t("delete_order_title"), self.t("delete_order_question", order_id=order["amazon_order_id"]), parent=self
        ):
            self.db.delete_order(order_id)
            self._fill_orders_tree()
            self.show_toast(self.t("delete"), "success")

    def _after_save(self):
        self.show_toast(self.t("saved_toast"), "success")
        if self.current_page == "orders" and hasattr(self, "orders_tree") and self.orders_tree.winfo_exists():
            self._fill_orders_tree()
        else:
            self.refresh_current()

    def on_close(self):
        if self.system_tray_enabled and not self._force_exit:
            self._ensure_tray_icon()
            # Only hide the window if a real tray icon was created.  If the
            # optional tray dependency is unavailable, close normally instead
            # of leaving an invisible process with no way to restore it.
            if self._tray_icon is not None:
                try: self.withdraw()
                except tk.TclError: pass
                return
        # Flush the visible Settings state before closing. If remember-key is off,
        # this also guarantees no API key remains persisted on disk.
        if self.current_page == "settings" and hasattr(self, "settings_aftership_key_var"):
            try:
                job = getattr(self, "_settings_autosave_job", None)
                if job:
                    self.after_cancel(job)
                    self._settings_autosave_job = None
                self._autosave_settings()
            except Exception:
                pass
        if self._tracking_refresh_job:
            try:
                self.after_cancel(self._tracking_refresh_job)
            except Exception:
                pass
        self._stop_tray_icon()
        self.db.close()
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
