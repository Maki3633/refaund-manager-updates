@echo off
chcp 65001 >nul
cd /d "%~dp0"

set "PY_CMD="
where py >nul 2>nul
if not errorlevel 1 set "PY_CMD=py -3"
if not defined PY_CMD (
  where python >nul 2>nul
  if not errorlevel 1 set "PY_CMD=python"
)

if not defined PY_CMD (
  echo Python не знайдено. Встанови Python 3.11 або новіший з python.org.
  echo Під час встановлення увімкни Add Python to PATH.
  echo.
  pause
  exit /b 1
)

if not exist ".deps" mkdir ".deps"

rem Use a local dependency folder so pip and the app always use the same modules.
set "PYTHONPATH=%CD%\.deps;%PYTHONPATH%"
%PY_CMD% -c "import PIL, pystray" >nul 2>nul
if errorlevel 1 (
  echo [Refaund Manager] Встановлюю системний трей у локальну папку .deps...
  %PY_CMD% -m pip --version >nul 2>nul
  if errorlevel 1 %PY_CMD% -m ensurepip --upgrade
  %PY_CMD% -m pip install --disable-pip-version-check --upgrade --target "%CD%\.deps" -r requirements.txt
  if errorlevel 1 (
    echo.
    echo Не вдалося встановити pystray/Pillow. Перевір інтернет та pip.
    echo Програма все одно запуститься; системний трей можна буде повторити пізніше.
    echo.
  )
)

rem Final verification using exactly the same interpreter + local .deps.
%PY_CMD% -c "import PIL, pystray; print('Tray dependencies: OK')" >nul 2>nul
if errorlevel 1 (
  echo [Увага] Компоненти системного трею поки недоступні.
) else (
  echo [OK] Системний трей готовий.
)

%PY_CMD% app.py
if errorlevel 1 (
  echo.
  echo Не вдалося запустити програму. Сфотографуй текст помилки і надішли мені.
  pause
)
