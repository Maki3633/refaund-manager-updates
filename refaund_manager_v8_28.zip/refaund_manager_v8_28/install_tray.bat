@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY_CMD="
where py >nul 2>nul
if not errorlevel 1 set "PY_CMD=py -3"
if not defined PY_CMD (
  where python >nul 2>nul
  if not errorlevel 1 set "PY_CMD=python"
)
if not defined PY_CMD (
  echo Python не знайдено.
  pause
  exit /b 1
)
if not exist ".deps" mkdir ".deps"
%PY_CMD% -m pip --version >nul 2>nul
if errorlevel 1 %PY_CMD% -m ensurepip --upgrade
%PY_CMD% -m pip install --disable-pip-version-check --upgrade --target "%CD%\.deps" -r requirements.txt
set "PYTHONPATH=%CD%\.deps;%PYTHONPATH%"
%PY_CMD% -c "import PIL, pystray; print('OK: pystray + Pillow installed')"
if errorlevel 1 (
  echo.
  echo Помилка встановлення.
) else (
  echo.
  echo Готово. Системний трей встановлено для Refaund Manager.
)
pause
